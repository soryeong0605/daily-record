import rclpy
from rclpy.node import Node
from rcl_interfaces.msg import ParameterDescriptor

class MinimalParam(Node):
    def __init__(self):
        super().__init__('minimal_param_node')
        my_parameter_descriptor = ParameterDescriptor(description='This is my parameter')
        self.declare_parameter('my_parameter', 'world', my_parameter_descriptor)
        self.timer = self.create_timer(1, self.timer_callback)

    def timer_callback(self):
        my_parameter = self.get_parameter('my_parameter').get_parameter_value().string_value
        self.get_logger().info(f'Hello {my_parameter}!')
        my_new_parameter = rclpy.parameter.Parameter(
            'my_parameter',
            rclpy.Parameter.Type.STRING,
            'world'
        )
        all_new_parameters = [my_new_parameter]
        self.set_parameters(all_new_parameters)
    

def main(args=None):
    rclpy.init(args=args)
    node = MinimalParam()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()