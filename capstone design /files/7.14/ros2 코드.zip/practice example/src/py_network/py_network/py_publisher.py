import rclpy
from rclpy.node import Node
from std_msgs.msg import Float32
import numpy as np

class Publisher(Node):
    def __init__(self):
        super().__init__('publisher_node')
        self.publisher = self.create_publisher(Float32, 'message', 10)
        self.timer = self.create_timer(1.0, self.publish_message)
        self.count = 0

    def publish_message(self):
        msg = Float32()
        msg.data = np.pi*self.count
        self.publisher.publish(msg)
        self.get_logger().info(f'Publishing: {msg.data}')
        self.count += 1

    
def main(args=None):
    rclpy.init(args=args)
    publisher = Publisher()
    rclpy.spin(publisher)
    publisher.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()