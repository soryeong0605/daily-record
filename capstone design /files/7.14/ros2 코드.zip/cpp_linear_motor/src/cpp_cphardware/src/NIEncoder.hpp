#pragma once
#include <cassert>
#include <string>
#include <span>
#include "NIDAQmx.h"
#include "EncoderConfig.hpp"

// NIDAQmx 타입 재정의 목록
// int32 == int, float64 == double, uInt64 == unsigned long long, TaskHandle == void*, bool32 == bool

// NIEncoder 클래스 템플릿 (CRTP 패턴)
template<typename Derived>
class NIEncoder
{
  public:
    // 클래스 생성자, 소멸자 선언
    NIEncoder(const EncoderConfig& config);
    ~NIEncoder() noexcept;

    // 초기화 함수
    int init(std::string hw_timer_source, float64 rate, int32 active_edge, int32 sample_mode, uInt64 hw_buffer_size);

    // 데이터 읽기 함수
    int read_data(std::span<double> buffer, int32 sample_size);

    // 작업 시작 함수
    int start();

    // 작업 중지 함수
    void stop() noexcept;

  protected:
    // 공용 변수 선언
    TaskHandle _taskhandle;       // NI-DAQmx 작업 핸들
    EncoderConfig _config;        // 인코더 구성 설정
};

// RotaryEncoder 클래스 (NIEncoder의 파생 클래스)
class RotaryEncoder : public NIEncoder<RotaryEncoder> {
  public:
    // RotaryEncoder 생성자 선언
    RotaryEncoder(const EncoderConfig& config) : NIEncoder<RotaryEncoder>(config) {};

    // RotaryEncoder 채널 생성 함수 선언
    bool create_channel();
};

// LinearEncoder 클래스 (NIEncoder의 파생 클래스)
class LinearEncoder : public NIEncoder<LinearEncoder> {
  public:
    // LinearEncoder 생성자 선언
    LinearEncoder(const EncoderConfig& config) : NIEncoder<LinearEncoder>(config) {};

    // LinearEncoder 채널 생성 함수 선언
    bool create_channel();
};

// NIEncoder 클래스 생성자 구현
template<typename Derived>
NIEncoder<Derived>::NIEncoder(const EncoderConfig& config) {
  _taskhandle = nullptr;
  _config = config;
}

// NIEncoder 클래스 소멸자 구현
template<typename Derived>
NIEncoder<Derived>::~NIEncoder() noexcept {
  // 클래스는 소멸 시 stop 함수 호출
  stop();
  if(_taskhandle) {
    DAQmxClearTask(_taskhandle);
    _taskhandle = nullptr;
  }
}

// init 함수 구현
template<typename Derived>
int NIEncoder<Derived>::init(std::string hw_timer_source, float64 rate, int32 active_edge, int32 sample_mode, uInt64 hw_buffer_size) {
  // DAQ 작업 생성
  if(DAQmxCreateTask(_config.name.c_str(), &_taskhandle) < 0) return -1;

  // 채널 생성 (파생 클래스의 create_channel 함수 호출)
	auto& self = static_cast<Derived&>(*this);
  if(!self.create_channel()) return -2;

  // 채널 설정
  if(DAQmxSetCIEncoderAInputTerm(_taskhandle, _config.name.c_str(), _config.chan_a.c_str()) < 0) return -3;   // 채널 A 설정
  if(DAQmxSetCIEncoderBInputTerm(_taskhandle, _config.name.c_str(), _config.chan_b.c_str()) < 0) return -4;   // 채널 B 설정
  if(DAQmxSetCIEncoderZIndexEnable(_taskhandle, _config.name.c_str(), _config.zidx_enable) < 0) return -5;    // Z-Index 활성화 설정 (사용 X)

  // 샘플링 클럭 타이밍 구성
  if(DAQmxCfgSampClkTiming(_taskhandle, hw_timer_source.c_str(), rate, active_edge, sample_mode, hw_buffer_size) < 0) return -6;

  return 0;
}

// read_data 함수 구현
template<typename Derived>
int NIEncoder<Derived>::read_data(std::span<double> buffer, int32 sample_size) {
  // 버퍼 크기가 sample_size보다 작은지 확인, 작으면 오류 발생
  assert(buffer.size() >= static_cast<size_t>(sample_size) && "Buffer size is smaller than sample_size");

  // 데이터 읽기
  // 읽어온 데이터는 buffer에 저장됨
  int samps_read = 0;   // 실제로 읽은 샘플 수
  DAQmxReadCounterF64(_taskhandle, sample_size, 1, buffer.data(), (uInt32)buffer.size(), &samps_read, NULL);
  return samps_read;
}

// start 함수 구현
template<typename Derived>
int NIEncoder<Derived>::start() {
  // DAQ 작업 시작
  return DAQmxStartTask(_taskhandle);
}

// stop 함수 구현
template<typename Derived>
void NIEncoder<Derived>::stop() noexcept {
  // _taskhandle이 nullptr이 아닐 때 작업 중지 및 해제
  if(_taskhandle) {
    DAQmxStopTask(_taskhandle);
  }
}