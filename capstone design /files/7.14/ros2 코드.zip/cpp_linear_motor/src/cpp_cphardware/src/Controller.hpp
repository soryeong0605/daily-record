#pragma once
#include <array>
#include <utility>

template<typename Derived>
class Controller {
  public:
    Controller() = default;
    ~Controller() = default;

    template<typename... Args>
    void set_param(Args&&... args) {
      static_cast<Derived&>(*this).impl_set_param(std::forward<Args>(args)...);
    }

    auto get_param() const {
      return static_cast<const Derived&>(*this).impl_get_param();
    }

    template<typename... Args>
    void set_target(Args&&... targets) {
      static_cast<Derived&>(*this).impl_set_target(std::forward<Args>(targets)...);
    }

    auto get_target() const {
      return static_cast<const Derived&>(*this).impl_get_target();
    }

    void reset() {
      static_cast<Derived&>(*this).impl_reset();
    }

    template<typename... Args>
    auto compute(Args&&... args) {
      return static_cast<Derived&>(*this).impl_compute(std::forward<Args>(args)...);
    }

  protected:
    double _dt = 0.1; // in seconds
    double _target = 0.0;
};

class PIDController : public Controller<PIDController> {
  public:
    PIDController() : Controller() {}
    ~PIDController() = default;

    void impl_set_param(double kp, double ki, double kd, double alpha, double limit, double dt) {_kp = kp; _ki = ki; _kd = kd; _alpha = alpha; _limit = limit; _dt = dt;}
    std::array<double, 6> impl_get_param() const {return {_kp, _ki, _kd, _alpha, _limit, _dt};}
    void impl_set_target(double target) {_target = target;}
    double impl_get_target() const {return _target;}
    void impl_reset() {_prev_error = 0.0; _integral = 0.0;}
    double impl_compute(double current);

  protected:
    double _kp = 0.0;
    double _ki = 0.0;
    double _kd = 0.0;
    double _prev_error = 0.0;
    double _prev_filtered = 0.0;
    double _prev_output = 0.0;
    double _integral = 0.0;
    double _alpha = 0.1; // for derivative filtering
    double _limit = 0.0; // output limit
};

class LQRController : public Controller<LQRController> {
  public:
    LQRController() : Controller() {}
    ~LQRController() = default;

    void impl_set_param(const std::array<double, 4>& K, double alpha, double dt) {_K = K; _alpha = alpha; _dt = dt;}
    std::array<double, 6> impl_get_param() const {return {_K[0], _K[1], _K[2], _K[3], _alpha, _dt};}
    void impl_set_target(double target_pos, double target_ang) {_target_pos = target_pos; _target_ang = target_ang;}
    std::array<double, 2> impl_get_target() const {return {_target_pos, _target_ang};}
    void impl_reset() {_prev_vel_filtered = 0.0; _prev_angvel_filtered = 0.0;}
    double impl_compute(double cart_pos, double pend_ang, double cart_vel, double pend_angvel);
  
  private:
    std::array<double, 4> _K = {0.0, 0.0, 0.0, 0.0}; // State feedback gains
    double _alpha = 0.1; // for derivative filtering
    double _prev_vel_filtered = 0.0;
    double _prev_angvel_filtered = 0.0;

    double _target_pos = 0.0;
    double _target_ang = 0.0;
};