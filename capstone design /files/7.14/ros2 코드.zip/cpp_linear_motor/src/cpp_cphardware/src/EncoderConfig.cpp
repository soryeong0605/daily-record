#include "EncoderConfig.hpp"

EncoderConfig rotenc_config = {
  .name = "RotaryEncoder",
  .counter = "Dev1/ctr1",
  .encoding_type = DAQmx_Val_X1,
  .units = DAQmx_Val_Degrees,
  .pulses_per_rev = 3000, // 3000 pulses per 360 degrees
  .chan_a = "/Dev1/PFI3",
  .chan_b = "/Dev1/PFI11"
};

EncoderConfig linenc_config = {
  .name = "LinearEncoder",
  .counter = "Dev1/ctr0",
  .encoding_type = DAQmx_Val_X4,
  .units = DAQmx_Val_Meters,
  .dist_per_pulse = 0.000004, // 0.000004 m per pulse
  .chan_a = "/Dev1/PFI8",
  .chan_b = "/Dev1/PFI10"
};