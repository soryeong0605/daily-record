#include "ros2_controller.hpp"

int main(int argc, char** argv) {
  // ROS2 노드 초기화 및 실행
  rclcpp::init(argc, argv);
  auto node = std::make_shared<ControlNode>("controller_node");
  rclcpp::spin(node->get_node_base_interface());
  rclcpp::shutdown();
  return 0;
}

ControlNode::ControlNode(const std::string& node_name)
: LifecycleNode(node_name) {
  // ROS2 파라미터 선언
  declare_parameter("target_cart_pos", 0.0);
  declare_parameter("target_pend_ang", 0.0);
  declare_parameter("max_voltage", 10.0);
  declare_parameter("dt", 0.005);
  declare_parameter("controller_type", "PID");
  declare_parameter("pid_cart_params", std::vector<double>{0.0, 0.0, 0.0, 0.1});
  declare_parameter("pid_pend_params", std::vector<double>{0.0, 0.0, 0.0, 0.1});
  declare_parameter("lqr_K", std::vector<double>{0.0, 0.0, 0.0, 0.0});
  declare_parameter("lqr_alpha", 0.1);

  // 전압 퍼블리셔 생성
  // 전압 퍼블리셔는 라이프사이클 퍼블리셔라 on/off가 가능하므로 여기서 생성
  // 상태 서브스크립션은 on/off가 불가능하므로 필요할 때 생성, 삭제
  _volt_pub = this->create_publisher<std_msgs::msg::Float64>("voltage_command", 10);

  RCLCPP_INFO(this->get_logger(), "Controller status: created");
}

ControlNode::~ControlNode() {
  // 퍼블리셔, 서브스크립션, PID 제어기 정리
  if(_volt_pub) _volt_pub.reset();
  if(_state_sub) _state_sub.reset();
  if(_cart_pid) _cart_pid.reset();
  if(_pend_pid) _pend_pid.reset();
  if(_lqr_controller) _lqr_controller.reset();
  RCLCPP_INFO(this->get_logger(), "Controller status: terminated");
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
ControlNode::on_configure(const rclcpp_lifecycle::State& state) {
  // unconfigured -> inactive
  if(_update_params() == 0 && _init() == 0) {
    // 파라미터 업데이트 및 초기화 성공 시 SUCCESS 반환
    RCLCPP_INFO(this->get_logger(), "Controller status: unconfigured -> inactive");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  } else {
    // 실패하면 FAILURE 반환
    RCLCPP_ERROR(this->get_logger(), "Controller status: unconfigured -> inactive failed");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
  }
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
ControlNode::on_activate(const rclcpp_lifecycle::State& state) {
  // inactive -> active
  if(_start() == 0) {
    // 퍼블리셔 활성화 및 서브스크립션 시작 성공 시 SUCCESS 반환
    RCLCPP_INFO(this->get_logger(), "Controller status: inactive -> active");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  } else {
    // 실패하면 FAILURE 반환
    RCLCPP_ERROR(this->get_logger(), "Controller status: inactive -> active failed");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
  }
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
ControlNode::on_deactivate(const rclcpp_lifecycle::State& state) {
  // active -> inactive
  if(_pause() == 0) {
    // 서브스크립션 중지 및 퍼블리셔 비활성화 성공 시 SUCCESS 반환
    RCLCPP_INFO(this->get_logger(), "Controller status: active -> inactive");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  } else {
    // 실패하면 FAILURE 반환
    RCLCPP_ERROR(this->get_logger(), "Controller status: active -> inactive failed");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
  }
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
ControlNode::on_cleanup(const rclcpp_lifecycle::State& state) {
  // inactive -> unconfigured
  if(_reset() == 0) {
    // PID 제어기 정리 성공 시 SUCCESS 반환
    RCLCPP_INFO(this->get_logger(), "Controller status: inactive -> unconfigured");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  } else {
    // 실패하면 FAILURE 반환
    RCLCPP_ERROR(this->get_logger(), "Controller status: inactive -> unconfigured failed");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
  }
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
ControlNode::on_shutdown(const rclcpp_lifecycle::State& state) {
  // any state -> shutdown
  if(_pause() == 0 && _reset() == 0) {
    // 모든 작업 중지 및 리소스 해제 성공 시 SUCCESS 반환
    RCLCPP_INFO(this->get_logger(), "Controller status: shutting down");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  } else {
    // 실패하면 FAILURE 반환
    RCLCPP_ERROR(this->get_logger(), "Controller status: shutting down failed");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
  }
}

int ControlNode::_update_params() {
  // 파라미터 업데이트 함수
  // client에서 ROS2 파라미터를 설정하면 이를 클래스 멤버 변수에 반영
  // 예) client에서 controller_cart_p 파라미터를 설정하면 이를 _cart_p 멤버 변수에 반영
  try {
    // ROS2에서 파라미터 가져오기를 시도
    _dt = this->get_parameter("dt").as_double();
    _target_cart_pos = this->get_parameter("target_cart_pos").as_double();
    _target_pend_ang = this->get_parameter("target_pend_ang").as_double();
    _max_voltage = this->get_parameter("max_voltage").as_double();

    // 제어기 타입 및 파라미터 설정
    _controller_type = this->get_parameter("controller_type").as_string();
    if(_controller_type == "PID") {
      auto pid_cart_list = this->get_parameter("pid_cart_params").as_double_array();
      if(pid_cart_list.size() != 4) {
        RCLCPP_ERROR(this->get_logger(), "Invalid PID cart parameters size.");
        return -3;
      }
      _pid_cart_params.kp = pid_cart_list[0];
      _pid_cart_params.ki = pid_cart_list[1];
      _pid_cart_params.kd = pid_cart_list[2];
      _pid_cart_params.alpha = pid_cart_list[3];

      auto pid_pend_list = this->get_parameter("pid_pend_params").as_double_array();
      if(pid_pend_list.size() != 4) {
        RCLCPP_ERROR(this->get_logger(), "Invalid PID pendulum parameters size.");
        return -4;
      }
      _pid_pend_params.kp = pid_pend_list[0];
      _pid_pend_params.ki = pid_pend_list[1];
      _pid_pend_params.kd = pid_pend_list[2];
      _pid_pend_params.alpha = pid_pend_list[3];
    } else if(_controller_type == "LQR") {
      auto lqr_K_list = this->get_parameter("lqr_K").as_double_array();
      if(lqr_K_list.size() != 4) {
        RCLCPP_ERROR(this->get_logger(), "Invalid LQR K parameters size.");
        return -5;
      }
      _lqr_alpha = this->get_parameter("lqr_alpha").as_double();
      for(int i = 0; i < 4; i++) {
        _lqr_K[i] = lqr_K_list[i];
      }
    } else {
      RCLCPP_ERROR(this->get_logger(), "Unsupported controller type: %s", _controller_type.c_str());
      return -6;
    }
    
  } catch (const rclcpp::exceptions::ParameterNotDeclaredException &e) {
    // 파라미터가 선언되지 않은 경우 에러 처리
    RCLCPP_ERROR(this->get_logger(), "Parameter not declared: %s", e.what());
    return -1;
  } catch (const std::exception &e) {
    // 기타 에러 처리
    RCLCPP_ERROR(this->get_logger(), "Error retrieving parameters: %s", e.what());
    return -2;
  }
  RCLCPP_INFO(this->get_logger(), "Controller parameters updated.");
  return 0;
}

int ControlNode::_init() {
  // 초기화 함수
  // 퍼블리셔 생성 및 PID 제어기 초기화
  if(_volt_pub == nullptr) {
    // 퍼블리셔가 생성되지 않은 경우 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to create publisher");
    return -1;
  }
  
  if(_controller_type == "PID") {
    // PID 제어기 생성
    if(_cart_pid == nullptr) {
      _cart_pid = std::make_unique<PIDController>();
    }
    if(_pend_pid == nullptr) {
      _pend_pid = std::make_unique<PIDController>();
    }
    RCLCPP_INFO(this->get_logger(), "Initializing PID controllers.");

    _cart_pid->set_param(_pid_cart_params.kp, _pid_cart_params.ki, _pid_cart_params.kd, _pid_cart_params.alpha, _max_voltage, _dt);
    _pend_pid->set_param(_pid_pend_params.kp, _pid_pend_params.ki, _pid_pend_params.kd, _pid_pend_params.alpha, _max_voltage, _dt);
    _cart_pid->set_target(_target_cart_pos);      // 목표 카트 위치 설정
    _pend_pid->set_target(_target_pend_ang);      // 목표 진자 각도 설정
  } else if(_controller_type == "LQR") {
    // LQR 제어기 생성
    if(_lqr_controller == nullptr) {
      _lqr_controller = std::make_unique<LQRController>();
    }
    RCLCPP_INFO(this->get_logger(), "Initializing LQR controller.");

    _lqr_controller->set_param(_lqr_K, _lqr_alpha, _dt); // Derivative filter coefficient 설정
    _lqr_controller->set_target(_target_cart_pos, _target_pend_ang); // 목표 상태 설정
  } else {
    RCLCPP_ERROR(this->get_logger(), "Unsupported controller type during initialization: %s", _controller_type.c_str());
    return -1;
  }
  return 0;
}

int ControlNode::_start() {
  // 시작 함수
  // 퍼블리셔 활성화 및 서브스크립션 시작

  // 전압 퍼블리셔 활성화
  _volt_pub->on_activate();
  if(!_volt_pub->is_activated()) {
    // 전압 퍼블리셔 활성화 실패 시 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to activate voltage publisher");
    return -1;
  }

  // 상태 서브스크립션 시작
  _state_sub = this->create_subscription<cartpend_msgs::msg::CartPendState>(
    "cartpend_state", 10,
    [this](const cartpend_msgs::msg::CartPendState::SharedPtr msg) {
      if(_controller_type == "PID") {
        // PID 제어기 계산
        double cart_out = _cart_pid->compute(msg->cart_pos);
        double pend_out = _pend_pid->compute(msg->pend_ang);
        voltage = cart_out + pend_out;
      } else if(_controller_type == "LQR") {
        // LQR 제어기 계산
        voltage = _lqr_controller->compute(msg->cart_pos, msg->pend_ang, msg->cart_vel, msg->pend_angvel);
      } else {
        RCLCPP_ERROR(this->get_logger(), "Unsupported controller type during state callback: %s", _controller_type.c_str());
        return;
      }
      // 전압 명령 제한
      if (voltage > _max_voltage) voltage = _max_voltage;
      if (voltage < -_max_voltage) voltage = -_max_voltage;

      // 전압 명령 퍼블리시
      auto voltage_msg = std_msgs::msg::Float64();
      voltage_msg.data = voltage;
      _volt_pub->publish(voltage_msg);
    });
    if(_state_sub == nullptr) {
      // 상태 서브스크립션 생성 실패 시 에러 반환
      RCLCPP_ERROR(this->get_logger(), "Failed to create state subscription");
      return -2;
    }
  return 0;
}

int ControlNode::_pause() {
  // 일시정지 함수
  // 서브스크립션 중지 및 퍼블리셔 비활성화

  // 상태 서브스크립션 중지
  _state_sub.reset();
  if(_state_sub != nullptr) {
    // 서브스크립션 중지 실패 시 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to reset state subscription");
    return -1;
  }

  // 전압 퍼블리셔 비활성화
  if(_volt_pub == nullptr) {
    // 비활성화에 앞서 퍼블리셔가 없는 경우 에러 반환
    // 이 경우는 거의 없겠지만 퍼블리셔가 없을 경우 뒤에 나오는 과정들이 모두 실패하므로 미리 체크
    RCLCPP_ERROR(this->get_logger(), "Voltage publisher is not initialized");
    return -2;
  }
  // 퍼블리셔 비활성화 전에 모터 정지를 위해 전압 명령을 0으로 퍼블리시
  auto volt = std_msgs::msg::Float64();
  volt.data = 0.0;
  _volt_pub->publish(volt);

  // 퍼블리셔 비활성화
  _volt_pub->on_deactivate();
  if(_volt_pub->is_activated()) {
    // 퍼블리셔 비활성화 실패 시 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to deactivate voltage publisher");
    return -3;
  }

  return 0;
}

int ControlNode::_reset() {
  if(_controller_type == "PID") {
    // PID 제어기 정리 함수
    if(_cart_pid) {
      _cart_pid->reset();
    }
    if(_pend_pid) {
      _pend_pid->reset();
    }
  } else if(_controller_type == "LQR") {
    // LQR 제어기 정리 함수
    if(_lqr_controller) {
      _lqr_controller->reset();
    }
  }
  return 0;
}

