#pragma once
#include <string>
#include "NIDAQmx.h"

/*
  NI DAQ에 사용할 인코더 설정 구조체 정의
  name : 인코더 채널 이름
  counter : NI DAQ에서 사용할 카운터 채널 이름
  encoding_type : 인코더 인코딩 타입 (X1, X2, X4) (default: DAQmx_Val_X1)
  zidx_enable : Z 인덱스 사용 여부 (default: FALSE)
  zidx_val : Z 인덱스 위치 값 (default: 0.0)
  zidx_phase : Z 인덱스 위상 (default: DAQmx_Val_AHighBHigh)
  units : 측정 단위 (default: 0)
  pulses_per_rev : 회전당 펄스 수 (로터리 인코더용) (default: 0)
  dist_per_pulse : 펄스당 거리 (리니어 인코더용) (default: 0.0)
  initial_pos : 초기 위치 값 (default: 0.0)
  custom_scale_name : 사용자 정의 스케일 이름
  chan_a : 인코더 채널 A의 물리적 입력 터미널 이름
  chan_b : 인코더 채널 B의 물리적 입력 터미널 이름
*/
typedef struct
{
  std::string name = "";
  std::string counter = "";
  int32 encoding_type = DAQmx_Val_X1; // DAQmx_Val_X1, DAQmx_Val_X2, DAQmx_Val_X4
  bool32 zidx_enable = FALSE;
  float64 zidx_val = 0.0;
  int32 zidx_phase = DAQmx_Val_AHighBHigh;
  int32 units = 0;
  uInt32 pulses_per_rev = 0;
  float64 dist_per_pulse = 0.0;
  float64 initial_pos = 0.0;
  std::string custom_scale_name = "";
  std::string chan_a = "";
  std::string chan_b = "";
} EncoderConfig;

// 외부에서 사용하기 위한 전역 변수 선언
// 프로그램에서 이 변수들은 단 하나만 존재
extern EncoderConfig rotenc_config;
extern EncoderConfig linenc_config;