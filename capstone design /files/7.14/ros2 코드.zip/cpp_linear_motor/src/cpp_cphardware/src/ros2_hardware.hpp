#pragma once
#include <thread>
#include <chrono>
#include <array>
#include <atomic>
#include <memory>
#include <chrono>
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_lifecycle/lifecycle_node.hpp"
#include "std_msgs/msg/float64.hpp"
#include "cartpend_msgs/msg/cart_pend_state.hpp"
#include "NIEncoder.hpp"
#include "EncoderConfig.hpp"

/*
  HardwareNode 클래스: ROS2 라이프사이클 노드로서 하드웨어 제어 및 상태 퍼블리싱 담당
  라이프사이클 노드 : 노드를 껐다 켰다 할 수 있는 기능 제공
  모터 제어 및 인코더 데이터 수집은 별도의 스레드에서 수행 (실시간성 보장을 위해)

  ROS2 파라미터 :
    - hardware_encoder_tick : 인코더 샘플링 주기 (초)
    - hardware_encoder_rate : 인코더 샘플링 속도 (Hz)
    - hardware_publish_tick : 상태 퍼블리시 주기 (초)
    - hardware_sample_size : 인코더 샘플링 크기 (한 번에 읽는 샘플 수), (publish_tick / encoder_tick)와 일치해야 함
  
  퍼블리셔 :
    - _state_pub : cartpend_msgs::msg::CartPendState 타입의 상태 메시지 퍼블리셔 (카트 위치, 진자 각도, 전압 명령 포함), ControlNode의 _state_sub과 매칭됨

  서브스크립션 :
    - _volt_sub : std_msgs::msg::Float64 타입의 전압 명령 서브스크립션, ControlNode의 _volt_pub과 매칭됨

  메시지 전달 흐름 :
    HardwareNode                                  ControlNode 
    (_state_pub)    -----(CartPendState)----->    (_state_sub)
    (_volt_sub)     <--------(Float64)--------    (_volt_pub)

  _update_params()를 사용하는 이유 :
    유저가 별도의 컴파일 과정 없이 실행 중에도 파라미터들을 변경할 수 있도록 하기 위함
    파라미터들을 하드코딩할 경우 속도는 빠르겠지만, 파라미터 수정할 때마다 재컴파일 필요
    유저가 설정한 파라미터를 런타임 중에 받아오기 위해, HardwareNode와 ControlNode의 _update_params() 함수를 사용
*/
class HardwareNode : public rclcpp_lifecycle::LifecycleNode {
  public:
    HardwareNode(const std::string &node_name);
    ~HardwareNode();

    // Lifecycle 노드 콜백 함수
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_configure(const rclcpp_lifecycle::State& state) override;
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_activate(const rclcpp_lifecycle::State& state) override;
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_deactivate(const rclcpp_lifecycle::State& state) override;
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_cleanup(const rclcpp_lifecycle::State& state) override;
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_shutdown(const rclcpp_lifecycle::State& state) override;

  private:
    int _update_params();               // 파라미터 업데이터 함수  
    int _init();                        // 초기화 함수
    int _start();                       // 시작 함수                    
    int _pause();                       // 일시정지 함수       
    int _reset();                       // 리셋 함수     
    void _hardware_loop();              // 하드웨어 루프 함수   
    bool _check(int32 err_code, const char* ctx, rclcpp::Logger logger);  // 에러 체크 함수
    int _home_position();               // 영점 복귀 함수
    int _home_init();                   // 영점 설정 함수
    double _barrier(double position, double voltage);                  // 리니어모터 경계 안전을 위한 함수
    double _regulate_angle(double angle);                               // 진자 각도 -180~180도로 조절하는 함수
    bool _need_reset = false;           // 리셋이 필요한지 알려주는 변수
    bool _need_home = false;            // 홈 위치 설정이 필요한지 알려주는 변수
    bool _need_init = false;            // 초기화가 필요한지 알려주는 변수
    std::atomic<bool> _is_conflict = false;          // barrier 구간에서 충돌이 발생했는지 알려주는 변수
       
    std::atomic<bool> _running{false};          // 하드웨어 루프가 실행중인지 알려주는 변수
    std::atomic<double> _voltage{0.0};          // 전압 명령
    std::unique_ptr<RotaryEncoder> _rotenc;     // 로터리 인코더 포인터
    std::array<float64, 100> _rotenc_buffer{};  // 로터리 인코더 버퍼
    std::unique_ptr<LinearEncoder> _linenc;     // 리니어 인코더 포인터
    std::array<float64, 100> _linenc_buffer{};  // 리니어 인코더 버퍼

    rclcpp_lifecycle::LifecyclePublisher<cartpend_msgs::msg::CartPendState>::SharedPtr _state_pub;  // 상태(카트 위치, 진자 각도) 퍼블리셔(LifecyclePublisher)
    rclcpp_lifecycle::LifecyclePublisher<cartpend_msgs::msg::CartPendState>::SharedPtr _cli_pub;    // 같은 데이터를 client로 퍼블리시하기 위한 퍼블리셔
    rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr _volt_sub;                              // 전압 명령 서브스크립션
    rclcpp::Subscription<std_msgs::msg::Float64>::SharedPtr _home_pos_sub;                          // 홈 위치 서브스크립션
    rclcpp::TimerBase::SharedPtr _home_timer;                                                       // 홈 위치 타이머

    double _publish_tick;   // 퍼블리시 주기
    double _encoder_tick;   // 인코딩 주기 (1/_encoder_rate)
    double _encoder_rate;   // 초당 인코딩 수 (1/_encoder_tick)
    size_t _cli_timer;      // 몇 번의 hardware loop를 돌아야 _cli_pub가 동작하는지 알려주는 변수
    int _sample_size;       // 샘플링 크기
    double _start_pos = 0;  // 루프 시작 시점의 리니어 인코더 위치
    
    TaskHandle _hw_clock = nullptr;           // 하드웨어 클럭 핸들
    TaskHandle _linear_motor = nullptr;       // 리니어 모터 핸들
    const float64 _linear_motor_max = 10.0;   // 리니어 모터 최대 전압

    std::thread _hardware_worker;             // 하드웨어 루프 스레드(멀티스레드 구현용)

    const std::string _hw_clock_name = "HW_clock";
    const std::string _hw_clock_channel = "/Dev1/ai/SampleClock";
    const std::string _hw_clock_input = "Dev1/ai0";
    const std::string _hw_clock_output = "Dev1/ao0";
    const std::string _task_name = "LinearMotor";
};