#include "ros2_hardware.hpp"

int main(int argc, char** argv) {
  // ROS2 노드 초기화 및 실행
  rclcpp::init(argc, argv);
  auto node = std::make_shared<HardwareNode>("hardware_node");
  rclcpp::spin(node->get_node_base_interface());
  rclcpp::shutdown();
  return 0;
}

HardwareNode::HardwareNode(const std::string &node_name)
: LifecycleNode(node_name) {
  // ROS2 파라미터 선언
  declare_parameter<double>("encoder_tick", 0.001);
  declare_parameter<double>("encoder_rate", 1000.0);
  declare_parameter<double>("publish_tick", 0.005);
  declare_parameter<int>("sample_size", 5);
  declare_parameter<int>("cli_timer", 10);  // per one loop
  // 카트 진자 상태 퍼블리셔 생성
  rclcpp::QoS qos_profile(10);
  qos_profile.reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  _state_pub = this->create_publisher<cartpend_msgs::msg::CartPendState>("cartpend_state", qos_profile);
  _cli_pub = this->create_publisher<cartpend_msgs::msg::CartPendState>("current_state", qos_profile);
  _home_pos_sub = this->create_subscription<std_msgs::msg::Float64>(
    "home_position",
    10,
    [this](const std_msgs::msg::Float64::SharedPtr msg) {
      if(msg->data > 0) {
        _need_home = true;
      } else {
        _need_init = true;
      }
    }
  );
  _home_timer = this->create_timer(
    std::chrono::milliseconds(500),
    [this]() {
      if(_need_home) {
        int ret = _home_position();
        if(ret == 0) {
          RCLCPP_INFO(this->get_logger(), "Home position set successfully.");
        } else {
          RCLCPP_ERROR(this->get_logger(), "Failed to set home position, error code: %d", ret);
        }
        _need_home = false;
      } else if(_need_init) {
        int ret = _home_init();
        if(ret == 0) {
          RCLCPP_INFO(this->get_logger(), "Hardware reset successfully.");
        } else {
          RCLCPP_ERROR(this->get_logger(), "Failed to reset hardware, error code: %d", ret);
        }
        _need_init = false;
      }
    }
  );

  RCLCPP_INFO(this->get_logger(), "Hardware status: created.");
}

HardwareNode::~HardwareNode() {
  // 하드웨어 루프 종료
  if(_running.load()) {
    _running.store(false);
    if(_hardware_worker.joinable()) {
      _hardware_worker.join();
    }
  }
  // 하드웨어 타이머 종료
  if(_hw_clock) {
    DAQmxStopTask(_hw_clock);
    DAQmxClearTask(_hw_clock);
    _hw_clock = nullptr;
  }

  // 리니어 모터 태스크 종료
  if(_linear_motor) {
    DAQmxStopTask(_linear_motor);
    DAQmxClearTask(_linear_motor);
    _linear_motor = nullptr;
  }
  // 퍼블리셔 및 서브스크립션 해제
  if(_volt_sub) _volt_sub.reset();
  if(_state_pub) _state_pub.reset();
  if(_cli_pub) _cli_pub.reset();

  // 인코더 객체 종료
  if(_rotenc) {
    _rotenc->stop();
    _rotenc.reset();
  }
  if(_linenc) {
    _linenc->stop();
    _linenc.reset();
  }
  RCLCPP_INFO(this->get_logger(), "Hardware status: terminated.");
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
HardwareNode::on_configure(const rclcpp_lifecycle::State& state) {
  // unconfigured -> inactive
  // 에러 체크
  if(_need_reset && _reset() != 0) {
    // 리셋에 실패한 경우 FAILURE 반환
    RCLCPP_ERROR(this->get_logger(), "Hardware status: reset failed during configuration");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
  }
  // 파라미터 업데이트 후 초기화
  if(_update_params() == 0 && _init() == 0) {
    // 파라미터 업데이트나 초기화에 성공한 경우 SUCCESS 반환
    RCLCPP_INFO(this->get_logger(), "Hardware status: configuring -> inactive");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  } else {
    // 파라미터 업데이트나 초기화에 실패한 경우 FAILURE 반환
    RCLCPP_ERROR(this->get_logger(), "Hardware status: configuring -> inactive failed");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
  }
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
HardwareNode::on_activate(const rclcpp_lifecycle::State& state) {
  // inactive -> active
  // 하드웨어 시작
  if(_start() == 0) {
    // 하드웨어 시작에 성공한 경우 SUCCESS 반환
    RCLCPP_INFO(this->get_logger(), "Hardware status: inactive -> active");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  } else {
    // 하드웨어 시작에 실패한 경우 FAILURE 반환
    RCLCPP_ERROR(this->get_logger(), "Hardware status: inactive -> active failed");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
  }
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
HardwareNode::on_deactivate(const rclcpp_lifecycle::State& state) {
  // active -> inactive
  // 하드웨어 일시 정지
  if(_pause() == 0) {
    // 일시 정지에 성공한 경우 SUCCESS 반환
    RCLCPP_INFO(this->get_logger(), "Hardware status: active -> inactive");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  } else {
    // 일시 정지에 실패한 경우 FAILURE 반환
    RCLCPP_ERROR(this->get_logger(), "Hardware status: active -> inactive failed");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
  }
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
HardwareNode::on_cleanup(const rclcpp_lifecycle::State& state) {
  // inactive -> unconfigured
  // 하드웨어 리셋
  if(_reset() == 0) {
    // 리셋에 성공한 경우 SUCCESS 반환
    RCLCPP_INFO(this->get_logger(), "Hardware status: inactive -> unconfigured");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  } else {
    // 리셋에 실패한 경우 FAILURE 반환
    RCLCPP_ERROR(this->get_logger(), "Hardware status: inactive -> unconfigured failed");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
  }
}

rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn
HardwareNode::on_shutdown(const rclcpp_lifecycle::State& state) {
  // any state -> shutdown
  // 하드웨어 일시 정지 및 리셋
  if(_pause() == 0 && _reset() == 0) {
    // 일시 정지 및 리셋에 성공한 경우 SUCCESS 반환
    RCLCPP_INFO(this->get_logger(), "Hardware status: shutting down");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::SUCCESS;
  } else {
    // 일시 정지 및 리셋에 실패한 경우 FAILURE 반환
    RCLCPP_ERROR(this->get_logger(), "Hardware status: shutting down failed");
    return rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn::FAILURE;
  }
}

int HardwareNode::_update_params() {
  // 파라미터 업데이트 함수
  // client에서 ROS2 파라미터를 설정하면 이를 클래스 멤버 변수에 반영
  // 왜 이렇게 만들었는지는 ros2_hardware.hpp 파일의 주석 참고
  try {
    // ROS2에서 파라미터 가져오기를 시도
    _encoder_tick = this->get_parameter("encoder_tick").as_double();
    _encoder_rate = this->get_parameter("encoder_rate").as_double();
    _publish_tick = this->get_parameter("publish_tick").as_double();
    _sample_size = this->get_parameter("sample_size").as_int();
    _cli_timer = static_cast<size_t>(this->get_parameter("cli_timer").as_int());
  } catch(const rclcpp::exceptions::ParameterNotDeclaredException &e) {
    // 파라미터가 선언되지 않은 경우 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Parameter not declared: %s", e.what());
    return -1;
  } catch(const std::exception &e) {
    // 기타 예외 발생 시 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Error getting parameters: %s", e.what());
    return -2;
  }
  RCLCPP_INFO(this->get_logger(), "Hardware parameters updated:");
  return 0;
}

int HardwareNode::_init() {
  _need_reset = true;
  // 하드웨어 클럭 및 리니어 모터 작업 생성
  DAQmxCreateTask(_hw_clock_name.c_str(), &_hw_clock);
  DAQmxCreateAIVoltageChan(_hw_clock, _hw_clock_input.c_str(), _hw_clock_name.c_str(), DAQmx_Val_RSE, -_linear_motor_max, _linear_motor_max, DAQmx_Val_Volts, NULL);
  DAQmxCfgSampClkTiming(_hw_clock, "", _encoder_rate, DAQmx_Val_Rising, DAQmx_Val_ContSamps, 1000);
  
  DAQmxCreateTask(_task_name.c_str(), &_linear_motor);
  DAQmxCreateAOVoltageChan(_linear_motor, _hw_clock_output.c_str(), _task_name.c_str(), -_linear_motor_max, _linear_motor_max, DAQmx_Val_Volts, NULL);
  DAQmxCfgSampClkTiming(_linear_motor, _hw_clock_channel.c_str(), _encoder_rate, DAQmx_Val_Rising, DAQmx_Val_ContSamps, 1000);
  DAQmxSetWriteRegenMode(_linear_motor, DAQmx_Val_DoNotAllowRegen);

  // 인코더 객체 생성
  _rotenc = std::make_unique<RotaryEncoder>(rotenc_config);
  _linenc = std::make_unique<LinearEncoder>(linenc_config);
  if(_rotenc == nullptr || _linenc == nullptr) {
    // 만약 인코더 객체 생성에 실패한 경우 에러 반환
    char buf[4096];
    DAQmxGetExtendedErrorInfo(buf, 4096);
    RCLCPP_ERROR(this->get_logger(), "Failed to create encoder objects: %s", buf);
    return -1;
  }

  // 로터리 인코더 태스크 생성
  int err_code = _rotenc->init(_hw_clock_channel.c_str(), _encoder_rate, DAQmx_Val_Rising, DAQmx_Val_ContSamps, (uInt64)_rotenc_buffer.size());
  if(err_code < 0) {
    // 로터리 인코더 태스크 생성에 실패한 경우 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to configure rotary encoder: %d", err_code);
    return -2;
  }

  // 리니어 인코더 태스크 생성
  err_code = _linenc->init(_hw_clock_channel.c_str(), _encoder_rate, DAQmx_Val_Rising, DAQmx_Val_ContSamps, (uInt64)_linenc_buffer.size());
  if(err_code < 0) {
    // 리니어 인코더 태스크 생성에 실패한 경우 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to configure linear encoder: %d", err_code);
    return -3;
  }

  // 하드웨어 타이머 시작
  bool err = _check(DAQmxStartTask(_hw_clock), "Starting hardware clock", this->get_logger());
  if(!err) {
    // 하드웨어 타이머 시작에 실패한 경우 에러 반환
    char buf[4096];
    DAQmxGetExtendedErrorInfo(buf, 4096);
    RCLCPP_ERROR(this->get_logger(), "Failed to start hardware clock: %s", buf);
    return -4;
  }

  // 리니어 모터 태스크 시작
  err = _check(DAQmxStartTask(_linear_motor), "Starting linear motor task", this->get_logger());
  if(!err) {
    // 리니어 모터 태스크 시작에 실패한 경우 에러 반환
    char buf[4096];
    DAQmxGetExtendedErrorInfo(buf, 4096);
    RCLCPP_ERROR(this->get_logger(), "Failed to start linear motor task: %s", buf);
    return -5;
  }

  return 0;
}

int HardwareNode::_start() {
  // 상태(카트 위치, 진자 각도)퍼블리셔 활성화
  _state_pub->on_activate();
  _cli_pub->on_activate();
  // 전압 명령을 구독하는 서브스크립션 생성
  _volt_sub = this->create_subscription<std_msgs::msg::Float64>("voltage_command", 10, [this](const std_msgs::msg::Float64 &msg) {_voltage.store(msg.data, std::memory_order_relaxed);});

  // 에러 체크
  if(!_state_pub->is_activated()) {
    // 상태 퍼블리셔 활성화에 실패한 경우 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to activate state publisher");
    return -1;
  }
  if(!_cli_pub->is_activated()) {
    RCLCPP_ERROR(this->get_logger(), "Failed to activate cli publisher");
    return -2;
  }
  if(_volt_sub == nullptr) {
    // 전압 명령 서브스크립션 생성에 실패한 경우 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to create voltage command subscription");
    return -3;
  }
  if(_rotenc->start() < 0) {
    // 로터리 인코더 태스크 시작에 실패한 경우 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to start rotary encoder task");
    return -4;
  }
  if(_linenc->start() < 0) {
    // 리니어 인코더 태스크 시작에 실패한 경우 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to start linear encoder task");
    return -5;
  }

  // 하드웨어 루프 시작
  _running.store(true);   // _running이라는 변수에 true 저장
  // 하드웨어 루프는 별도의 스레드에서 실행
  _hardware_worker = std::thread(&HardwareNode::_hardware_loop, this);  // _hardware_loop 라는 함수를 별도의 스레드에서 실행
  if(!_hardware_worker.joinable()) {
    // 하드웨어 루프가 제대로 시작되지 않은 경우 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to start hardware thread");
    return -4;
  }
  return 0;
}

int HardwareNode::_pause() {
  // 하드웨어 루프 종료
  _running.store(false);    // _running이라는 변수에 false 저장
  if(_hardware_worker.joinable()) {
    try {
      // 하드웨어 루프 스레드가 실행중이라면 종료
      _hardware_worker.join();
    } catch (const std::system_error &e) {
      // 스레드 종료에 실패한 경우 에러 반환
      RCLCPP_ERROR(this->get_logger(), "Error joining hardware thread: %s", e.what());
      return -1;
    }
  }

  _volt_sub.reset();              // 전압 명령 서브스크립션 해제
  _state_pub->on_deactivate();    // 상태 퍼블리셔 비활성화
  _cli_pub->on_deactivate();      // cli 퍼블리셔 비활성화
  // 에러 체크
  if(_state_pub->is_activated()) {
    // 상태 퍼블리셔 비활성화에 실패한 경우 에러 반환
    // 전압 명령 서브스크립션 해제는 치명적인 에러가 아니므로 체크하지 않음
    RCLCPP_ERROR(this->get_logger(), "Failed to deactivate state publisher");
    return -2;
  }

  if(_rotenc != nullptr) _rotenc->stop();
  if(_linenc != nullptr) _linenc->stop();

  // 리니어모터 전압 0으로 설정
  if(!_check(DAQmxWriteAnalogScalarF64(_linear_motor, 1, 10.0, 0, NULL), "Writing zero voltage to Linear Motor", this->get_logger())) return -3;
  return 0;
}

int HardwareNode::_reset() {
  // 인코더 및 하드웨어 태스크 정지 및 해제
  bool err;
  if(_hw_clock) {
    // 하드웨어 타이머 정지, 실패하면 에러 반환
    err = _check(DAQmxStopTask(_hw_clock), "Stopping hardware clock", this->get_logger());
    if(!err) return -1;
    DAQmxClearTask(_hw_clock);
    _hw_clock = nullptr;
  }
  if(_linear_motor) {
    // 리니어 모터 태스크 정지, 실패하면 에러 반환
    err = _check(DAQmxStopTask(_linear_motor), "Stopping linear motor task", this->get_logger());
    if(!err) return -2;
    DAQmxClearTask(_linear_motor);
    _linear_motor = nullptr;
  }

  // 인코더 객체 정지 및 해제
  if(_rotenc != nullptr) _rotenc.reset();
  if(_linenc != nullptr) _linenc.reset();
  if(_rotenc != nullptr || _linenc != nullptr) {
    // 인코더 객체 해제에 실패한 경우 에러 반환
    RCLCPP_ERROR(this->get_logger(), "Failed to reset encoder objects");
    return -3;
  }
  _need_reset = false;
  return 0;
}

void HardwareNode::_hardware_loop() {
  // 하드웨어 루프 함수
  size_t timer = 0;
  auto start_time = std::chrono::steady_clock::now();
  RCLCPP_INFO(this->get_logger(), "Hardware loop started");

  // client로 0초 상태 전송

  double angle = 0.0;
  double position = _start_pos;
  double _prev_angle = angle;
  double _prev_position = position;

  auto state_msg = cartpend_msgs::msg::CartPendState();
  state_msg.pend_ang = angle;
  state_msg.cart_pos = position;
  state_msg.time = 0.0;
  state_msg.volt = 0;
  _cli_pub->publish(state_msg);
  
  while(_running.load()) {
    // _running이 true이면 루프 반복
    timer++;
    int32 rot_samps_read = _rotenc->read_data(_rotenc_buffer, _sample_size);
    int32 lin_samps_read = _linenc->read_data(_linenc_buffer, _sample_size);
    
    if(rot_samps_read <= 0 || lin_samps_read <= 0) {
      continue;  // 읽은 샘플이 없으면 다음 루프로
    } else {
      angle = _rotenc_buffer[rot_samps_read - 1];
      angle = _regulate_angle(angle);
      position = -_linenc_buffer[lin_samps_read - 1] + _start_pos;  // 방향을 맞추기 위해 음수 부호 추가
    }

    // _voltage에 저장된 전압 명령 불러오기
    double voltage = _barrier(position, _voltage.load(std::memory_order_relaxed));
    if(_is_conflict.load()) {
      RCLCPP_WARN(this->get_logger(), "Barrier conflict at position: %.4f, voltage command adjusted to: %.2f", position, voltage);
      _is_conflict.store(false);
    }

    // 상태 퍼블리시
    auto state_msg = cartpend_msgs::msg::CartPendState();
    state_msg.pend_ang = angle;
    state_msg.cart_pos = position;
    state_msg.cart_vel = (position - _prev_position) / (_publish_tick);
    state_msg.pend_angvel = (angle - _prev_angle) / (_publish_tick);
    _prev_angle = angle;
    _prev_position = position;
    state_msg.time = _publish_tick * timer;
    state_msg.volt = voltage;
    _state_pub->publish(state_msg);

    // client에 상태 퍼블리시
    if(timer % _cli_timer == 0) {
      _cli_pub->publish(state_msg);
    }
    // 리니어모터에 전압 명령 전송
    float64 output_array[_sample_size] = {0.0};
    for(int i = 0; i < _sample_size; i++) {
      output_array[i] = voltage;
    }
    DAQmxWriteAnalogF64(_linear_motor, _sample_size, FALSE, 10.0, DAQmx_Val_GroupByChannel, output_array, NULL, NULL);
  }
  _start_pos = position;
  RCLCPP_INFO(this->get_logger(), "Hardware loop stopped. Elapsed time: %.3f seconds", std::chrono::duration<double>(std::chrono::steady_clock::now() - start_time).count());
}

bool HardwareNode::_check(int32 err_code, const char* ctx, rclcpp::Logger logger) {
  // 에러 코드 체크 함수
  if(err_code < 0) {
    char buf[4096];
    DAQmxGetExtendedErrorInfo(buf, sizeof(buf));
    RCLCPP_ERROR(logger, "[%d] Error in %s: %s", err_code, ctx, buf);
    return false;
  }
  if(err_code > 0) {
    RCLCPP_WARN(logger, "[%d] Warning in %s", err_code, ctx);
  }
  return true;
}

int HardwareNode::_home_init() {
  if(_need_reset) {
    RCLCPP_ERROR(this->get_logger(), "Cannot home position before reset.");
    return -1;
  }
  if(_update_params() != 0) {
    RCLCPP_ERROR(this->get_logger(), "Failed to update parameters before homing.");
    return -2;
  }
  if(_init() != 0) {
    RCLCPP_ERROR(this->get_logger(), "Failed to initialize hardware before homing.");
    return -3;
  }

  // 초기에 우측 끝까지 이동
  int count = 0;
  double kp = 8.0;
  double ki = 1.0;
  double kd = 5.0;
  double integral = 0.0;
  double previous_error = 0.0;
  double target_position = 2;
  bool reached = false;
  int reached_count = 0;
  _linenc->start();
  while(count++ < 4000) {
    int32 lin_samps_read = _linenc->read_data(_linenc_buffer, 5);
    if(lin_samps_read > 0) {
      double position = -_linenc_buffer[lin_samps_read - 1];
      double error = target_position - position;
      integral += error * _encoder_tick * 5;
      double derivative = (error - previous_error) / (_encoder_tick * 5);
      double control_signal = kp * error + ki * integral + kd * derivative;
      if(control_signal > 1) control_signal = 1;
      if(control_signal < -1) control_signal = -1;
      const float64 control_array[5] = {control_signal, control_signal, control_signal, control_signal, control_signal};
      DAQmxWriteAnalogF64(_linear_motor, 5, FALSE, 10.0, DAQmx_Val_GroupByChannel, control_array, NULL, NULL);
      if(count > 200 && abs(derivative) < 0.01) {
        //RCLCPP_INFO(this->get_logger(), "Error diff: %.4f", abs(derivative)*(_encoder_tick*5));
        reached_count++;
        if(reached_count >= 200) {
          reached = true;
          break;  // 목표 위치에 도달했으면 종료
        }
      } else {
        reached_count = 0;
      }
      previous_error = error;
    }
  }
  _linenc->stop();
  const float64 stop_array[5] = {0.0, 0.0, 0.0, 0.0, 0.0};
  DAQmxWriteAnalogF64(_linear_motor, 5, FALSE, 10.0, DAQmx_Val_GroupByChannel, stop_array, NULL, NULL);
  if(!reached) {
    RCLCPP_ERROR(this->get_logger(), "Failed to reach the right end.");
    _reset();
    return -4;
  }
  
  count = 0;
  integral = 0.0;
  previous_error = 0.0;
  target_position = -0.5;
  reached = false;
  reached_count = 0;
  _linenc->start();
  while(count++ < 4000) {
    int32 lin_samps_read = _linenc->read_data(_linenc_buffer, 5);
    if(lin_samps_read > 0) {
      double position = -_linenc_buffer[lin_samps_read - 1];
      double error = target_position - position;
      integral += error * _encoder_tick * 5;
      double derivative = (error - previous_error) / (_encoder_tick * 5);
      double control_signal = kp * error + ki * integral + kd * derivative;
      if(control_signal > 5) control_signal = 5;
      if(control_signal < -5) control_signal = -5;
      const float64 control_array[5] = {control_signal, control_signal, control_signal, control_signal, control_signal};
      DAQmxWriteAnalogF64(_linear_motor, 5, FALSE, 10.0, DAQmx_Val_GroupByChannel, control_array, NULL, NULL);
      previous_error = error;
      if(abs(error) < 0.02) {
        //RCLCPP_INFO(this->get_logger(), "Count: %d, Position error: %.4f", reached_count, abs(error));
        reached_count++;
        if(reached_count >= 200) {
          reached = true;
          break;  // 목표 위치에 도달했으면 종료
        }
      } else {
        reached_count = 0;
      }
    }
  }
  _linenc->stop();
  
  // 모터 정지
  DAQmxWriteAnalogF64(_linear_motor, 5, FALSE, 10.0, DAQmx_Val_GroupByChannel, stop_array, NULL, NULL);
  if (!reached) {
    RCLCPP_ERROR(this->get_logger(), "Failed to home the cart.");
    _reset();
    return -5;
  }
  if(_reset() != 0) {
    RCLCPP_ERROR(this->get_logger(), "Failed to reset hardware after homing.");
    return -6;
  }

  _start_pos = 0.0;
  RCLCPP_INFO(this->get_logger(), "Homing successful. Current position set to zero.");
  return 0;
}

int HardwareNode::_home_position() {
  if(_need_reset) {
    RCLCPP_ERROR(this->get_logger(), "Cannot home position before reset.");
    return -1;
  }
  if(_update_params() != 0) {
    RCLCPP_ERROR(this->get_logger(), "Failed to update parameters before homing.");
    return -2;
  }
  if(_init() != 0) {
    RCLCPP_ERROR(this->get_logger(), "Failed to initialize hardware before homing.");
    return -3;
  }

  // 초기에 우측 끝까지 이동
  int count = 0;
  double kp = 8.0;
  double ki = 1.0;
  double kd = 5.0;
  double integral = 0.0;
  double previous_error = 0.0;
  double target_position = 0.0;
  bool reached = false;
  int reached_count = 0;
  double position = 0.0;
  _linenc->start();
  while(count++ < 4000) {
    int32 lin_samps_read = _linenc->read_data(_linenc_buffer, 5);
    if(lin_samps_read > 0) {
      position = -_linenc_buffer[lin_samps_read - 1];
      double error = target_position - position;
      integral += error * _encoder_tick * 5;
      double derivative = (error - previous_error) / (_encoder_tick * 5);
      double control_signal = kp * error + ki * integral + kd * derivative;
      if(control_signal > 5) control_signal = 5;
      if(control_signal < -5) control_signal = -5;
      const float64 control_array[5] = {control_signal, control_signal, control_signal, control_signal, control_signal};
      DAQmxWriteAnalogF64(_linear_motor, 5, FALSE, 10.0, DAQmx_Val_GroupByChannel, control_array, NULL, NULL);
      previous_error = error;
      if(abs(error) < 0.02) {
        //RCLCPP_INFO(this->get_logger(), "Count: %d, Position error: %.4f", reached_count, abs(error));
        reached_count++;
        if(reached_count >= 200) {
          reached = true;
          break;  // 목표 위치에 도달했으면 종료
        }
      } else {
        reached_count = 0;
      }
    }
  }
  _linenc->stop();
  
  // 모터 정지
  const float64 stop_array[5] = {0.0, 0.0, 0.0, 0.0, 0.0};
  DAQmxWriteAnalogF64(_linear_motor, 5, FALSE, 10.0, DAQmx_Val_GroupByChannel, stop_array, NULL, NULL);
  if (!reached) {
    RCLCPP_ERROR(this->get_logger(), "Failed to home the cart.");
    _reset();
    return -5;
  }
  if(_reset() != 0) {
    RCLCPP_ERROR(this->get_logger(), "Failed to reset hardware after homing.");
    return -6;
  }

  _start_pos = position;
  RCLCPP_INFO(this->get_logger(), "Homing successful. Current position set to zero.");
  return 0;
}

double HardwareNode::_barrier(double position, double voltage) {
  double boundary = 0.35;
  double margin = 0.10;
  if(position >= boundary && position < boundary + margin && voltage > 0) {
    _is_conflict.store(true);
    return -(position - boundary)*100.0;
  } else if(position <= -boundary && position > -boundary - margin && voltage < 0) {
    _is_conflict.store(true);
    return (-position - boundary)*100.0;
  } else if(position >= boundary + margin && voltage > 0) {
    _is_conflict.store(true);
    return -10;
  } else if(position <= -boundary - margin && voltage < 0) {
    _is_conflict.store(true);
    return 10;
  } else {
    return voltage;
  }
}

double HardwareNode::_regulate_angle(double angle) {
  while(angle > 180.0) {
    angle -= 360.0;
  }
  while(angle <= -180.0) {
    angle += 360.0;
  }
  return angle;
}