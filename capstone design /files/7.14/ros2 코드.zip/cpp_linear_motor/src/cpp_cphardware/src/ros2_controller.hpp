#pragma once
#include <thread>
#include "rclcpp/rclcpp.hpp"
#include "rclcpp_lifecycle/lifecycle_node.hpp"
#include "std_msgs/msg/float64.hpp"
#include "cartpend_msgs/msg/cart_pend_state.hpp"
#include "Controller.hpp"

/*
  ControlNode 클래스: ROS2 라이프사이클 노드로서 제어 알고리즘 구현 및 전압 명령 퍼블리싱 담당
  라이프사이클 노드 : 노드를 껐다 켰다 할 수 있는 기능 제공

  ROS2 파라미터 :
    - control_cart_p : 카트 위치 PID 제어기의 비례 이득
    - control_cart_i : 카트 위치 PID 제어기의 적분 이득
    - control_cart_d : 카트 위치 PID 제어기의 미분 이득
    - control_pend_p : 진자 각도 PID 제어기의 비례 이득
    - control_pend_i : 진자 각도 PID 제어기의 적분 이득
    - control_pend_d : 진자 각도 PID 제어기의 미분 이득
    - control_dt : 제어 루프의 시간 간격 (초)
    - control_target_cart_pos : 목표 카트 위치 (미터)
    - control_target_pend_ang : 목표 진자 각도 (라디안)
  
  퍼블리셔 :
    - _volt_pub : std_msgs::msg::Float64 타입의 전압 명령 퍼블리셔
    - _cli_pub : cartpend_msgs::msg::CartPendState 타입의 상태 퍼블리셔

  서브스크립션 :
    - _state_sub : cartpend_msgs::msg::CartPendState 타입의 상태 메시지 서브스크립션

  메시지 전달 흐름 :
    HardwareNode                                  ControlNode 
    (_state_pub)    -----(CartPendState)----->    (_state_sub)
    (_volt_sub)     <--------(Float64)--------    (_volt_pub)

  _update_params()를 사용하는 이유 :
    유저가 별도의 컴파일 과정 없이 실행 중에도 파라미터들을 변경할 수 있도록 하기 위함
    파라미터들을 하드코딩할 경우 속도는 빠르겠지만, 파라미터 수정할 때마다 재컴파일 필요
    유저가 설정한 파라미터를 런타임 중에 받아오기 위해, HardwareNode와 ControlNode의 _update_params() 함수를 사용
*/

typedef struct {
  double kp = 0.0;
  double ki = 0.0;
  double kd = 0.0;
  double alpha = 0.1; // 미분 필터링 상수
} PIDParams;

class ControlNode : public rclcpp_lifecycle::LifecycleNode {
  public:
    ControlNode(const std::string& node_name);
    ~ControlNode();
    
    // Lifecycle 노드 콜백 함수
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_configure(const rclcpp_lifecycle::State& state) override;
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_activate(const rclcpp_lifecycle::State& state) override;
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_deactivate(const rclcpp_lifecycle::State& state) override;
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_cleanup(const rclcpp_lifecycle::State& state) override;
    rclcpp_lifecycle::node_interfaces::LifecycleNodeInterface::CallbackReturn on_shutdown(const rclcpp_lifecycle::State& state) override;

    double voltage; // 퍼블리시할 전압 명령 변수

    private:
      int _update_params();   // 파라미터 업데이터 함수
      int _init();            // 초기화 함수 
      int _start();           // 시작 함수
      int _pause();           // 일시정지 함수
      int _reset();           // 리셋 함수

      rclcpp_lifecycle::LifecyclePublisher<std_msgs::msg::Float64>::SharedPtr _volt_pub;            // 전압 명령 퍼블리셔
      rclcpp::Subscription<cartpend_msgs::msg::CartPendState>::SharedPtr _state_sub;                // 상태 서브스크립션
      std::unique_ptr<PIDController> _cart_pid;   // 카트 위치 PID 제어기
      std::unique_ptr<PIDController> _pend_pid;   // 진자 각도 PID 제어기
      std::unique_ptr<LQRController> _lqr_controller; // LQR 제어기

      double _dt = 0.005;           // 제어 루프 시간 간격
      double _max_voltage = 10.0;   // 최대 전압 명령
      
      std::string _controller_type; // 제어기 타입
      PIDParams _pid_cart_params;   // 카트 위치 PID 파라미터
      PIDParams _pid_pend_params;   // 진자 각도 PID 파라미터
      std::array<double, 4> _lqr_K; // LQR 상태 피드백 이득 행렬
      double _lqr_alpha = 0.1;      // 미분 필터링 상수

      double _target_cart_pos = 0.0; // 목표 카트 위치
      double _target_pend_ang = 0.0; // 목표 진자 각도
};