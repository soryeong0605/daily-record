#include "Controller.hpp"

double PIDController::impl_compute(double current) {
  // Compute PID output
  double error = _target - current;
  
  // Derivative with filtering
  double d_raw = (error - _prev_error)/_dt;
  double d_filtered = _alpha * d_raw + (1 - _alpha) * _prev_filtered;
  
  // Anti-windup for integral term
  bool at_upper_limit = (_limit > 0.0) && ((_prev_output >= _limit) && (error > 0));
  bool at_lower_limit = (_limit > 0.0) && ((_prev_output <= -_limit) && (error < 0));
  if(!(at_upper_limit || at_lower_limit)) {
    _integral += error*_dt;
  }

  double output = _kp*error + _ki*_integral + _kd*d_filtered;

  _prev_error = error;
  _prev_filtered = d_filtered;
  _prev_output = output;
  return output;
}

double LQRController::impl_compute(double cart_pos, double pend_ang, double cart_vel, double pend_angvel) {
  double error_pos = _target_pos - cart_pos;
  double error_ang = _target_ang - pend_ang;
  double vel_filtered = _alpha * cart_vel + (1 - _alpha) * _prev_vel_filtered;
  double angvel_filtered = _alpha * pend_angvel + (1 - _alpha) * _prev_angvel_filtered;
  double output = _K[0]*error_pos + _K[1]*error_ang + _K[2]*vel_filtered + _K[3]*angvel_filtered;
  _prev_vel_filtered = vel_filtered;
  _prev_angvel_filtered = angvel_filtered;
  return output;
}