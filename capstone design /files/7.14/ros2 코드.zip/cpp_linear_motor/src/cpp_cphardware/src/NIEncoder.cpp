#include "NIEncoder.hpp"


bool RotaryEncoder::create_channel() {
  int err = DAQmxCreateCIAngEncoderChan
    (
      _taskhandle, _config.counter.c_str(), _config.name.c_str(),
      _config.encoding_type, _config.zidx_enable, _config.zidx_val, _config.zidx_phase,
      _config.units, _config.pulses_per_rev, _config.initial_pos, _config.custom_scale_name.c_str()
    );
  if (err < 0) return false;
  return true;
}

bool LinearEncoder::create_channel() {
  int err = DAQmxCreateCILinEncoderChan
    (
      _taskhandle, _config.counter.c_str(), _config.name.c_str(),
      _config.encoding_type, _config.zidx_enable, _config.zidx_val, _config.zidx_phase,
      _config.units, _config.dist_per_pulse, _config.initial_pos, _config.custom_scale_name.c_str()
    );
  if(err < 0) return false;
  return true;
}