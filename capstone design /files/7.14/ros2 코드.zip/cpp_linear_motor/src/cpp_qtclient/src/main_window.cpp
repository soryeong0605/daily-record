#include "main_window.hpp"


MainWindow::MainWindow(std::shared_ptr<ClientCore> client, QWidget* parent)
 : QMainWindow(parent), _client(std::move(client)) {

  // grid layout setup
  this->resize(1080, 640);
  this->setWindowTitle("Cart-Pendulum Qt Client");
  QFont font("Arial", 15);
  this->setFont(font);
  _tab_widget = new QTabWidget(this);
  setCentralWidget(_tab_widget);

  // PID Tab layout
  _pid_tab = new QWidget();
  auto* pid_grid = new QGridLayout(_pid_tab);
  pid_grid->setContentsMargins(20, 20, 20, 20);
  pid_grid->setHorizontalSpacing(20);
  pid_grid->setVerticalSpacing(10);
  pid_grid->setColumnStretch(6, 1);
  pid_grid->setColumnStretch(7, 1);
  
  _dashboard_setup(pid_grid, _pid_layout);
  
  // col 0: Cart
  pid_grid->addWidget(new QLabel("Cart P"), 4, 0);
  pid_grid->addWidget(new QLabel("Cart I"), 5, 0);
  pid_grid->addWidget(new QLabel("Cart D"), 6, 0);
  pid_grid->addWidget(new QLabel("Cart Alpha"), 7, 0);

  // col 1: Cart edit
  _edit_cp = new QLineEdit("0.0", this);
  pid_grid->addWidget(_edit_cp, 4, 1);
  _edit_ci = new QLineEdit("0.0", this);
  pid_grid->addWidget(_edit_ci, 5, 1);
  _edit_cd = new QLineEdit("0.0", this);
  pid_grid->addWidget(_edit_cd, 6, 1);
  _edit_cal = new QLineEdit("0.1", this);
  pid_grid->addWidget(_edit_cal, 7, 1);

  // col 3: Pendulum
  pid_grid->addWidget(new QLabel("Pend P"), 4, 3);
  pid_grid->addWidget(new QLabel("Pend I"), 5, 3);
  pid_grid->addWidget(new QLabel("Pend D"), 6, 3);
  pid_grid->addWidget(new QLabel("Pend Alpha"), 7, 3);

  // col 4: Pendulum edit
  _edit_pp = new QLineEdit("0.0", this);
  pid_grid->addWidget(_edit_pp, 4, 4);
  _edit_pi = new QLineEdit("0.0", this);
  pid_grid->addWidget(_edit_pi, 5, 4);
  _edit_pd = new QLineEdit("0.0", this);
  pid_grid->addWidget(_edit_pd, 6, 4);
  _edit_pal = new QLineEdit("0.1", this);
  pid_grid->addWidget(_edit_pal, 7, 4);

  _tab_widget->addTab(_pid_tab, "PID");

  // LQR Tab layout
  _lqr_tab = new QWidget();
  auto* lqr_grid = new QGridLayout(_lqr_tab);
  lqr_grid->setContentsMargins(20, 20, 20, 20);
  lqr_grid->setHorizontalSpacing(20);
  lqr_grid->setVerticalSpacing(10);
  lqr_grid->setColumnStretch(6, 1);
  lqr_grid->setColumnStretch(7, 1);

  _dashboard_setup(lqr_grid, _lqr_layout);
  
  // col 0
  lqr_grid->addWidget(new QLabel(""), 4, 0); // spacer
  lqr_grid->addWidget(new QLabel("LQR K1"), 5, 0);
  lqr_grid->addWidget(new QLabel("LQR K2"), 6, 0);
  lqr_grid->addWidget(new QLabel("dt (s)"), 8, 0);

  // col 1
  _edit_k1 = new QLineEdit("0.0", this);
  lqr_grid->addWidget(_edit_k1, 5, 1);
  _edit_k2 = new QLineEdit("0.0", this);
  lqr_grid->addWidget(_edit_k2, 6, 1);

  // col 2: spacer
  lqr_grid->addItem(new QSpacerItem(10, 10, QSizePolicy::Expanding, QSizePolicy::Minimum), 0, 2); // spacer

  // col 3
  lqr_grid->addWidget(new QLabel("LQR K3"), 5, 3);
  lqr_grid->addWidget(new QLabel("LQR K4"), 6, 3);
  lqr_grid->addWidget(new QLabel("Alpha"), 7, 3);

  // col 4
  _edit_k3 = new QLineEdit("0.0", this);
  lqr_grid->addWidget(_edit_k3, 5, 4);
  _edit_k4 = new QLineEdit("0.0", this);
  lqr_grid->addWidget(_edit_k4, 6, 4);
  _edit_lal = new QLineEdit("0.1", this);
  lqr_grid->addWidget(_edit_lal, 7, 4);

  // col 5: spacer
  lqr_grid->addItem(new QSpacerItem(10, 10, QSizePolicy::Expanding, QSizePolicy::Minimum), 0, 5); // spacer

  _tab_widget->addTab(_lqr_tab, "LQR");

  // setup timers
  _status_timer = new QTimer(this);
  _status_timer->setInterval(5000);  // 5000 ms
  connect(_status_timer, &QTimer::timeout, this, &MainWindow::_update_status);
  _status_timer->start();

  _update_timer = new QTimer(this);
  _update_timer->setInterval(50);  // 50 ms
  connect(_update_timer, &QTimer::timeout, [this]() {
    auto states = _client->get_states();
    for(auto& type: {_pid_layout, _lqr_layout}) {
      type.clock->setText(QString::number(states[0], 'f', 2));
      type.cart_pos_now->setText(QString::number(states[1], 'f', 4));
      type.pend_ang_now->setText(QString::number(states[2], 'f', 4));
      type.volt->setText(QString::number(states[3], 'f', 2));
    }
  });
  _update_timer->start();
}

// 슬롯 구현
void MainWindow::_on_update_clk() {
  int curr_tab = _tab_widget->currentIndex();
  if(curr_tab == 0) {
    // PID tab
    std::vector<double> params = {_edit_cp->text().toDouble(), _edit_ci->text().toDouble(),
                                  _edit_cd->text().toDouble(), _edit_cal->text().toDouble(),
                                  _edit_pp->text().toDouble(), _edit_pi->text().toDouble(),
                                  _edit_pd->text().toDouble(), _edit_pal->text().toDouble(),
                                  _pid_layout.edit_dt->text().toDouble(), 0.001,
                                  _pid_layout.edit_period->text().toDouble(),
                                  _pid_layout.edit_max_volt->text().toDouble()
    };
    int res = _client->set_params(params, "PID");
    if(res < 0) {
      QMessageBox::warning(this, "Warning", "Failed to set parameters. Make sure nodes are in 'unconfigured' state.\n Error code: " + QString::number(res));
      return;
    }
    res = _client->set_targets(
      _pid_layout.edit_cart_pos->text().toDouble(),
      _pid_layout.edit_pend_ang->text().toDouble()
    );
    if(res < 0) {
      QMessageBox::warning(this, "Warning", "Failed to set targets. Make sure nodes are in 'unconfigured' state.\n Error code: " + QString::number(res));
      return;
    }
  } else if(curr_tab == 1) {
    // LQR tab
    std::vector<double> params = {_edit_k1->text().toDouble(), _edit_k2->text().toDouble(),
                                  _edit_k3->text().toDouble(), _edit_k4->text().toDouble(),
                                  _edit_lal->text().toDouble(),
                                  _lqr_layout.edit_dt->text().toDouble(), 0.001,
                                  _lqr_layout.edit_period->text().toDouble(),
                                  _lqr_layout.edit_max_volt->text().toDouble()
    };
    int res = _client->set_params(params, "LQR");
    if(res < 0) {
      QMessageBox::warning(this, "Warning", "Failed to set parameters. Make sure nodes are in 'unconfigured' state.\n Error code: " + QString::number(res));
      return;
    }
  }
  
}

void MainWindow::_on_init_clk() {
  std::array<int, 2> res = _client->init();
  for(auto& type: {_pid_layout, _lqr_layout}) {
    type.ct_status->setText(_status(res[0]).c_str());
    type.hw_status->setText(_status(res[1]).c_str());
  }
}
void MainWindow::_on_start_clk() {
  std::array<int, 2> res = _client->start();
  for(auto& type: {_pid_layout, _lqr_layout}) {
    type.ct_status->setText(_status(res[0]).c_str());
    type.hw_status->setText(_status(res[1]).c_str());
  }
}
void MainWindow::_on_stop_clk() {
  std::array<int, 2> res = _client->stop();
  for(auto& type: {_pid_layout, _lqr_layout}) {
    type.ct_status->setText(_status(res[0]).c_str());
    type.hw_status->setText(_status(res[1]).c_str());
  }
}
void MainWindow::_on_save_clk()
{
  QString filename = QFileDialog::getSaveFileName(this, "Save Data", QDir::homePath() + "/data.csv", "CSV Files (*.csv);;All Files (*)");
  if(filename.isEmpty()) return;

  int res = _client->save(filename.toStdString());
  if(res == 0) {
    QMessageBox::information(this, "Info", "Data saved successfully.");
    return;
  } else if(res == -10) {
    QMessageBox::warning(this, "Warning", "Cannot save data while nodes are active. Please stop the nodes first.");
    return;
  } else if(res == -30) {
    QMessageBox::warning(this, "Warning", "No data to save.");
    return;
  } else if(res == -31) {
    QMessageBox::warning(this, "Warning", "Failed to open csv file.");
    return;
  } else {
    QMessageBox::warning(this, "Warning", "Failed to save data due to unknown error.");
    return;
  }
}

void MainWindow::_on_home_clk() {
  auto states = _client->get_node_states();
  if(states[1] != UNCONFIGURED) {
    QMessageBox::warning(this, "Warning", "Cannot home position when hardware node is not unconfigured.");
    return;
  }
  _client->home_position(1.0);
}

void MainWindow::_on_reset_clk() {
  auto states = _client->get_node_states();
  if(states[1] != UNCONFIGURED) {
    QMessageBox::warning(this, "Warning", "Cannot reset position when hardware node is not unconfigured.");
    return;
  }
  _client->home_position(-1.0);
}

std::string MainWindow::_status(const int status_code) {
  switch(status_code) {
    case DISCONNECTED:
      return "Disconnected";
    case UNCONFIGURED:
      return "Unconfigured";
    case INACTIVE:
      return "Inactive";
    case ACTIVE:
      return "Active";
    default:
      return "Unknown";
  }
}

void MainWindow::closeEvent(QCloseEvent* event) {
  if(_status_timer && _status_timer->isActive()) _status_timer->stop();
  if(_update_timer && _update_timer->isActive()) _update_timer->stop();
  //if(_client) _client->quit();
  event->accept();
}

void MainWindow::_update_status() {
  std::array<int, 2> res = _client->get_node_states();
  for(auto& type: {_pid_layout, _lqr_layout}) {
    type.ct_status->setText(_status(res[0]).c_str());
    type.hw_status->setText(_status(res[1]).c_str());
  }
}

void MainWindow::_dashboard_setup(QGridLayout* grid, Layout& type) {
  // col 0: Cart
  grid->addWidget(new QLabel("Clock (s)"), 0, 0);
  grid->addWidget(new QLabel("Cart Pos (m)"), 1, 0);
  grid->addWidget(new QLabel("Target"), 2, 0);
  grid->addItem(new QSpacerItem(10, 100, QSizePolicy::Expanding, QSizePolicy::Fixed), 3, 0); // spacer
  grid->addWidget(new QLabel("dt (s)"), 8, 0);

  // col 1: Cart edit
  type.clock = new QLineEdit("0.0", this);
  type.clock->setReadOnly(true);
  grid->addWidget(type.clock, 0, 1);
  type.cart_pos_now = new QLineEdit("0.0", this);
  type.cart_pos_now->setReadOnly(true);
  grid->addWidget(type.cart_pos_now, 1, 1);
  type.edit_cart_pos = new QLineEdit("0.0", this);
  grid->addWidget(type.edit_cart_pos, 2, 1);
  type.edit_dt = new QLineEdit("0.005", this);
  grid->addWidget(type.edit_dt, 8, 1);
  
  // col 2: spacer
  grid->addItem(new QSpacerItem(10, 10, QSizePolicy::Expanding, QSizePolicy::Minimum), 0, 2); // spacer

  // col 3: Pendulum
  grid->addWidget(new QLabel("Voltage (V)"), 0, 3);
  grid->addWidget(new QLabel("Pend Ang (deg)"), 1, 3);
  grid->addWidget(new QLabel("Target"), 2, 3);
  grid->addWidget(new QLabel("Data Period (s)"), 8, 3);

  // col 4: Pendulum edit
  type.volt = new QLineEdit("0.0", this);
  type.volt->setReadOnly(true);
  grid->addWidget(type.volt, 0, 4);
  type.pend_ang_now = new QLineEdit("0.0", this);
  type.pend_ang_now->setReadOnly(true);
  grid->addWidget(type.pend_ang_now, 1, 4);
  type.edit_pend_ang = new QLineEdit("0.0", this);
  grid->addWidget(type.edit_pend_ang, 2, 4);
  type.edit_period = new QLineEdit("0.05", this);
  grid->addWidget(type.edit_period, 8, 4);

  // col 5: spacer
  grid->addItem(new QSpacerItem(10, 10, QSizePolicy::Expanding, QSizePolicy::Minimum), 0, 5); // spacer

  // col 6: Node status and buttons
  grid->addWidget(new QLabel("Controller"), 0, 6);
  grid->addWidget(new QLabel("Hardware"), 1, 6);
  grid->addWidget(new QLabel("Max Volt (V)"), 2, 6);
  type.btn_update = new QPushButton("Update", this);
  grid->addWidget(type.btn_update, 4, 6);
  type.btn_start = new QPushButton("Start", this);
  grid->addWidget(type.btn_start, 5, 6);
  type.btn_home = new QPushButton("Home", this);
  grid->addWidget(type.btn_home, 6, 6);

  // col 7: Node status and buttons
  type.ct_status = new QLineEdit("Disconnected", this);
  type.ct_status->setReadOnly(true);
  grid->addWidget(type.ct_status, 0, 7);
  type.hw_status = new QLineEdit("Disconnected", this);
  type.hw_status->setReadOnly(true);
  grid->addWidget(type.hw_status, 1, 7);
  type.edit_max_volt = new QLineEdit("10.0", this);
  grid->addWidget(type.edit_max_volt, 2, 7);
  type.btn_init = new QPushButton("Init", this);
  grid->addWidget(type.btn_init, 4, 7);
  type.btn_stop = new QPushButton("Stop", this);
  grid->addWidget(type.btn_stop, 5, 7);
  type.btn_reset = new QPushButton("Reset", this);
  grid->addWidget(type.btn_reset, 6, 7);
  type.btn_save = new QPushButton("Save", this);
  grid->addWidget(type.btn_save, 8, 7);

  // signal-slot connections
  connect(type.btn_update, &QPushButton::clicked, this, &MainWindow::_on_update_clk);
  connect(type.btn_init, &QPushButton::clicked, this, &MainWindow::_on_init_clk);
  connect(type.btn_start, &QPushButton::clicked, this, &MainWindow::_on_start_clk);
  connect(type.btn_stop, &QPushButton::clicked, this, &MainWindow::_on_stop_clk);
  connect(type.btn_home, &QPushButton::clicked, this, &MainWindow::_on_home_clk);
  connect(type.btn_reset, &QPushButton::clicked, this, &MainWindow::_on_reset_clk);
  connect(type.btn_save, &QPushButton::clicked, this, &MainWindow::_on_save_clk);
}