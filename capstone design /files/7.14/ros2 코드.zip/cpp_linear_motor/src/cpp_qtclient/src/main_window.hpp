#pragma once
#include <QMainWindow>
#include <QWidget>
#include <QPushButton>
#include <QGridLayout>
#include <QLineEdit>
#include <QLabel>
#include <QTimer>
#include <QSpacerItem>
#include <QApplication>
#include <QFont>
#include <QSizePolicy>
#include <QCloseEvent>
#include <QMessageBox>
#include <QFileDialog>
#include <QTabWidget>
#include <string>
#include <array>
#include "client_core.hpp"

typedef struct {
  QLineEdit* clock;
  QLineEdit* cart_pos_now;
  QLineEdit* edit_cart_pos;
  QLineEdit* volt;
  QLineEdit* pend_ang_now;
  QLineEdit* edit_pend_ang;
  QLineEdit* edit_dt;
  QLineEdit* edit_period;
  QLineEdit* ct_status;
  QLineEdit* hw_status;
  QLineEdit* edit_max_volt;
  
  QPushButton* btn_update;
  QPushButton* btn_init;
  QPushButton* btn_start;
  QPushButton* btn_stop;
  QPushButton* btn_home;
  QPushButton* btn_reset;
  QPushButton* btn_save;
} Layout;

class MainWindow : public QMainWindow {
  Q_OBJECT

public:
  explicit MainWindow(std::shared_ptr<ClientCore> client, QWidget* parent = nullptr);

protected:
  void closeEvent(QCloseEvent* event) override;

private:
  std::shared_ptr<ClientCore> _client;
  void _dashboard_setup(QGridLayout* grid, Layout& type);

  // Main widgets
  QTabWidget* _tab_widget;
  QWidget* _pid_tab;
  QWidget* _lqr_tab;

  // PID tab widgets
  Layout _pid_layout;

  QLineEdit* _edit_cp;
  QLineEdit* _edit_ci;
  QLineEdit* _edit_cd;
  QLineEdit* _edit_cal;
  QLineEdit* _edit_pp;
  QLineEdit* _edit_pi;
  QLineEdit* _edit_pd;
  QLineEdit* _edit_pal;

  // LQR tab widgets
  Layout _lqr_layout;

  QLineEdit* _edit_k1;
  QLineEdit* _edit_k2;
  QLineEdit* _edit_k3;
  QLineEdit* _edit_k4;
  QLineEdit* _edit_lal;

  // Timers
  QTimer* _status_timer;
  QTimer* _update_timer;

  // status display
  std::string _status(const int status_code);

private slots:
  void _on_update_clk();
  void _on_init_clk();
  void _on_start_clk();
  void _on_stop_clk();
  void _on_home_clk();
  void _on_reset_clk();
  void _on_save_clk();
  void _update_status();
};