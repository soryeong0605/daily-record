#pragma once
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <array>
#include <chrono>
#include <filesystem>
#include <mutex>
#include <cstdlib>
#include "rclcpp/rclcpp.hpp"
#include "lifecycle_msgs/msg/state.hpp"
#include "lifecycle_msgs/msg/transition.hpp"
#include "lifecycle_msgs/srv/change_state.hpp"
#include "lifecycle_msgs/srv/get_state.hpp"
#include "std_msgs/msg/float64.hpp"
#include "cartpend_msgs/msg/cart_pend_state.hpp"

#define UNKNOWN -1
#define DISCONNECTED 0
#define UNCONFIGURED 1
#define INACTIVE 2
#define ACTIVE 3

class ClientCore : public rclcpp::Node {
  public:
    ClientCore();

    // ROS2 interfaces
    rclcpp::AsyncParametersClient::SharedPtr control_node = nullptr;
    rclcpp::Client<lifecycle_msgs::srv::ChangeState>::SharedPtr change_controller_state_client;
    rclcpp::Client<lifecycle_msgs::srv::GetState>::SharedPtr get_controller_state_client;
    rclcpp::AsyncParametersClient::SharedPtr hardware_node = nullptr;
    rclcpp::Client<lifecycle_msgs::srv::ChangeState>::SharedPtr change_hardware_state_client;
    rclcpp::Client<lifecycle_msgs::srv::GetState>::SharedPtr get_hardware_state_client;

    std::array<int, 2> init();
    std::array<int, 2> start();
    std::array<int, 2> stop();
    std::array<int, 2> quit();
    int save(const std::string file_path);
    int set_params(std::vector<double> params, std::string control_type);
    int set_targets(double pos, double ang);
    std::vector<double> get_params(std::string control_type);
    std::array<double, 2> get_targets();
    std::array<double, 4> get_states();
    std::array<int, 2> get_node_states();
    void home_position(double state);

  private:
    bool _change_state(uint8_t transition, rclcpp::Client<lifecycle_msgs::srv::ChangeState>::SharedPtr client);
    int _get_node_state(rclcpp::Client<lifecycle_msgs::srv::GetState>::SharedPtr client);
    std::vector<std::array<double, 4>> _data_buffer = {};
    std::mutex _data_mutex;

    rclcpp::Subscription<cartpend_msgs::msg::CartPendState>::SharedPtr _cli_sub;
    rclcpp::Publisher<std_msgs::msg::Float64>::SharedPtr _home_pub;

    std::vector<double> _pid_cart_params = {0.0, 0.0, 0.0, 0.1}; // kp, ki, kd, alpha
    std::vector<double> _pid_pend_params = {0.0, 0.0, 0.0, 0.1}; // kp, ki, kd, alpha
    std::vector<double> _lqr_K = {0.0, 0.0, 0.0, 0.0};
    double _lqr_alpha = 0.1;
    double _target_cart_pos = 0.0;
    double _target_pend_ang = 0.0;
    double _dt = 0.005;
    double _encoder_tick = 0.001;
    double _cli_tick = 0.05;
    double _max_voltage = 10.0;
    size_t _encoder_rate = 1000;
    size_t _cli_timer = 10;
    size_t _sample_size = 5;
};