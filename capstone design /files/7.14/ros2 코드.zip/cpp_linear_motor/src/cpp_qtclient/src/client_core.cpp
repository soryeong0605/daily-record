#include "client_core.hpp"


using namespace std::chrono_literals;

ClientCore::ClientCore() : Node("ClientNode") {
  _home_pub = this->create_publisher<std_msgs::msg::Float64>("home_position", 10);
}

std::array<int, 2> ClientCore::init() {
  auto curr_state = get_node_states();
  switch(curr_state[0]) {
    case UNCONFIGURED:
      // initialize controller
      _change_state(lifecycle_msgs::msg::Transition::TRANSITION_CONFIGURE, change_controller_state_client);
      break;

    case INACTIVE:
      // re-initialize controller
      if(_change_state(lifecycle_msgs::msg::Transition::TRANSITION_CLEANUP, change_controller_state_client)) {
        _change_state(lifecycle_msgs::msg::Transition::TRANSITION_CONFIGURE, change_controller_state_client);
      }
      break;

    case ACTIVE:
      // must stop first
      break;

    default:
      // unknown state or disconnected
      break;
  }
  
  switch(curr_state[1]) {
    case UNCONFIGURED:
      // initialize hardware
      _change_state(lifecycle_msgs::msg::Transition::TRANSITION_CONFIGURE, change_hardware_state_client);
      break;

    case INACTIVE:
      // re-initialize
      if(_change_state(lifecycle_msgs::msg::Transition::TRANSITION_CLEANUP, change_hardware_state_client)) {
        _change_state(lifecycle_msgs::msg::Transition::TRANSITION_CONFIGURE, change_hardware_state_client);
      }
      break;

    case ACTIVE:
      // must stop first
      break;

    default:
      // unknown state or disconnected
      break;
  }

  // clear data buffer
  {
    std::lock_guard<std::mutex> lock(_data_mutex);
    _data_buffer.clear();
  }
  
  // set up subscription to cartpend state topic
  auto qos = rclcpp::QoS(10).reliability(RMW_QOS_POLICY_RELIABILITY_RELIABLE);
  _cli_sub = this->create_subscription<cartpend_msgs::msg::CartPendState>(
    "current_state", qos,
    [this](const cartpend_msgs::msg::CartPendState::SharedPtr msg) {
      std::lock_guard<std::mutex> lock(_data_mutex);
      std::array<double, 4> data = {msg->time, msg->cart_pos, msg->pend_ang, msg->volt};
      _data_buffer.push_back(data);
    });

  if(_cli_sub == nullptr) {
    RCLCPP_INFO(this->get_logger(), "Failed to create subscription to cartpend_state_cli topic.");
  }
  
  return get_node_states();
}

std::array<int, 2> ClientCore::start() {
  auto curr_state = get_node_states();
  switch(curr_state[0]) {
    case UNCONFIGURED:
      // init first
      break;

    case INACTIVE:
      // start from inactive
      _change_state(lifecycle_msgs::msg::Transition::TRANSITION_ACTIVATE, change_controller_state_client);
      break;

    case ACTIVE:
      // already started
      break;
    
    default:
      // unknown state or disconnected
      break;
  }

  switch(curr_state[1]) {
    case UNCONFIGURED:
      // init first
      break;

    case INACTIVE:
      // start from inactive
      _change_state(lifecycle_msgs::msg::Transition::TRANSITION_ACTIVATE, change_hardware_state_client);
      break;

    case ACTIVE:
      // already started
      break;
    
    default:
      // unknown state or disconnected
      break;
  }
  
  return get_node_states();
}

std::array<int, 2> ClientCore::stop() {
  if(_cli_sub != nullptr) _cli_sub.reset();

  auto curr_state = get_node_states();
  switch(curr_state[0]) {
    case UNCONFIGURED:
      // already stopped
      break;

    case INACTIVE:
      // make unconfigured
      _change_state(lifecycle_msgs::msg::Transition::TRANSITION_CLEANUP, change_controller_state_client);
      break;

    case ACTIVE:
      // stop from active
      if(_change_state(lifecycle_msgs::msg::Transition::TRANSITION_DEACTIVATE, change_controller_state_client)) {
        _change_state(lifecycle_msgs::msg::Transition::TRANSITION_CLEANUP, change_controller_state_client);
      }
      break;

    default:
      // unknown state or disconnected
      break;
  }
  
  switch(curr_state[1]) {
    case UNCONFIGURED:
      // already stopped
      break;

    case INACTIVE:
      // make unconfigured
      _change_state(lifecycle_msgs::msg::Transition::TRANSITION_CLEANUP, change_hardware_state_client);
      break;

    case ACTIVE:
      // stop from active
      if(_change_state(lifecycle_msgs::msg::Transition::TRANSITION_DEACTIVATE, change_hardware_state_client)) {
        _change_state(lifecycle_msgs::msg::Transition::TRANSITION_CLEANUP, change_hardware_state_client);
      }
      break;

    default:
      // unknown state or disconnected
      break;
  }
  
  return get_node_states();
}

int ClientCore::set_params(std::vector<double> params, std::string control_type) {
  int err = 0;
  if(control_type == "PID") {
    double cp = params[0]; double ci = params[1]; double cd = params[2]; double ca = params[3];
    double pp = params[4]; double pi = params[5]; double pd = params[6]; double pa = params[7];
    double dt = params[8]; double et = params[9]; double ct = params[10]; double mv = params[11];

    _dt = dt;
    _encoder_tick = et;
    _cli_tick = ct;
    _max_voltage = mv;
    _pid_cart_params[0] = cp;
    _pid_cart_params[1] = ci;
    _pid_cart_params[2] = cd;
    _pid_cart_params[3] = ca;
    _pid_pend_params[0] = pp;
    _pid_pend_params[1] = pi;
    _pid_pend_params[2] = pd;
    _pid_pend_params[3] = pa;

    if(mv <= 0.0 || mv > 10.0) return -100;
    
    int state = DISCONNECTED;
    if(control_node != nullptr) state = _get_node_state(get_controller_state_client);
    if(state == UNCONFIGURED) {
      control_node->set_parameters({
        rclcpp::Parameter("pid_cart_params", _pid_cart_params),
        rclcpp::Parameter("pid_pend_params", _pid_pend_params),
        rclcpp::Parameter("dt", _dt),
        rclcpp::Parameter("max_voltage", _max_voltage),
        rclcpp::Parameter("controller_type", control_type)
      });
      RCLCPP_INFO(this->get_logger(), "Cart P: %.4f, I: %.4f, D: %.4f", _pid_cart_params[0], _pid_cart_params[1], _pid_cart_params[2]);
      RCLCPP_INFO(this->get_logger(), "Pend P: %.4f, I: %.4f, D: %.4f", _pid_pend_params[0], _pid_pend_params[1], _pid_pend_params[2]);
      RCLCPP_INFO(this->get_logger(), "Control dt: %.4f, Max Voltage: %.4f", _dt, _max_voltage);
    } else {
      RCLCPP_INFO(this->get_logger(), "Controller node must be in 'unconfigured' state to set parameters.");
      err -= 10;
    }
  } else if(control_type == "LQR") {
    _lqr_K = {params[0], params[1], params[2], params[3]};
    _lqr_alpha = params[4];
    _dt = params[5];
    _encoder_tick = params[6];
    _cli_tick = params[7];
    _max_voltage = params[8];

    if(_max_voltage <= 0.0 || _max_voltage > 10.0) return -100;

    int state = DISCONNECTED;
    if(control_node != nullptr) state = _get_node_state(get_controller_state_client);
    if(state == UNCONFIGURED) {
      control_node->set_parameters({
        rclcpp::Parameter("lqr_K", _lqr_K),
        rclcpp::Parameter("lqr_alpha", _lqr_alpha),
        rclcpp::Parameter("dt", _dt),
        rclcpp::Parameter("max_voltage", _max_voltage),
        rclcpp::Parameter("controller_type", control_type)
      });
      RCLCPP_INFO(this->get_logger(), "LQR K: [%.4f, %.4f, %.4f, %.4f]", _lqr_K[0], _lqr_K[1], _lqr_K[2], _lqr_K[3]);
      RCLCPP_INFO(this->get_logger(), "LQR alpha: %.4f", _lqr_alpha);
      RCLCPP_INFO(this->get_logger(), "Control dt: %.4f, Max Voltage: %.4f", _dt, _max_voltage);
    } else {
      RCLCPP_INFO(this->get_logger(), "Controller node must be in 'unconfigured' state to set parameters.");
      err -= 20;
    }
  } else {
    return -200; // invalid control type
  }

  // set hardware parameters
  int state = DISCONNECTED;
  if(hardware_node != nullptr) state = _get_node_state(get_hardware_state_client);
  if(state == UNCONFIGURED) {
    _encoder_rate = static_cast<size_t>(std::round(1.0/_encoder_tick));
    _sample_size = static_cast<size_t>(std::round(_dt*_encoder_rate));
    _cli_timer = static_cast<size_t>(std::round(_cli_tick/_dt));

    hardware_node->set_parameters({
      rclcpp::Parameter("encoder_tick", _encoder_tick),
      rclcpp::Parameter("encoder_rate", static_cast<double>(_encoder_rate)),
      rclcpp::Parameter("publish_tick", _dt),
      rclcpp::Parameter("sample_size", static_cast<int>(_sample_size)),
      rclcpp::Parameter("cli_timer", static_cast<int>(_cli_timer))
    });
    RCLCPP_INFO(this->get_logger(), "dt: %.4f, encoder dt: %.4f, counter dt: %.4f", _dt, _encoder_tick, _cli_tick);
  } else {
    RCLCPP_INFO(this->get_logger(), "Hardware node must be in 'unconfigured' state to set parameters.");
    err -= 1;
  }
  return err;
}

int ClientCore::set_targets(double pos, double ang) {
  int err = 0;
  int state = DISCONNECTED;
  state = _get_node_state(get_controller_state_client);
  if(state != UNKNOWN && state != DISCONNECTED) {
    _target_cart_pos = pos;
    _target_pend_ang = ang;

    control_node->set_parameters({
      rclcpp::Parameter("target_cart_pos", _target_cart_pos),
      rclcpp::Parameter("target_pend_ang", _target_pend_ang)
    });

    RCLCPP_INFO(this->get_logger(), "Target Pos: %.4f, Target Ang: %.4f", _target_cart_pos, _target_pend_ang);
  } else {
    RCLCPP_INFO(this->get_logger(), "Cannot set targets when controller node is disconnected.");
    err = -10;
  }
  
  return err;
}

std::vector<double> ClientCore::get_params(std::string control_type) {
  if(control_type == "PID") {
    return {
      _pid_cart_params[0], _pid_cart_params[1], _pid_cart_params[2], _pid_cart_params[3],
      _pid_pend_params[0], _pid_pend_params[1], _pid_pend_params[2], _pid_pend_params[3],
      _dt, _encoder_tick, _cli_tick, _max_voltage
    };
  } else if(control_type == "LQR") {
    return {_lqr_K[0], _lqr_K[1], _lqr_K[2], _lqr_K[3], _lqr_alpha, _dt, _encoder_tick, _cli_tick, _max_voltage};
  } else {
    return {};
  }
}

std::array<double, 2> ClientCore::get_targets() {
  return {
    _target_cart_pos, _target_pend_ang
  };
}

std::array<double, 4> ClientCore::get_states() {
  std::lock_guard<std::mutex> lock(_data_mutex);
  if(_data_buffer.empty()) {
    return {0.0, 0.0, 0.0, 0.0};
  } else {
    return _data_buffer.back();
  }
}

int ClientCore::save(const std::string file_path) {
  auto curr_state = get_node_states();
  if(curr_state[0] == ACTIVE || curr_state[1] == ACTIVE) {
    return -10;
  }
  
  std::vector<std::array<double, 4>> data_copy;
  {
    std::lock_guard<std::mutex> lock(_data_mutex);
    if(_data_buffer.empty()) return -30;
    data_copy = _data_buffer;
  }

  // 파일에 데이터 저장
  std::ofstream ofs(file_path);
  if(!ofs) {
    return -31;
  }

  // CSV 헤더 작성
  ofs << "time,cart_pos,pend_ang,voltage\n";
  ofs << std::fixed << std::setprecision(6);

  // 데이터 버퍼의 내용을 파일에 저장
  for(const auto& data : data_copy) {
    ofs << data[0] << "," << data[1] << "," << data[2] << "," << data[3] << "\n";
  }

  ofs.close();
  return 0;
}

std::array<int, 2> ClientCore::quit() {
  auto curr_state = stop();
  
  if((curr_state[0] == UNCONFIGURED || curr_state[0] == DISCONNECTED || curr_state[0] == UNKNOWN) && (curr_state[1] == UNCONFIGURED || curr_state[1] == DISCONNECTED || curr_state[1] == UNKNOWN)) {
    std::lock_guard<std::mutex> lock(_data_mutex);
    _data_buffer.clear();
    rclcpp::shutdown();
  }
  
  return curr_state;
}

bool ClientCore::_change_state(uint8_t transition, rclcpp::Client<lifecycle_msgs::srv::ChangeState>::SharedPtr client) {
  auto req = std::make_shared<lifecycle_msgs::srv::ChangeState::Request>();
  req->transition.id = transition;

  if(!client->wait_for_service(5s)) {
    return false;
  }

  for(int attempt = 1; attempt <= 3; ++attempt) {
    auto future = client->async_send_request(req);
    if(future.wait_for(10s) == std::future_status::ready) {
      return future.get()->success;
    } 
  }
  return false;
}

int ClientCore::_get_node_state(rclcpp::Client<lifecycle_msgs::srv::GetState>::SharedPtr client) {
  auto req = std::make_shared<lifecycle_msgs::srv::GetState::Request>();
  
  if(!client->wait_for_service(5s)) {
    return UNKNOWN;
  }
  auto future = client->async_send_request(req);

  for(int attempt = 1; attempt <= 10; ++attempt) {
    if(future.wait_for(5s) == std::future_status::ready) {
      auto resp = future.get();
      auto state = resp->current_state.label;
      if(state == "unconfigured") return UNCONFIGURED;
      else if(state == "inactive") return INACTIVE;
      else if(state == "active") return ACTIVE;
      else return UNKNOWN;
    }
  }
  return DISCONNECTED;
}

std::array<int, 2> ClientCore::get_node_states() {
  int ct_state = DISCONNECTED;
  if(control_node != nullptr) ct_state = _get_node_state(get_controller_state_client);

  int hw_state = DISCONNECTED;
  if(hardware_node != nullptr) hw_state = _get_node_state(get_hardware_state_client);
  return {ct_state, hw_state};
}

void ClientCore::home_position(double state) {
  auto msg = std::make_shared<std_msgs::msg::Float64>();
  msg->data = state;
  _home_pub->publish(*msg);
}