#include <memory>
#include <thread>
#include <QApplication>
#include "rclcpp/executors/single_threaded_executor.hpp"
#include "client_core.hpp"
#include "main_window.hpp"


using namespace std::chrono_literals;


int main(int argc, char** argv) {
  rclcpp::init(argc, argv);
  auto client = std::make_shared<ClientCore>();

  std::string controller_name = "controller_node";
  std::cout << "Create client for Controller Node: " << controller_name << std::endl;
  client->control_node = std::make_shared<rclcpp::AsyncParametersClient>(client, controller_name);
  client->change_controller_state_client = 
    client->create_client<lifecycle_msgs::srv::ChangeState>(controller_name + "/change_state");
  client->get_controller_state_client = 
    client->create_client<lifecycle_msgs::srv::GetState>(controller_name + "/get_state");

  std::string hardware_name = "hardware_node";
  std::cout << "Create client for Hardware Node: " << hardware_name << std::endl;
  client->hardware_node = std::make_shared<rclcpp::AsyncParametersClient>(client, hardware_name);
  client->change_hardware_state_client = 
    client->create_client<lifecycle_msgs::srv::ChangeState>(hardware_name + "/change_state");
  client->get_hardware_state_client = 
    client->create_client<lifecycle_msgs::srv::GetState>(hardware_name + "/get_state");

  rclcpp::executors::SingleThreadedExecutor exec;
  exec.add_node(client);

  std::thread ros_thread([&exec]() {
    exec.spin();
  });

  QApplication app(argc, argv);
  MainWindow main_window(client);
  main_window.show();
  int ret = app.exec();

  exec.cancel();
  ros_thread.join();
  rclcpp::shutdown();
  return ret;
}

/*

*/