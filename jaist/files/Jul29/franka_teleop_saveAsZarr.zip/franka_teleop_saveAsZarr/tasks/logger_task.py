import threading
import os
import time
from datetime import datetime
from pathlib import Path

import numpy as np
import zarr


# =========================================================
# zarr 헬퍼 (demo_collect.py의 create_zarr_dataset / save_episode와 동일 패턴)
# =========================================================

def create_zarr_dataset(output_dir):
    """episodes/dataset.zarr 를 열거나(없으면) 새로 만듦"""
    zarr_path = Path(output_dir) / "dataset.zarr"
    root = zarr.open(str(zarr_path), mode="a")

    if "data" not in root:
        root.create_group("data")
    if "meta" not in root:
        meta = root.create_group("meta")
        meta.create_array("episode_ends", shape=(0,), dtype=np.int64, chunks=(100,))

    return root


def save_episode(zarr_root, episode_data):
    """episode_data(dict of np.ndarray) 를 zarr에 이어붙임"""
    data_group = zarr_root["data"]
    meta_group = zarr_root["meta"]

    episode_ends = meta_group["episode_ends"]
    n_eps = episode_ends.shape[0]
    current_len = int(episode_ends[n_eps - 1]) if n_eps > 0 else 0

    episode_len = episode_data["timestamp"].shape[0]
    new_len = current_len + episode_len

    for key, value in episode_data.items():
        if key not in data_group:
            data_group.create_array(
                key,
                shape=(new_len,) + value.shape[1:],
                dtype=value.dtype,
                chunks=(100,) + value.shape[1:],
            )
        else:
            data_group[key].resize((new_len,) + value.shape[1:])

        data_group[key][current_len:new_len] = value

    episode_ends.resize(n_eps + 1)
    episode_ends[-1] = new_len

    return n_eps


# =========================================================
# LoggerTask
# =========================================================

class LoggerTask(threading.Thread):

    def __init__(self, shared, output_dir="episodes"):
        super().__init__()
        self.shared = shared
        self.output_dir = output_dir

        # zarr store는 시작할 때 한 번만 열어둠 (append 모드)
        self.zarr_root = create_zarr_dataset(self.output_dir)

        # CSV의 self.csv_file / self.writer 자리를 대신하는 "버퍼"
        self.timestamps = []
        self.positions = []   # x, y, z
        self.velocities = []  # vx, vy, vz, wz

        self.episode_id = self._find_last_episode_id()

    def _find_last_episode_id(self):
        """zarr의 episode_ends 개수를 그대로 에피소드 번호로 사용.
        (재시작해도 이어서 번호 매겨짐 — 기존 CSV 버전의 폴더 스캔 방식 대체)"""
        meta = self.zarr_root["meta"]
        return int(meta["episode_ends"].shape[0])

    def _reset_buffers(self):
        self.timestamps = []
        self.positions = []
        self.velocities = []

    def start_episode(self):
        self.episode_id += 1
        self._reset_buffers()
        print(f"Episode {self.episode_id} 시작! -> {self.output_dir}/dataset.zarr")

    def stop_episode(self):
        if len(self.timestamps) == 0:
            print(f"Episode {self.episode_id} 종료! (기록된 데이터 없음, 저장 스킵)")
            return

        episode_data = {
            "timestamp": np.array(self.timestamps, dtype=np.float64),
            "eef_pos": np.array(self.positions, dtype=np.float32),      # (T, 3)
            "eef_velocity": np.array(self.velocities, dtype=np.float32),  # (T, 4) vx,vy,vz,wz
        }

        n_eps = save_episode(self.zarr_root, episode_data)
        print(f"Episode {self.episode_id} 종료! ({len(self.timestamps)} steps 저장됨, "
              f"zarr 누적 에피소드 수: {n_eps + 1})")

        self._reset_buffers()

    def run(self):
        while self.shared.running:

            with self.shared.lock:
                changed = self.shared.recording_changed
                recording = self.shared.recording

            if changed:
                with self.shared.lock:
                    self.shared.recording_changed = False
                if recording:
                    self.start_episode()
                else:
                    self.stop_episode()

            if not recording:
                time.sleep(0.05)
                continue

            with self.shared.lock:
                pose = None if self.shared.robot_pose is None else np.array(self.shared.robot_pose, copy=True)
                vel = list(self.shared.sent_velocity)

            if pose is None:
                time.sleep(0.05)
                continue

            # =========================
            # 버퍼에 적재 (CSV writerow 자리를 대신함)
            # =========================
            self.timestamps.append(time.time())     # 학습 파이프라인에서 쓰기 편하도록 float unix time
            self.positions.append(pose[:3].copy())
            self.velocities.append(np.array(vel, dtype=np.float32))

            time.sleep(0.05)  # 20Hz
