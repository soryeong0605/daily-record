"""
tasks/camera_task.py - franka_soryeong/combined_teleop/tasks/camera_task.py

RealSense 카메라 2대(camera_0, camera_1)를 백그라운드에서 스트리밍하는
독립 스레드. franka/flowbot 제어 로직에는 전혀 관여하지 않고, shared를
통해서만 logger_task.py와 상호작용함.

동작 방식:
- 평소엔 대기 (shared.camera_request == False)
- logger_task.py가 'c' 눌려서 shared.camera_request = True로 바꾸면
  그때 파이프라인을 열고 스트리밍 시작 (초기화에 1~2초 정도 걸림)
- 양쪽 카메라 모두 첫 프레임이 들어오면 shared.camera_ready = True로 세팅
  -> logger_task.py는 이 플래그가 True가 될 때까지 실제 로깅(CSV+이미지)을
     시작하지 않음 (카메라 준비 전 구간은 기록 안 함 -- 동기화 정확성 우선)
- 스트리밍 중엔 계속 shared.latest_frames를 최신 프레임으로 갱신
- shared.camera_request가 False로 바뀌면(= 's' 눌림) 파이프라인을 정지하고
  camera_ready도 False로 리셋한 뒤 다시 대기 상태로 돌아감
"""

import threading
import time

import numpy as np
import pyrealsense2 as rs

CAMERA_SERIALS = {
    "camera_0": "051222061185",  # D415
    "camera_1": "827112072398",  # D435
}
CAMERA_WIDTH, CAMERA_HEIGHT, CAMERA_FPS = 640, 480, 30


class CameraTask(threading.Thread):

    def __init__(self, shared):
        super().__init__()
        self.shared = shared
        self.pipelines = {}   # name -> rs.pipeline

    def _start_pipelines(self):
        print("[Camera] 초기화 중...")
        for name, serial in CAMERA_SERIALS.items():
            pipeline = rs.pipeline()
            config = rs.config()
            config.enable_device(serial)
            config.enable_stream(
                rs.stream.color, CAMERA_WIDTH, CAMERA_HEIGHT, rs.format.bgr8, CAMERA_FPS
            )
            pipeline.start(config)
            self.pipelines[name] = pipeline
        print("[Camera] 파이프라인 시작됨, 첫 프레임 대기 중...")

    def _stop_pipelines(self):
        for name, pipeline in self.pipelines.items():
            try:
                pipeline.stop()
            except Exception as e:
                print(f"[Camera] {name} pipeline stop 실패: {e}")
        self.pipelines = {}
        print("[Camera] 스트리밍 정지됨")

    def run(self):
        while self.shared.running:

            with self.shared.lock:
                requested = self.shared.camera_request

            if not requested:
                time.sleep(0.05)
                continue

            # =========================
            # 스트리밍 시작 (요청 들어옴)
            # =========================
            self._start_pipelines()
            first_frame_seen = {name: False for name in self.pipelines}

            while self.shared.running:

                with self.shared.lock:
                    requested = self.shared.camera_request
                if not requested:
                    break  # 's' 눌려서 정지 요청됨

                frames = {}
                for name, pipeline in self.pipelines.items():
                    try:
                        rs_frames = pipeline.wait_for_frames(timeout_ms=1000)
                        color_frame = rs_frames.get_color_frame()
                        if color_frame:
                            frames[name] = np.asanyarray(color_frame.get_data())
                            first_frame_seen[name] = True
                    except Exception as e:
                        print(f"[Camera] {name} 프레임 읽기 실패: {e}")

                if frames:
                    with self.shared.lock:
                        self.shared.latest_frames.update(frames)

                if all(first_frame_seen.values()):
                    with self.shared.lock:
                        already_ready = self.shared.camera_ready
                        if not already_ready:
                            self.shared.camera_ready = True
                    if not already_ready:
                        print("[Camera] 양쪽 카메라 준비 완료 -> camera_ready = True")

            # =========================
            # 스트리밍 정지 (요청 해제됨)
            # =========================
            self._stop_pipelines()
            with self.shared.lock:
                self.shared.camera_ready = False

        # =========================
        # 전체 종료 시, 혹시 스트리밍 중이었으면 정리
        # =========================
        if self.pipelines:
            self._stop_pipelines()
