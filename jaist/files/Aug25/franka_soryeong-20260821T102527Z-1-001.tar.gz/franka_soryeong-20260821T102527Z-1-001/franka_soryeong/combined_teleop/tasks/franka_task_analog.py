import csv
import os
import threading
import time

import numpy as np
import pyspacemouse

from franky import Robot, CartesianVelocityMotion, CartesianVelocityStopMotion, Twist

from shared import RECORD_DT

# =========================
# SpaceMouse -> velocity 매핑 (franky_teleop.py 원본과 동일)
# =========================

DEADBAND_X = 0.12
DEADBAND_Y = 0.12
DEADBAND_Z = 0.12
DEADBAND_YAW = 0.12

RAW_X_MIN, RAW_X_MAX = -0.80, 0.80
RAW_Y_MIN, RAW_Y_MAX = -0.80, 0.80
RAW_Z_MIN, RAW_Z_MAX = -0.80, 0.80
RAW_YAW_MIN, RAW_YAW_MAX = -1.00, 1.00

MAX_LINEAR = 0.03
SLOW_LINEAR = 0.01
MAX_YAW = 0.4

MIN_RETARGET_DT = 0.05
KEEPALIVE_DT = 0.15

YAW_EXCLUSIVITY_RATIO = 1.5


def clamp(v, lo, hi):
    return max(lo, min(hi, v))


def map_axis(raw, raw_min, raw_max, deadband):
    if abs(raw) < deadband:
        return 0.0
    if raw > 0.0:
        if raw_max <= deadband:
            return 0.0
        return clamp((raw - deadband) / (raw_max - deadband), 0.0, 1.0)
    if raw_min >= -deadband:
        return 0.0
    return clamp((raw + deadband) / (abs(raw_min) - deadband), -1.0, 0.0)


def axis_to_velocity(unit, max_pos, max_neg, mode):
    if mode == "digital":
        if unit > 0.0:
            return max_pos
        if unit < 0.0:
            return max_neg
        return 0.0
    if unit > 0.0:
        return unit * max_pos
    if unit < 0.0:
        return abs(unit) * max_neg
    return 0.0


def spacemouse_target(state, mode, max_linear=MAX_LINEAR):
    x_unit = map_axis(state.x, RAW_X_MIN, RAW_X_MAX, DEADBAND_X)
    y_unit = map_axis(state.y, RAW_Y_MIN, RAW_Y_MAX, DEADBAND_Y)
    z_unit = map_axis(state.z, RAW_Z_MIN, RAW_Z_MAX, DEADBAND_Z)
    yaw_unit = map_axis(state.yaw, RAW_YAW_MIN, RAW_YAW_MAX, DEADBAND_YAW)

    trans_mag = max(abs(state.x) / RAW_X_MAX, abs(state.y) / RAW_Y_MAX, abs(state.z) / RAW_Z_MAX)
    yaw_mag = abs(state.yaw) / RAW_YAW_MAX

    if yaw_mag > trans_mag * YAW_EXCLUSIVITY_RATIO:
        x_unit = 0.0
        y_unit = 0.0
        z_unit = 0.0
    elif trans_mag > yaw_mag * YAW_EXCLUSIVITY_RATIO:
        yaw_unit = 0.0
    else:
        x_unit = 0.0
        y_unit = 0.0
        z_unit = 0.0
        yaw_unit = 0.0

    vx = axis_to_velocity(x_unit, max_linear, -max_linear, mode)
    vy = axis_to_velocity(y_unit, max_linear, -max_linear, mode)
    vz = axis_to_velocity(z_unit, max_linear, -max_linear, mode)
    wz = axis_to_velocity(yaw_unit, MAX_YAW, -MAX_YAW, mode)

    vx, vy, vz = normalize_linear(vx, vy, vz, max_linear)
    return np.array([vx, vy, vz, wz], dtype=float)


def targets_differ(a, b, lin_deadband=0.002, yaw_deadband=0.005):
    if np.linalg.norm(a[:3] - b[:3]) > lin_deadband:
        return True
    if abs(a[3] - b[3]) > yaw_deadband:
        return True
    return False


def normalize_linear(vx, vy, vz, max_speed):
    v = np.array([vx, vy, vz], dtype=float)
    norm = float(np.linalg.norm(v))
    if norm > max_speed and norm > 1e-9:
        v = v / norm * max_speed
    return float(v[0]), float(v[1]), float(v[2])


class FrankaTask(threading.Thread):
    """
    franky_teleop.py 원본 + zarr 데이터수집(8/22) + 모드전환(8/25) 연동.
    """

    def __init__(self, shared, ip="172.16.0.2", mode="digital",
                 dynamics_factor=0.05, camera_manager=None):
        super().__init__()
        self.shared = shared
        self.ip = ip
        self.mode = mode
        self.dynamics_factor = dynamics_factor
        self.camera_manager = camera_manager
        self.robot = None
        self.plot_csv_file = None
        self.plot_writer = None
        self._last_b0 = False   # 1번 버튼 edge 감지용

    def _open_plot_log(self):
        os.makedirs("sessions", exist_ok=True)
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filepath = f"sessions/session_{timestamp}.csv"

        self.plot_csv_file = open(filepath, "w", newline="")
        self.plot_writer = csv.writer(self.plot_csv_file)
        self.plot_writer.writerow([
            "t",
            "raw_x", "raw_y", "raw_z", "raw_yaw",
            "vx", "vy", "vz", "wz",
            "act_vx", "act_vy", "act_vz", "act_wz",
        ])
        print(f"[Franka] Plot log -> {filepath}")

    def _close_plot_log(self):
        if self.plot_csv_file:
            self.plot_csv_file.close()

    def run(self):
        self._open_plot_log()

        print(f"[Franka] Connecting to {self.ip} ...")
        self.robot = Robot(self.ip)
        self.robot.relative_dynamics_factor = self.dynamics_factor
        self.robot.recover_from_errors()
        print(f"[Franka] Connected. relative_dynamics_factor={self.dynamics_factor}, mode={self.mode}")

        with pyspacemouse.open() as device:
            print("SpaceMouse connected")

            last_target = np.zeros(4, dtype=float)
            last_retarget_time = 0.0
            last_state_query = 0.0
            STATE_QUERY_DT = 0.05
            session_start = time.monotonic()

            while self.shared.running:
                state = device.read()
                if state is None:
                    time.sleep(0.01)
                    continue

                time.sleep(0.001)

                # ── 모드 전환: 1번 버튼(buttons[0]) 누르면 정지 후 flowbot으로 ──
                buttons = list(state.buttons)
                b0_now = bool(buttons[0]) if len(buttons) > 0 else False
                if b0_now and not self._last_b0:
                    print("[Franka] 1번 버튼 감지 -> 정지 후 flowbot으로 전환")
                    try:
                        self.robot.move(CartesianVelocityStopMotion(), asynchronous=True)
                        self.robot.join_motion()
                    except Exception as e:
                        print(f"[Franka] 전환 전 정지 실패: {e}")
                    with self.shared.lock:
                        self.shared.active_mode = "flowbot"
                self._last_b0 = b0_now

                with self.shared.lock:
                    mode = self.shared.active_mode
                if mode != "franka":
                    time.sleep(0.02)
                    continue

                with self.shared.lock:
                    slow_mode = self.shared.slow_mode
                max_linear = SLOW_LINEAR if slow_mode else MAX_LINEAR

                target = spacemouse_target(state, self.mode, max_linear=max_linear)
                now = time.monotonic()

                changed = targets_differ(target, last_target)
                elapsed = now - last_retarget_time
                should_retarget = (
                    (changed and elapsed >= MIN_RETARGET_DT)
                    or elapsed >= KEEPALIVE_DT
                )

                if should_retarget:
                    vx, vy, vz, wz = target
                    motion = CartesianVelocityMotion(Twist([vx, vy, vz], [0.0, 0.0, wz]))
                    self.robot.move(motion, asynchronous=True)
                    last_target = target.copy()
                    last_retarget_time = now
                    with self.shared.lock:
                        self.shared.sent_velocity = last_target.tolist()

                if now - last_state_query >= STATE_QUERY_DT:
                    last_state_query = now

                    pose = None
                    try:
                        cart_state = self.robot.current_cartesian_state
                        pose = np.array(cart_state.pose.end_effector_pose.translation)
                        act_v = cart_state.velocity.end_effector_twist
                        act_vx, act_vy, act_vz = act_v.linear
                        act_wz = act_v.angular[2]

                        with self.shared.lock:
                            self.shared.latest_franka_eef_pose = pose
                            self.shared.latest_franka_velocity = np.array(
                                [act_vx, act_vy, act_vz, act_wz], dtype=float
                            )
                    except Exception as e:
                        print(f"[Franka] state read failed: {e}")
                        act_vx = act_vy = act_vz = act_wz = float("nan")

                    b0 = buttons[0] if len(buttons) > 0 else 0
                    b1 = buttons[14] if len(buttons) > 14 else 0

                    self.plot_writer.writerow([
                        f"{now - session_start:.4f}",
                        f"{state.x:.4f}", f"{state.y:.4f}", f"{state.z:.4f}", f"{state.yaw:.4f}",
                        f"{target[0]:.5f}", f"{target[1]:.5f}", f"{target[2]:.5f}", f"{target[3]:.5f}",
                        f"{act_vx:.5f}", f"{act_vy:.5f}", f"{act_vz:.5f}", f"{act_wz:.5f}",
                    ])

                    # ── zarr 기록 (flowbot과 동일한 RECORD_DT 게이팅) ──
                    if pose is not None:
                        now2 = time.time()
                        with self.shared.lock:
                            recording = self.shared.is_recording
                            time_to_record = (now2 - self.shared.last_record_time) >= RECORD_DT
                            if recording and time_to_record:
                                self.shared.last_record_time = now2
                            pwm = self.shared.latest_pwm

                        if recording and time_to_record:
                            self.shared.episode_buffer.add(
                                timestamp=now2,
                                franka_eef_pose=pose,
                                gripper_tip_pose=pose,
                                pwm_signals=np.asarray(
                                    pwm if pwm is not None else np.zeros(3), dtype=float
                                ),
                                franka_velocity=np.array(
                                    [act_vx, act_vy, act_vz, act_wz], dtype=float
                                ),
                                operation_mode=np.array([1, 0], dtype=np.uint8),
                                camera_frames=(
                                    self.camera_manager.get_latest_frames()
                                    if self.camera_manager else {}
                                ),
                            )

        self._close_plot_log()
        try:
            self.robot.move(CartesianVelocityStopMotion(), asynchronous=True)
            self.robot.join_motion()
        except Exception as e:
            print(f"[Franka] Stop failed: {e}")