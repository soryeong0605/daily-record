"""
show_zarr_timeline.py

zarr 에피소드를 "시간순으로 어떤 값이 찍혔는지" CSV처럼 훑어보는 스크립트.
- --interval_sec 간격으로 샘플링해서 보여줌(기본 1초, 내부적으로 timestamp 기준)
- 스텝 간 시간차가 비정상적으로 크면 [GAP!] 표시로 따로 강조 (판정용으로만 씀, 화면엔 dt를 안 보여줌)
- --csv_out 지정하면 전체 스텝(샘플링 없이) CSV로도 저장

사용법:
    # 터미널에 1초 간격으로 훑어보기
    python show_zarr_timeline.py --zarr_path data/demo_data/dataset.zarr --episode 0

    # 전체 스텝을 CSV로도 뽑기
    python show_zarr_timeline.py --zarr_path data/demo_data/dataset.zarr --episode 0 --csv_out timeline_ep0.csv
"""

import argparse
import csv as csv_module

import numpy as np
import zarr


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--zarr_path", default="data/demo_data/dataset.zarr")
    parser.add_argument("--episode", type=int, default=0, help="몇 번째 에피소드를 볼지 (0부터)")
    parser.add_argument("--interval_sec", type=float, default=1.0,
                         help="터미널 출력 샘플링 간격(초, timestamp 기준). 0이면 전체 스텝 다 출력")
    parser.add_argument("--gap_threshold_ms", type=float, default=100.0,
                         help="이 값(ms)보다 스텝 간 시간차가 크면 [GAP!]으로 표시")
    parser.add_argument("--csv_out", default=None, help="지정하면 전체 스텝을 이 경로에 CSV로 저장")
    args = parser.parse_args()

    root = zarr.open(args.zarr_path, mode="r")
    data = root["data"]
    ends = np.array(root["meta"]["episode_ends"])
    starts = np.concatenate([[0], ends[:-1]])

    if args.episode >= len(ends):
        print(f"에피소드 {args.episode}번은 없습니다 (총 {len(ends)}개, 0~{len(ends)-1})")
        return

    s, e = int(starts[args.episode]), int(ends[args.episode])
    ts = np.array(data["timestamp"][s:e])
    op_mode = np.array(data["operation_mode"][s:e])
    franka_pose = np.array(data["franka_eef_pose"][s:e])
    pwm = np.array(data["pwm_signals"][s:e])
    action = np.array(data["action"][s:e])  # (T,7) = [vx,vy,vz,wz, pwm1,pwm2,pwm3]
    franka_velocity = action[:, :4]

    dt_ms = np.concatenate([[0.0], np.diff(ts) * 1000.0])  # gap 판정에만 씀, 화면엔 안 찍음
    mode_label = np.where(
        op_mode[:, 0] == 1,
        np.where(op_mode[:, 1] == 1, "release", "franka"),
        "gripper",
    )

    print(f"\n에피소드 {args.episode}: {e - s} 스텝, {ts[0]:.3f} ~ {ts[-1]:.3f}")
    print("-" * 110)
    header = (f"{'step':>5} {'timestamp':>16} {'mode':>8} "
              f"{'franka_vel(vx,vy,vz,wz)':>32} {'pwm':>16}")
    print(header)
    print("-" * 110)

    next_mark_time = ts[0]
    for i in range(len(ts)):
        is_gap = dt_ms[i] > args.gap_threshold_ms
        show_by_interval = args.interval_sec <= 0 or ts[i] >= next_mark_time
        if not (show_by_interval or is_gap):
            continue
        if show_by_interval:
            next_mark_time = ts[i] + args.interval_sec

        vel_str = (f"[{franka_velocity[i,0]:.3f},{franka_velocity[i,1]:.3f},"
                   f"{franka_velocity[i,2]:.3f},{franka_velocity[i,3]:.3f}]")
        pwm_str = f"[{pwm[i,0]:.0f},{pwm[i,1]:.0f},{pwm[i,2]:.0f}]"
        gap_tag = "  <== [GAP!]" if is_gap else ""
        print(f"{i:>5} {ts[i]:>16.3f} {mode_label[i]:>8} "
              f"{vel_str:>32} {pwm_str:>16}{gap_tag}")

    if args.csv_out:
        with open(args.csv_out, "w", newline="") as f:
            writer = csv_module.writer(f)
            writer.writerow([
                "step", "timestamp", "mode",
                "franka_x", "franka_y", "franka_z",
                "pwm1", "pwm2", "pwm3",
                "franka_vx", "franka_vy", "franka_vz", "franka_wz",
                "action_pwm1", "action_pwm2", "action_pwm3",
            ])
            for i in range(len(ts)):
                writer.writerow([
                    i, f"{ts[i]:.6f}", mode_label[i],
                    *[f"{v:.5f}" for v in franka_pose[i, :3]],
                    *[f"{v:.3f}" for v in pwm[i]],
                    *[f"{v:.5f}" for v in action[i]],
                ])
        print(f"\n전체 {e-s}스텝 CSV -> {args.csv_out}")


if __name__ == "__main__":
    main()
