# =========================
# Plot helpers (2D only: XY / XZ / YZ)
# =========================
#
# 3D 워크스페이스 패널을 제거하고, 2D 평면(XY, XZ, YZ) 3개만 보여주는 버전.
# 레이아웃: 1x3 가로 배치
#   [XY]   [XZ]   [YZ]

from __future__ import annotations

import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import ConvexHull


class plot_helper:
    def setup_plot(self, points: np.ndarray, draw_hull: bool = True):
        points = np.asarray(points, dtype=float)
        P_vis = points

        mn = points.min(axis=0)
        mx = points.max(axis=0)

        plt.ion()
        fig = plt.figure(figsize=(15, 5))

        ax_xy = fig.add_subplot(1, 3, 1)
        ax_xz = fig.add_subplot(1, 3, 2)
        ax_yz = fig.add_subplot(1, 3, 3)

        # -------------------------
        # 2D hulls on each plane
        # -------------------------
        def _plot_hull_2d(ax, pts2):
            pts2 = np.asarray(pts2, dtype=float)
            if len(pts2) < 3:
                ax.scatter(pts2[:, 0], pts2[:, 1], s=2, alpha=0.3)
                return
            try:
                h = ConvexHull(pts2)
                poly = pts2[h.vertices]
                poly = np.vstack([poly, poly[0]])
                ax.plot(poly[:, 0], poly[:, 1], linewidth=1.0, alpha=0.6)
            except Exception:
                ax.scatter(pts2[:, 0], pts2[:, 1], s=2, alpha=0.3)

        ax_xy.set_title("XY"); ax_xy.set_xlabel("x"); ax_xy.set_ylabel("y")
        ax_xz.set_title("XZ"); ax_xz.set_xlabel("x"); ax_xz.set_ylabel("z")
        ax_yz.set_title("YZ"); ax_yz.set_xlabel("y"); ax_yz.set_ylabel("z")

        for ax in (ax_xy, ax_xz, ax_yz):
            ax.grid(True)
            ax.set_aspect("equal", adjustable="box")

        if draw_hull:
            _plot_hull_2d(ax_xy, P_vis[:, [0, 1]])
            _plot_hull_2d(ax_xz, P_vis[:, [0, 2]])
            _plot_hull_2d(ax_yz, P_vis[:, [1, 2]])

        # -------------------------
        # 워크스페이스 경계점들 (PWM 0~26 스윕한 실제 점군, 작은 점으로)
        # -------------------------
        ax_xy.scatter(P_vis[:, 0], P_vis[:, 1], s=3, alpha=0.35, c="steelblue", zorder=1)
        ax_xz.scatter(P_vis[:, 0], P_vis[:, 2], s=3, alpha=0.35, c="steelblue", zorder=1)
        ax_yz.scatter(P_vis[:, 1], P_vis[:, 2], s=3, alpha=0.35, c="steelblue", zorder=1)

        ax_xy.set_xlim(mn[0], mx[0]); ax_xy.set_ylim(mn[1], mx[1])
        ax_xz.set_xlim(mn[0], mx[0]); ax_xz.set_ylim(mn[2], mx[2])
        ax_yz.set_xlim(mn[1], mx[1]); ax_yz.set_ylim(mn[2], mx[2])
        ax_xz.invert_yaxis()
        ax_yz.invert_yaxis()

        # -------------------------
        # Handles (pc, opti, trail) for 2D
        # -------------------------
        p0 = P_vis[0] if len(P_vis) > 0 else np.array([0.0, 0.0, 0.0])

        pc_xy = ax_xy.scatter([p0[0]], [p0[1]], s=60, c="red", label="pc")
        pc_xz = ax_xz.scatter([p0[0]], [p0[2]], s=60, c="red", label="pc")
        pc_yz = ax_yz.scatter([p0[1]], [p0[2]], s=60, c="red", label="pc")

        opti_xy = ax_xy.scatter([p0[0]], [p0[1]], s=45, c="blue", label="opti")
        opti_xz = ax_xz.scatter([p0[0]], [p0[2]], s=45, c="blue", label="opti")
        opti_yz = ax_yz.scatter([p0[1]], [p0[2]], s=45, c="blue", label="opti")

        (trail_xy,) = ax_xy.plot([], [], linewidth=1.0, alpha=0.8, label="trail")
        (trail_xz,) = ax_xz.plot([], [], linewidth=1.0, alpha=0.8, label="trail")
        (trail_yz,) = ax_yz.plot([], [], linewidth=1.0, alpha=0.8, label="trail")

        ax_xy.legend(loc="best")
        ax_xz.legend(loc="best")
        ax_yz.legend(loc="best")

        fig.tight_layout()
        fig.show()
        plt.pause(0.001)

        axes = {"xy": ax_xy, "xz": ax_xz, "yz": ax_yz}
        pc_handles = {"xy": pc_xy, "xz": pc_xz, "yz": pc_yz}
        opti_handles = {"xy": opti_xy, "xz": opti_xz, "yz": opti_yz}
        trail_handles = {"xy": trail_xy, "xz": trail_xz, "yz": trail_yz}

        return fig, axes, pc_handles, opti_handles, trail_handles

    def update_point_handle(self, pc_handles, pc: np.ndarray):
        pc = np.asarray(pc, dtype=float).reshape(3,)

        pc_handles["xy"].set_offsets([[pc[0], pc[1]]])
        pc_handles["xz"].set_offsets([[pc[0], pc[2]]])
        pc_handles["yz"].set_offsets([[pc[1], pc[2]]])

    def update_opti_handle(self, opti_handles, p: np.ndarray):
        p = np.asarray(p, dtype=float).reshape(3,)

        opti_handles["xy"].set_offsets([[p[0], p[1]]])
        opti_handles["xz"].set_offsets([[p[0], p[2]]])
        opti_handles["yz"].set_offsets([[p[1], p[2]]])

    def highlight_pwm_corners(self, axes, robot, pwm_max: float = 26.0, pwm_min: float = 0.0):
        """
        PWM 0/pwm_max 조합 8개(꼭짓점들)의 실제 도달 위치를 계산해서
        2D 패널(XY/XZ/YZ)에 빨간 세모로 표시. setup_plot() 호출 직후,
        딱 한 번만 부르면 됨.

        사용 예 (teleop.py / flowbot.py 쪽에서):
            fb.pl.highlight_pwm_corners(fb.axes, fb.flowbot, pwm_max=26)
        """
        combos = [
            (pwm_min, pwm_min, pwm_min),
            (pwm_max, pwm_min, pwm_min),
            (pwm_min, pwm_max, pwm_min),
            (pwm_min, pwm_min, pwm_max),
            (pwm_max, pwm_max, pwm_min),
            (pwm_min, pwm_max, pwm_max),
            (pwm_max, pwm_min, pwm_max),
            (pwm_max, pwm_max, pwm_max),
        ]

        pts = []
        for pwm_tuple in combos:
            pwm = np.array(pwm_tuple, dtype=float)
            pb = robot.pwm_to_pressure(pwm)
            fk = robot.forward_kinematics_from_pressures(pb)
            pc = np.asarray(fk["pc"], dtype=float).reshape(3,)
            pts.append(pc)
            print(f"[plot_helper] PWM={pwm_tuple} -> pc={np.round(pc, 2)}")

        pts = np.array(pts)

        for key, idx in (("xy", (0, 1)), ("xz", (0, 2)), ("yz", (1, 2))):
            ax = axes[key]
            i, j = idx
            ax.scatter(pts[:, i], pts[:, j], s=60, c="red", marker="^",
                      label="PWM corners", zorder=5)
            ax.legend(loc="best")

    def update_trail_handle(self, trail_handles, trail_xyz: np.ndarray):
        if trail_xyz is None or len(trail_xyz) == 0:
            trail_handles["xy"].set_data([], [])
            trail_handles["xz"].set_data([], [])
            trail_handles["yz"].set_data([], [])
            return

        trail_xyz = np.asarray(trail_xyz, dtype=float)

        trail_handles["xy"].set_data(trail_xyz[:, 0], trail_xyz[:, 1])
        trail_handles["xz"].set_data(trail_xyz[:, 0], trail_xyz[:, 2])
        trail_handles["yz"].set_data(trail_xyz[:, 1], trail_xyz[:, 2])
