"""
capture_current_pose.py

지금 프랑카 팔이 손으로 잡혀있는(또는 마지막으로 이동한) 위치의 관절 각도를 읽어서,
go_home.py의 HOME_JOINTS에 그대로 붙여넣을 수 있는 형식으로 출력함.

사용법:
    python capture_current_pose.py
    # 출력된 HOME_JOINTS = [...] 를 복사해서 go_home.py에 붙여넣기
"""

from franky import Robot

FRANKA_IP = "172.16.0.2"

robot = Robot(FRANKA_IP)
q = robot.state.q  # 현재 관절 각도 (7개)

print("\n현재 관절 각도:")
print(list(q))

print("\n아래를 그대로 go_home.py의 HOME_JOINTS에 붙여넣으세요:\n")
print("HOME_JOINTS = [" + ", ".join(f"{v}" for v in q) + "]")
