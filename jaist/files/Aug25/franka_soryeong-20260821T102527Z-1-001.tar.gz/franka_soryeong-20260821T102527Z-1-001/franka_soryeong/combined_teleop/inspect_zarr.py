"""
inspect_zarr.py
"""
import argparse
import os
import numpy as np
import zarr


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--zarr_path", default="data/demo_data/dataset.zarr")
    parser.add_argument("--save_sample_images", action="store_true")
    args = parser.parse_args()

    root = zarr.open(args.zarr_path, mode="r")

    print("=" * 60)
    print(f"dataset: {args.zarr_path}")
    print("=" * 60)

    if "meta" in root and "episode_ends" in root["meta"]:
        episode_ends = np.array(root["meta"]["episode_ends"])
        print(f"\n에피소드 수: {len(episode_ends)}")
        print(f"episode_ends: {episode_ends}")
        total_steps = int(episode_ends[-1]) if len(episode_ends) > 0 else 0
        print(f"총 스텝 수: {total_steps}")
    else:
        print("\n⚠️  meta/episode_ends가 없습니다")
        total_steps = 0

    if "camera_info" in root:
        print(f"\ncamera_info attrs: {dict(root['camera_info'].attrs)}")

    print("\n필드별 shape/dtype:")
    if "data" not in root or total_steps == 0:
        print("  (저장된 필드 없음)")
        return

    data_group = root["data"]
    for key in data_group.array_keys():
        arr = data_group[key]
        print(f"  {key:20s} shape={arr.shape}  dtype={arr.dtype}")

    print("\n첫 에피소드, 첫 스텝(step 0) 값 미리보기:")
    for key in data_group.array_keys():
        if key.startswith("camera_"):
            continue
        arr = data_group[key]
        print(f"  {key:20s} = {np.array(arr[0])}")

    if args.save_sample_images:
        try:
            import cv2
        except ImportError:
            print("\n(opencv 없어서 이미지 저장 생략)")
            cv2 = None
        if cv2 is not None:
            out_dir = os.path.join(os.path.dirname(args.zarr_path), "sample_frames")
            os.makedirs(out_dir, exist_ok=True)
            for key in data_group.array_keys():
                if not key.startswith("camera_"):
                    continue
                frame = np.array(data_group[key][0])
                bgr = frame[:, :, ::-1]
                out_path = os.path.join(out_dir, f"{key}_step0.png")
                cv2.imwrite(out_path, bgr)
                print(f"  샘플 이미지 저장 -> {out_path}")


if __name__ == "__main__":
    main()
