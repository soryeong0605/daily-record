"""
check_mouse.py - SpaceMouse raw 값과 버튼 상태를 실시간으로 확인.

두 가지 모드:
    python check_mouse.py           -> pyspacemouse 직접 사용 (기본)
    python check_mouse.py mp        -> mouse_process.py의 MouseProcess 사용
                                        (spawn 방식, franky와 같이 쓸 때 검증된 방법)

Ctrl+C로 종료.
"""

import sys
import time


def run_direct():
    import pyspacemouse

    with pyspacemouse.open() as device:
        print("SpaceMouse connected (direct). 움직이거나 버튼을 눌러보세요. (Ctrl+C 종료)")
        try:
            while True:
                state = device.read()
                if state is None:
                    print("state: None (읽기 실패)")
                else:
                    buttons = list(state.buttons)
                    pressed = [i for i, b in enumerate(buttons) if b]
                    print(
                        f"x={state.x:+.3f} y={state.y:+.3f} z={state.z:+.3f} "
                        f"yaw={state.yaw:+.3f}  pressed_buttons={pressed}"
                    )
                time.sleep(0.1)
        except KeyboardInterrupt:
            print("\n종료")


def run_via_mouse_process():
    from mouse_process import MouseProcess

    mp_mouse = MouseProcess()
    mp_mouse.start()
    print("SpaceMouse 프로세스 시작 (spawn). 디바이스 열릴 때까지 잠시 대기...")
    time.sleep(1.0)

    print("움직이거나 버튼을 눌러보세요. (Ctrl+C 종료)")
    try:
        while True:
            x, y, z, yaw, buttons, is_stale = mp_mouse.get_latest()
            pressed = [i for i, b in enumerate(buttons) if b]
            stale_flag = " [STALE -- 입력 없음/프로세스 죽음]" if is_stale else ""
            print(
                f"x={x:+.3f} y={y:+.3f} z={z:+.3f} yaw={yaw:+.3f} "
                f"pressed_buttons={pressed}{stale_flag}"
            )
            if is_stale and not mp_mouse.is_child_alive():
                print("  -> 자식 프로세스 죽음 감지, 재시작 시도")
                mp_mouse.stop()
                mp_mouse.start()
                time.sleep(0.3)
            time.sleep(0.1)
    except KeyboardInterrupt:
        print("\n종료")
    finally:
        mp_mouse.stop()


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "mp":
        run_via_mouse_process()
    else:
        run_direct()
