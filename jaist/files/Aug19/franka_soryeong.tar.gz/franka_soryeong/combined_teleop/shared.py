from dataclasses import dataclass, field
from threading import Lock


@dataclass
class SharedData:
    # "franka" 또는 "flowbot". SpaceMouse는 둘 중 이 값에 해당하는 쪽만
    # 열어서 독점 사용 -- 라이브러리(pyspacemouse vs libspnav)를 통일하지
    # 않고, 대신 한 번에 한쪽만 디바이스를 열게 해서 충돌을 피함.
    active_mode: str = "franka"

    running: bool = True
    lock: Lock = field(default_factory=Lock)
