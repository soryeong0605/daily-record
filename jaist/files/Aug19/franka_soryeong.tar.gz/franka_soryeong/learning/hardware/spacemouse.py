"""
Custom SpaceMouse Controller using libspnav directly (Linux) or easyhid (Windows)

Axis Mapping (SpaceMouse Raw → Robot):
    Linear:
        SpaceMouse X → Robot X (left/right)
        SpaceMouse Z → Robot Y (forward/backward)
        SpaceMouse Y → Robot Z (up/down)

    Rotation:
        SpaceMouse RX → Robot RX (roll)
        SpaceMouse RZ → Robot RY (pitch)
        SpaceMouse RY → Robot RZ (yaw/twist)

FIX (2026-08-11): teleop.py에서 계속 "Failed to read from HID device: -1"
반복되던 문제 -- Windows 경로가 pyspacemouse 기반 리더(flowbot.spacemouse_control
.SpaceMouseReader)를 쓰고 있었는데, 이 장치의 리포트를 pyspacemouse가 정상
파싱 못 하는 문제가 이미 spacemouse_control_v13_diag.py에서 확인/해결된
상태였음 (easyhid로 직접 raw HID 리포트를 읽는 방식으로 우회). 그 검증된
easyhid 기반 리더를 여기로 그대로 이식.
"""

import ctypes
from ctypes import c_int, c_uint, Structure, POINTER, byref
import numpy as np
import threading
from typing import Optional
import os
import sys
FILE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PARENT_DIR = os.path.dirname(FILE_DIR)
sys.path.insert(0, PARENT_DIR)


# spnav event types
SPNAV_EVENT_MOTION = 1
SPNAV_EVENT_BUTTON = 2


class SpnavMotionEvent(Structure):
    _fields_ = [
        ("type", c_int),
        ("x", c_int),
        ("y", c_int),
        ("z", c_int),
        ("rx", c_int),
        ("ry", c_int),
        ("rz", c_int),
        ("period", c_uint),
        ("data", ctypes.c_void_p),
    ]


class SpnavButtonEvent(Structure):
    _fields_ = [
        ("type", c_int),
        ("press", c_int),
        ("bnum", c_int),
    ]


class SpnavEvent(ctypes.Union):
    _fields_ = [
        ("type", c_int),
        ("motion", SpnavMotionEvent),
        ("button", SpnavButtonEvent),
    ]

# -------------------------
# SpaceMouse adapter (Linux vs Windows)
# -------------------------
import platform

class _BaseSpaceMouse:
    """Threaded SpaceMouse reader with cached latest xyz."""
    def __init__(self, device_index: int):
        self.device_index = device_index
        self._lock = threading.Lock()
        self._latest_xyz = np.zeros(3, dtype=float)
        self._button_status = [False,False]
        self._running = threading.Event()
        self._thread: Optional[threading.Thread] = None

    def start(self):
        if self._thread is not None and self._thread.is_alive():
            return
        self._running.set()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._running.clear()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
        self._thread = None

    def get_latest_xyz(self) -> np.ndarray:
        with self._lock:
            return self._latest_xyz.copy()

    def get_button_status(self):
        with self._lock:
            return self._button_status.copy()
    # subclass must implement this
    def _read_xyz_once(self) -> np.ndarray:
        raise NotImplementedError

    def _run(self):
        # choose a polling rate. 200 Hz is usually enough.
        dt = 1.0 / 200.0
        while self._running.is_set():
            try:
                xyz,button_status = self._read_xyz_once()
                xyz = np.asarray(xyz, dtype=float).reshape(3,)
                with self._lock:
                    self._latest_xyz[:] = xyz
                    self._button_status = button_status
            except Exception:
                # don’t kill thread on transient read errors
                pass
            # tiny sleep to avoid 100% CPU
            threading.Event().wait(dt)


# ---------------------------------------------------------------------------
# Windows: easyhid 기반 리더 (검증된 버전, spacemouse_control_v13_diag.py에서 이식)
# ---------------------------------------------------------------------------
class _EasyHidSpaceMouseReader:
    """3Dconnexion 장치를 easyhid로 직접 열어서 raw HID 리포트를 파싱.
    (pyspacemouse의 open()/read()가 이 장치의 리포트를 정상적으로
    파싱하지 못해 계속 실패하는 문제가 있어, easyhid로 직접 접근함.
    x축은 실측으로 부호가 반대라 scale=-1로 반전 적용됨.)
    버튼 상태는 이 리포트 포맷에서 별도로 안 다뤄서 항상 [False, False]."""

    VENDOR_ID = 9583  # 0x256F, 3Dconnexion

    def __init__(self, device_index: int = 0):
        self.device_index = device_index
        self._lock = threading.Lock()
        self._latest_xyz = np.zeros(3, dtype=float)
        self._running = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._target = None

    @staticmethod
    def _parse_axis(data, byte1, byte2, scale, axis_scale=350.0):
        raw = data[byte1] | (data[byte2] << 8)
        if raw >= 32768:
            raw -= 65536
        return raw * scale / axis_scale

    def _find_device(self):
        import easyhid
        en = easyhid.Enumeration()
        devices = en.find(vid=self.VENDOR_ID)
        candidates = [d for d in devices if d.usage_page == 1 and d.usage == 8]
        if not candidates:
            raise RuntimeError("3Dconnexion movement interface not found")
        if self.device_index >= len(candidates):
            raise RuntimeError(
                f"device_index={self.device_index} 요청했지만 매칭되는 장치가 "
                f"{len(candidates)}개뿐임 (0~{len(candidates)-1}만 유효)"
            )
        return candidates[self.device_index]

    def start(self):
        self._running.set()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self):
        self._running.clear()
        if self._thread is not None:
            self._thread.join(timeout=1.0)
        if self._target is not None:
            try:
                self._target.close()
            except Exception:
                pass

    def get_latest_xyz(self) -> np.ndarray:
        with self._lock:
            return self._latest_xyz.copy()

    def get_button_status(self):
        return [False, False]

    def _run(self):
        import time as _time
        while self._running.is_set():
            try:
                self._target = self._find_device()
                self._target.open()
                print(f"[spacemouse] connected: {self._target.path}")

                while self._running.is_set():
                    try:
                        data = self._target.read(64)
                    except Exception as read_err:
                        print(f"[spacemouse] read error: {read_err}, reconnecting...")
                        break

                    if data and data[0] == 1:
                        x = self._parse_axis(data, 1, 2, -1)   # x축 반전 (실측 확인됨)
                        y = self._parse_axis(data, 3, 4, -1)
                        z = self._parse_axis(data, 5, 6, -1)
                        with self._lock:
                            self._latest_xyz[:] = [x, y, z]

            except Exception as conn_err:
                if not self._running.is_set():
                    break
                print(f"[spacemouse] connection error: {conn_err}, retrying in 1s...")
                _time.sleep(1.0)


def _build_spacemouse(device_index: int = 0,os_name: str = 'linux',deadzone : float = 0.1, max_value: float = 350.0) -> _BaseSpaceMouse:
    os_name = platform.system().lower()

    # Linux: libspnav spacemouse.py
    if "linux" in os_name:

        class _LinuxSpaceMouse(_BaseSpaceMouse):
            def __init__(self, device_index: int):
                super().__init__(device_index)
                self._sm = SpaceMouse(deadzone=deadzone, max_value=max_value)

            def _read_xyz_once(self) -> np.ndarray:
                state6 = self._sm.get_motion_state_transformed()  # [x,y,z,rx,ry,rz]
                xyz = np.asarray(state6[:3], dtype=float)
                # axis/sign convention (edit if needed)
                button_status = self._sm.get_all_buttons()
                return np.array([xyz[0], xyz[1], xyz[2]], dtype=float),button_status

            def stop(self):
                super().stop()
                try:
                    self._sm.close()
                except Exception:
                    pass

        sm = _LinuxSpaceMouse(device_index)
        sm.start()
        return sm

    # Windows: easyhid 기반 리더 (FIX: pyspacemouse -> easyhid로 교체됨)
    if "windows" in os_name:
        # hidapi.dll 검색 경로 추가 (이 파일 기준 두 단계 위, 예: ...\learning\learning\hidapi.dll)
        try:
            hidapi_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            if hasattr(os, "add_dll_directory"):
                os.add_dll_directory(hidapi_dir)
        except Exception as e:
            print(f"[spacemouse] hidapi.dll 경로 추가 실패(무시하고 계속): {e}")

        class _WindowsSpaceMouse(_BaseSpaceMouse):
            def __init__(self, device_index: int):
                super().__init__(device_index)
                self._reader = _EasyHidSpaceMouseReader(device_index=device_index)
                self._reader.start()

            def _read_xyz_once(self):
                xyz = np.asarray(self._reader.get_latest_xyz(), dtype=float)
                button_status = self._reader.get_button_status()
                return np.array([xyz[0], xyz[1], xyz[2]], dtype=float), button_status

            def stop(self):
                super().stop()
                try:
                    self._reader.stop()
                except Exception:
                    pass

        sm = _WindowsSpaceMouse(device_index)
        sm.start()
        return sm

    raise RuntimeError(f"Unsupported OS: {platform.system()}")


class SpaceMouse:
    """
    SpaceMouse controller using libspnav directly. (Linux 전용)

    Axis mapping đã được calibrate cho robot UR5e:
        Linear:
            X = left/right (SpaceMouse X)
            Y = forward/backward (SpaceMouse Z)
            Z = up/down (SpaceMouse Y)
        Rotation:
            RX = roll (SpaceMouse RX) - disabled
            RY = pitch (SpaceMouse RZ) - disabled
            RZ = yaw/twist (SpaceMouse RY)

    Usage:
        with SpaceMouse() as sm:
            state = sm.get_motion_state_transformed()
            # state = [x, y, z, rx, ry, rz] normalized to [-1, 1]

            if sm.is_button_pressed(0):  # Left button
                print("Left button pressed")
    """

    def __init__(self, deadzone: float = 0.1, max_value: float = 350.0):
        """
        Initialize SpaceMouse

        Args:
            deadzone: Values below this threshold are set to 0
            max_value: Raw value for normalization (output will be [-1, 1])
        """
        self.deadzone = deadzone
        self.max_value = max_value
        self.lib = None

        # Raw state from SpaceMouse
        self._x = self._y = self._z = 0
        self._rx = self._ry = self._rz = 0
        self._buttons = [False, False]

        # Load libspnav
        try:
            self.lib = ctypes.CDLL("libspnav.so")
        except OSError:
            try:
                self.lib = ctypes.CDLL("libspnav.so.0")
            except OSError:
                raise RuntimeError(
                    "Cannot load libspnav. Install: sudo apt install libspnav-dev"
                )

        # Setup function signatures
        self.lib.spnav_open.restype = c_int
        self.lib.spnav_close.restype = c_int
        self.lib.spnav_poll_event.argtypes = [POINTER(SpnavEvent)]
        self.lib.spnav_poll_event.restype = c_int

        # Open connection
        if self.lib.spnav_open() == -1:
            raise RuntimeError(
                "Cannot connect to spacenavd. "
                "Check: systemctl status spacenavd"
            )

        print("SpaceMouse connected (libspnav)")

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()
        return False

    def _poll(self):
        """Poll for events and update internal state"""
        event = SpnavEvent()

        while self.lib.spnav_poll_event(byref(event)) != 0:
            if event.type == SPNAV_EVENT_MOTION:
                self._x = event.motion.x
                self._y = event.motion.y
                self._z = event.motion.z
                self._rx = event.motion.rx
                self._ry = event.motion.ry
                self._rz = event.motion.rz
            elif event.type == SPNAV_EVENT_BUTTON:
                if event.button.bnum < len(self._buttons):
                    self._buttons[event.button.bnum] = bool(event.button.press)

    def _apply_deadzone(self, value: float) -> float:
        """Apply deadzone to normalized value"""
        if abs(value) < self.deadzone:
            return 0.0
        return value

    def get_motion_state_transformed(self) -> np.ndarray:
        """
        Get motion state with correct axis mapping for robot control.

        Returns:
            np.ndarray: [x, y, z, rx, ry, rz] normalized to approximately [-1, 1]
        """
        self._poll()

        x = self._apply_deadzone(self._x / self.max_value)   # SM X → Robot X
        y = self._apply_deadzone(self._z / self.max_value)   # SM Z → Robot Y
        z = self._apply_deadzone(self._y / self.max_value)   # SM Y → Robot Z

        rx = self._apply_deadzone(self._rx / self.max_value)
        ry = self._apply_deadzone(self._ry / self.max_value)
        rz = self._apply_deadzone(self._rz / self.max_value)

        return np.array([x, y, z, rx, ry, rz], dtype=np.float64)

    def get_raw_state(self) -> dict:
        """Get raw SpaceMouse values (for debugging)"""
        self._poll()
        return {
            'x': self._x,
            'y': self._y,
            'z': self._z,
            'rx': self._rx,
            'ry': self._ry,
            'rz': self._rz,
        }

    def is_button_pressed(self, button: int) -> bool:
        """Check if a button is currently pressed."""
        self._poll()
        if 0 <= button < len(self._buttons):
            return self._buttons[button]
        return False

    def get_all_buttons(self) -> list:
        """Get state of all buttons"""
        self._poll()
        return self._buttons.copy()

    def close(self):
        """Close SpaceMouse connection"""
        if self.lib:
            self.lib.spnav_close()
            print("SpaceMouse disconnected")
