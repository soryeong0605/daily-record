"""
teleop_feedforward.py - teleop.py의 순수 feedforward 경로만 남긴 경량 버전.

PID/OptiTrack 관련 코드를 전부 걷어냈기 때문에 online_optitrack.py,
position_pid.py, workspace.py 파일이 없어도 그냥 실행됨.
(원본 teleop.py는 이 파일들이 없으면 --pid를 안 써도 import 단계에서
ModuleNotFoundError로 죽었음 -- 그 문제를 피하기 위해 아예 뺌.)

남긴 것: SpaceMouse -> fb.step(xyz) feedforward 경로, PWM 꼭짓점(0~26)
+ 3평면(XY/XZ/YZ) 그래프(plot_helper.highlight_pwm_corners), 'r' 리셋.
"""

from __future__ import annotations

import time
import argparse
import platform

import numpy as np
import matplotlib.pyplot as plt

from kinematic_modeling import Flow_driven_bellow

import os
import sys
FILE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(FILE_DIR)
GRANDPARENT_DIR = os.path.dirname(PARENT_DIR)
sys.path.insert(0, GRANDPARENT_DIR)
sys.path.insert(0, PARENT_DIR)
from learning.hardware.spacemouse import _build_spacemouse

# -------------------------
# Control settings
# -------------------------
SEND_HZ = 30.0
DEADZONE = 0.1
PWM_MIN = 0
PWM_MAX = 26


def main():
    from learning.hardware import flowbot

    ap = argparse.ArgumentParser()
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--pwm-min", "-mi", type=int, default=1)
    ap.add_argument("--pwm-max", "-ma", type=int, default=25)
    ap.add_argument("--send-hz", type=float, default=SEND_HZ)
    ap.add_argument("--pressure-model", '-p', choices=["learned", "linear"], default="linear")
    args = ap.parse_args()

    os_name = platform.system().lower()
    if "linux" in os_name:
        serial_port = "/dev/ttyACM0"
    elif "windows" in os_name:
        serial_port = "COM9"
    CONTROL_HZ = 30.0

    fb = flowbot.flowbot(
        serial_port=serial_port,
        pwm_min=0,
        pwm_max=26,
        enable_plot=True,
        frequency=CONTROL_HZ,
        max_pos_speed=50,
        pressure_model=args.pressure_model,
    )

    sm_fb = _build_spacemouse(os_name=os_name)
    sm_fb.start()

    fb.start()
    fb.pl.highlight_pwm_corners(fb.axes, fb.flowbot, pwm_max=26)

    # --- keyboard: 'r' resets pc to init and sends [0,0,0] ---
    def _on_key(event):
        if event.key == 'r':
            fb.reset()
            print("Reset: pc ->", fb.pc, "  pwm -> [0,0,0]")

    if fb.fig is not None:
        fb.fig.canvas.mpl_connect('key_press_event', _on_key)

    PLOT_HZ_LOCAL = 30.0
    plot_dt = 1.0 / PLOT_HZ_LOCAL
    t_next_plot = time.perf_counter()

    print("Teleop running in feedforward-only mode. Press 'r' to reset. Close plot window or Ctrl+C to stop.")
    try:
        while (fb.fig is None) or plt.fignum_exists(fb.fig.number):
            t_now = time.perf_counter()

            xyz = sm_fb.get_latest_xyz()
            xyz[2] = -xyz[2]
            xyz = np.where(np.abs(xyz) < DEADZONE, 0.0, xyz)

            fb.step(xyz)   # 순수 feedforward, PID/OptiTrack 없음

            if fb.pl is not None and t_now >= t_next_plot:
                fb.update_plot()
                t_next_plot += plot_dt

    except KeyboardInterrupt:
        pass
    finally:
        sm_fb.stop()
        fb.stop()
        time.sleep(0.5)


if __name__ == "__main__":
    main()
