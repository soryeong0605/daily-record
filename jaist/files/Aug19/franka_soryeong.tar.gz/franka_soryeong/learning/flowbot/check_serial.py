"""
check_serial.py - 아두이노가 시리얼로 뭘 보내는지 그냥 그대로 찍어서 확인.
PWM 명령도 한 번 보내보고, ACK가 돌아오는지 직접 확인.

사용법:
    python check_serial.py
"""

import serial
import time

PORT = "/dev/ttyACM0"
BAUD = 115200

ser = serial.Serial(PORT, BAUD, timeout=1)
time.sleep(2)  # 아두이노 리셋 대기

print(f"[check_serial] {PORT} 열림. 5초간 아두이노가 보내는 걸 그대로 출력합니다...")

t_end = time.time() + 5
while time.time() < t_end:
    line = ser.readline()
    if line:
        print("[ARDUINO]", line.decode(errors="ignore").strip())

print("\n[check_serial] PWM 명령 '5 5 5' 전송...")
ser.write(b"5 5 5\n")

t_end = time.time() + 3
got_ack = False
while time.time() < t_end:
    line = ser.readline()
    if line:
        text = line.decode(errors="ignore").strip()
        print("[ARDUINO]", text)
        if text.startswith("ACK"):
            got_ack = True

if got_ack:
    print("\n[check_serial] ACK 받음 -- 아두이노가 명령을 정상 처리 중.")
else:
    print("\n[check_serial] ACK 못 받음 -- 아두이노가 명령을 못 받거나 응답을 안 하고 있음.")

ser.close()