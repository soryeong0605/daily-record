"""
plot_task.py - SpaceMouse raw 입력과 실제 커맨드된 속도를 위아래 두 그래프로
실시간 표시.

matplotlib GUI는 메인 스레드에서 돌려야 하므로(대부분의 백엔드에서 스레드
제약이 있음), 이 모듈은 별도 Thread로 만들지 않고 main.py의 메인 스레드
에서 run_plot(shared)을 직접 호출하는 방식으로 씀. plt.show()가 blocking
콜이라 창을 닫으면 shared.running=False로 바꿔서 다른 스레드들도 같이
종료되게 함.
"""

import matplotlib
matplotlib.use("TkAgg")  # 환경에 따라 Qt5Agg 등으로 바꿔야 할 수 있음

import matplotlib.pyplot as plt
import matplotlib.animation as animation


PLOT_WINDOW_SEC = 10.0   # x축에 보여줄 최근 시간 범위 (초)
UPDATE_INTERVAL_MS = 100  # 그래프 갱신 주기


def run_plot(shared):

    fig, (ax_raw, ax_vel) = plt.subplots(2, 1, sharex=True, figsize=(8, 6))
    fig.canvas.manager.set_window_title("SpaceMouse Input vs Commanded Velocity")

    # =========================
    # 위: SpaceMouse raw 입력 (-1~1)
    # =========================

    line_x, = ax_raw.plot([], [], label="x (raw)")
    line_y, = ax_raw.plot([], [], label="y (raw)")
    line_yaw, = ax_raw.plot([], [], label="yaw (raw)")

    ax_raw.set_ylim(-1.1, 1.1)
    ax_raw.set_ylabel("SpaceMouse raw input")
    ax_raw.legend(loc="upper right")
    ax_raw.grid(True)

    # =========================
    # 아래: 실제 로봇에 나간 속도
    # =========================

    line_vx, = ax_vel.plot([], [], label="vx")
    line_vy, = ax_vel.plot([], [], label="vy")
    line_vz, = ax_vel.plot([], [], label="vz")
    line_wz, = ax_vel.plot([], [], label="wz")

    ax_vel.set_ylabel("Commanded velocity (m/s, rad/s)")
    ax_vel.set_xlabel("time (s)")
    ax_vel.legend(loc="upper right")
    ax_vel.grid(True)

    all_lines = (line_x, line_y, line_yaw, line_vx, line_vy, line_vz, line_wz)

    def update(_frame):

        with shared.lock:
            t = list(shared.plot_time)
            rx = list(shared.plot_raw_x)
            ry = list(shared.plot_raw_y)
            ryaw = list(shared.plot_raw_yaw)
            vx = list(shared.plot_vx)
            vy = list(shared.plot_vy)
            vz = list(shared.plot_vz)
            wz = list(shared.plot_wz)

        if not t:
            return all_lines

        line_x.set_data(t, rx)
        line_y.set_data(t, ry)
        line_yaw.set_data(t, ryaw)

        line_vx.set_data(t, vx)
        line_vy.set_data(t, vy)
        line_vz.set_data(t, vz)
        line_wz.set_data(t, wz)

        t_max = t[-1]
        t_min = max(0.0, t_max - PLOT_WINDOW_SEC)
        ax_raw.set_xlim(t_min, t_max + 0.1)
        ax_vel.set_xlim(t_min, t_max + 0.1)

        # 속도 y축은 현재 창 범위 안 최대값 기준으로 살짝 여유 두고 자동 조정
        vel_all = vx + vy + vz + wz
        v_peak = max(abs(v) for v in vel_all) if vel_all else 0.05
        v_lim = max(0.02, v_peak * 1.2)
        ax_vel.set_ylim(-v_lim, v_lim)

        return all_lines

    ani = animation.FuncAnimation(
        fig, update, interval=UPDATE_INTERVAL_MS, blit=False, cache_frame_data=False
    )

    plt.tight_layout()
    plt.show()   # 창을 닫을 때까지 blocking

    # 창을 닫으면 다른 스레드들도 종료되도록
    with shared.lock:
        shared.running = False
