import threading
import time

import numpy as np
import pyspacemouse

# =========================
# TUNABLE PARAMETERS
# =========================

READ_HZ = 60.0
READ_DT = 1.0 / READ_HZ

DEADBAND_X = 0.12
DEADBAND_Y = 0.12
DEADBAND_YAW = 0.12

RAW_MAX = 0.80
RAW_YAW_MAX = 1.00

MAX_LINEAR_SPEED = 0.03   # m/s, 고정 속도 (digital 모드 -- 세게 밀든 살짝 밀든 속도는 동일)
MAX_YAW_SPEED = 0.5       # rad/s

# yaw 비틀 때 손목이 새어나가는 x/y 를 죽이기 위한 상호배타 비율
YAW_EXCLUSIVITY_RATIO = 1.5

# 장치가 실제로 새 패킷을 보낸 시점(state.t)이 이 시간 이상 안 바뀌면
# "입력 끊김/고착"으로 보고 강제로 0속도. 손 뗐을 때 리시버가 0 리포트를
# 안 보내는 경우, 우리가 매 루프마다 stamp를 새로 찍어버리면 franka_cosine
# 쪽 command_timeout(0.35s) 안전장치가 무력화됨 -- 이걸 막기 위한 워치독.
STALE_TIMEOUT = 0.15


def _map_axis(raw, deadband, max_speed):
    """데드밴드 넘으면 고정 속도(+-max_speed), 안 넘으면 0."""
    if abs(raw) < deadband:
        return 0.0
    return max_speed if raw > 0 else -max_speed


def _normalize_linear(vx, vy, max_speed):
    """
    x/y를 동시에 밀면(대각선) digital 모드 특성상 sqrt(vx^2+vy^2)가
    max_speed보다 커져서 (최대 약 1.4배) 단일 축보다 빨라지는 문제가 있음.
    방향은 유지한 채 크기만 max_speed로 눌러줌.
    z는 버튼으로 별도 구동이라 여기 정규화에 포함 안 함.
    """
    v = np.array([vx, vy], dtype=float)
    norm = float(np.linalg.norm(v))
    if norm > max_speed and norm > 1e-9:
        v = v / norm * max_speed
    return float(v[0]), float(v[1])


class SpaceMouseTask(threading.Thread):
    """
    SpaceMouse를 읽어서 '이미 속도로 변환된' 목표를 shared.spacemouse에 씀.

    Franka는 Dobot(ServoP)과 다르게 매 tick마다 속도/궤적 목표를 직접
    만들어줘야 해서, 여기서는 일정한 속력(digital 모드)의 속도 커맨드까지만
    계산해 넘기고, 실제 가속도 스무딩(코사인 커브)은 franka_task.py의
    HybridVelocitySmoother가 담당한다.
    """

    def __init__(self, shared):
        super().__init__()
        self.shared = shared
        self.last_state_t = None
        self.last_fresh_time = time.time()
        self.was_stale = False

    def run(self):

        device = pyspacemouse.open()

        if not device:
            print("SpaceMouse not found")
            return

        print("SpaceMouse connected")

        last_print = 0.0

        while self.shared.running:

            state = device.read()

            if state is None:
                time.sleep(READ_DT)
                continue

            raw_x = float(state.x)
            raw_y = float(state.y)
            raw_yaw = float(state.yaw)
            buttons = list(state.buttons)

            # =========================
            # 패킷 신선도 체크 (안전장치)
            # =========================
            # state.t는 장치 자체가 찍는 타임스탬프. 이게 바뀌지 않았다는건
            # 새 HID 패킷이 안 왔다는 뜻 -- 즉 손 뗀 뒤 값이 그대로
            # 캐싱되어 있을 수 있는 상태. 이럴 땐 무조건 0속도로 덮어씀.

            now = time.time()

            if state.t != self.last_state_t:
                self.last_state_t = state.t
                self.last_fresh_time = now

            stale = (now - self.last_fresh_time) > STALE_TIMEOUT

            if stale and not self.was_stale:
                print("[SpaceMouse] 입력 끊김 감지 -> 강제 0속도")
            self.was_stale = stale

            b_down = int(buttons[0]) if len(buttons) > 0 else 0
            b_up = int(buttons[14]) if len(buttons) > 14 else 0

            vx = _map_axis(raw_x, DEADBAND_X, MAX_LINEAR_SPEED)
            vy = _map_axis(raw_y, DEADBAND_Y, MAX_LINEAR_SPEED)
            wz = _map_axis(raw_yaw, DEADBAND_YAW, MAX_YAW_SPEED)

            # =========================
            # YAW / TRANSLATION 상호배타
            # =========================

            trans_mag = max(abs(raw_x), abs(raw_y)) / RAW_MAX
            yaw_mag = abs(raw_yaw) / RAW_YAW_MAX

            if yaw_mag > trans_mag * YAW_EXCLUSIVITY_RATIO:
                vx = 0.0
                vy = 0.0
            elif trans_mag > yaw_mag * YAW_EXCLUSIVITY_RATIO:
                wz = 0.0
            else:
                vx = 0.0
                vy = 0.0
                wz = 0.0

            # =========================
            # X/Y 대각선 속도 정규화
            # =========================

            vx, vy = _normalize_linear(vx, vy, MAX_LINEAR_SPEED)

            # =========================
            # Z (버튼 기반)
            # =========================

            if b_down == 1 and b_up == 0:
                vz = -MAX_LINEAR_SPEED
            elif b_up == 1 and b_down == 0:
                vz = MAX_LINEAR_SPEED
            else:
                vz = 0.0

            # =========================
            # STALE -> 강제 0
            # =========================

            if stale:
                vx = 0.0
                vy = 0.0
                vz = 0.0
                wz = 0.0

            # =========================
            # SAVE
            # =========================

            with self.shared.lock:
                self.shared.spacemouse["vx"] = vx
                self.shared.spacemouse["vy"] = vy
                self.shared.spacemouse["vz"] = vz
                self.shared.spacemouse["wz"] = wz
                self.shared.spacemouse["stamp"] = time.time()

            # =========================
            # DEBUG PRINT (0.5초에 한 번)
            # =========================

            now = time.time()
            if now - last_print > 0.5:
                last_print = now
                print(f"[SpaceMouse] vx={vx:+.3f} vy={vy:+.3f} vz={vz:+.3f} wz={wz:+.3f}")

            time.sleep(READ_DT)
