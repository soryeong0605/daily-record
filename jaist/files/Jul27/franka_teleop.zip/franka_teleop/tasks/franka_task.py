import threading
import time

import numpy as np

from franka_cosine import FrankaController, NativeVelocityConfig


class FrankaTask(threading.Thread):
    """
    Franka 로봇 담당 Task.

    Dobot(robot_arm_task.py)은 매 tick마다 ServoP로 목표 pose 하나씩 던지면
    끝났지만, Franka는 libfranka 콜백 루프가 매 tick마다 속도/궤적 목표를
    "직접" 만들어주길 요구함. 그래서 실제 스무딩 + 서보 루프는
    FrankaController(franka_cosine.py) 안의 HybridVelocitySmoother +
    start_ee_velocity_servo가 자체 스레드로 담당하고, 이 Task는 그 서보
    세션을 켜고 끄면서 shared 상태(TCP pose, 실제로 나간 속도)만 갱신함.
    """

    def __init__(self, shared, ip="172.16.0.2", recover=True):
        super().__init__()
        self.shared = shared
        self.ip = ip
        self.recover = recover
        self.franka = None

    # =========================
    # VELOCITY GETTER
    # =========================
    # FrankaController가 매 control tick마다 부르는 콜백.
    # spacemouse_task.py가 이미 계산해둔 목표 속도를 그대로 넘겨줌.

    def get_velocity(self):
        with self.shared.lock:
            sm = dict(self.shared.spacemouse)
        return sm["vx"], sm["vy"], sm["vz"], sm["wz"], sm["stamp"]

    def run(self):

        self.franka = FrankaController(
            ip=self.ip,
            use_gripper=False,
            realtime=False,
        )

        if self.recover:
            self.franka.recover_errors()

        # spacemouse_task.py의 MAX_LINEAR_SPEED(0.03)와 동일하게 맞춤.
        # 여기 값이 더 크면 스무더 쪽 클리핑이 사실상 안 걸려서 의미가
        # 없고, 더 작으면 spacemouse가 낸 속도를 이 cfg가 다시 깎아버림.
        cfg = NativeVelocityConfig(
            max_linear_speed=0.03,
            max_yaw_speed=0.5,
            transition_time_up=0.60,
            transition_time_down=0.25,
            command_timeout=0.35,
            startup_zero_time=0.8,
        )

        self.franka.start_ee_velocity_servo(
            velocity_getter=self.get_velocity,
            cfg=cfg,
        )

        while self.shared.running:

            # =========================
            # TCP POSE
            # =========================

            O_T_EE = self.franka.get_ee()
            pose = np.array([O_T_EE[12], O_T_EE[13], O_T_EE[14]])

            # 스무더 통과 후 실제로 로봇에 나간 속도 [vx,vy,vz,0,0,wz]
            sent = self.franka.latest_sent_velocity

            with self.shared.lock:
                self.shared.robot_pose = pose
                self.shared.sent_velocity = [
                    sent[0], sent[1], sent[2], sent[5]
                ]

            time.sleep(0.05)

        # =========================
        # SHUTDOWN
        # =========================

        try:
            self.franka.stop_ee_velocity_servo()
        except Exception as e:
            print(e)
