import threading
import time

import numpy as np
import pyspacemouse

# =========================
# TUNABLE PARAMETERS (spacemouse.py 원본과 동일)
# =========================

READ_HZ = 60.0
READ_DT = 1.0 / READ_HZ

DEADBAND_X = 0.12
DEADBAND_Y = 0.12
DEADBAND_YAW = 0.12

RAW_X_MIN = -0.80
RAW_X_MAX = +0.80

RAW_Y_MIN = -0.80
RAW_Y_MAX = +0.80

RAW_YAW_MIN = -1.00
RAW_YAW_MAX = +1.00

MAX_VX_POS = +0.03
MAX_VX_NEG = -0.03

MAX_VY_POS = +0.03
MAX_VY_NEG = -0.03

BUTTON_Z_SPEED = 0.03

MAX_WZ_POS = +0.5
MAX_WZ_NEG = -0.5

SIGN_X = +1.0
SIGN_Y = +1.0
SIGN_Z = +1.0
SIGN_YAW = +1.0

# yaw vs translation 상호배타 처리용 비율
YAW_EXCLUSIVITY_RATIO = 1.5

INPUT_MODE = "digital"


def clamp(value, low, high):
    return max(low, min(high, value))


def map_raw_axis_to_unit(raw_value, raw_min, raw_max, deadband):
    if abs(raw_value) < deadband:
        return 0.0

    if raw_value > 0.0:
        if raw_max <= deadband:
            return 0.0
        return clamp((raw_value - deadband) / (raw_max - deadband), 0.0, 1.0)

    if raw_min >= -deadband:
        return 0.0

    return clamp((raw_value + deadband) / (abs(raw_min) - deadband), -1.0, 0.0)


def unit_to_velocity(unit_value, max_positive_velocity, max_negative_velocity, mode="digital"):
    """
    mode="digital": 데드밴드 넘으면 고정 속도 (세게 밀든 살짝 밀든 동일).
    mode="analog": 미는 세기에 비례.
    """
    if mode == "digital":
        if unit_value > 0.0:
            return max_positive_velocity
        if unit_value < 0.0:
            return max_negative_velocity
        return 0.0

    if unit_value > 0.0:
        return unit_value * max_positive_velocity
    if unit_value < 0.0:
        return abs(unit_value) * max_negative_velocity
    return 0.0


def normalize_linear(vx, vy, max_speed):
    """대각선(x+y 동시) 입력이 max_speed*sqrt(2)로 빨라지는 것 방지."""
    v = np.array([vx, vy], dtype=float)
    norm = float(np.linalg.norm(v))
    if norm > max_speed and norm > 1e-9:
        v = v / norm * max_speed
    return float(v[0]), float(v[1])


class SpaceMouseTask(threading.Thread):
    """
    spacemouse.py의 command_from_state() 로직을 그대로 옮긴 버전.
    차이는 멀티프로세싱(mp.Array) 대신 스레드 + shared(lock)를 쓴다는 것뿐,
    속도/데드밴드/버튼 매핑 계산은 전부 동일.
    """

    def __init__(self, shared, mode=INPUT_MODE):
        super().__init__()
        self.shared = shared
        self.mode = mode

    def run(self):

        device = pyspacemouse.open()

        if not device:
            print("SpaceMouse not found")
            return

        print("SpaceMouse connected")

        while self.shared.running:

            state = device.read()

            if state is None:
                time.sleep(READ_DT)
                continue

            now = time.time()

            raw_x = float(state.x)
            raw_y = float(state.y)
            raw_yaw = float(state.yaw)
            buttons = list(state.buttons)

            b0 = int(buttons[0]) if len(buttons) > 0 else 0
            # 물리적 +Z 버튼은 index 14에서 뜸 (test_buttons_only.py로 확인된 사항)
            b1 = int(buttons[14]) if len(buttons) > 14 else 0

            x_unit = map_raw_axis_to_unit(SIGN_X * raw_x, RAW_X_MIN, RAW_X_MAX, DEADBAND_X)
            y_unit = map_raw_axis_to_unit(SIGN_Y * raw_y, RAW_Y_MIN, RAW_Y_MAX, DEADBAND_Y)
            yaw_unit = map_raw_axis_to_unit(SIGN_YAW * raw_yaw, RAW_YAW_MIN, RAW_YAW_MAX, DEADBAND_YAW)

            # =========================
            # YAW / TRANSLATION 상호배타
            # =========================

            trans_mag = max(abs(raw_x) / RAW_X_MAX, abs(raw_y) / RAW_Y_MAX)
            yaw_mag = abs(raw_yaw) / RAW_YAW_MAX

            if yaw_mag > trans_mag * YAW_EXCLUSIVITY_RATIO:
                x_unit = 0.0
                y_unit = 0.0
            elif trans_mag > yaw_mag * YAW_EXCLUSIVITY_RATIO:
                yaw_unit = 0.0
            else:
                x_unit = 0.0
                y_unit = 0.0
                yaw_unit = 0.0

            vx = unit_to_velocity(x_unit, MAX_VX_POS, MAX_VX_NEG, self.mode)
            vy = unit_to_velocity(y_unit, MAX_VY_POS, MAX_VY_NEG, self.mode)
            wz = unit_to_velocity(yaw_unit, MAX_WZ_POS, MAX_WZ_NEG, self.mode)

            # =========================
            # Z (버튼 기반)
            # =========================

            if b0 == 1 and b1 == 0:
                vz = -SIGN_Z * BUTTON_Z_SPEED
            elif b1 == 1 and b0 == 0:
                vz = +SIGN_Z * BUTTON_Z_SPEED
            else:
                vz = 0.0

            vx, vy = normalize_linear(vx, vy, MAX_VX_POS)

            # =========================
            # SAVE
            # =========================

            with self.shared.lock:
                self.shared.spacemouse["vx"] = vx
                self.shared.spacemouse["vy"] = vy
                self.shared.spacemouse["vz"] = vz
                self.shared.spacemouse["wz"] = wz
                self.shared.spacemouse["stamp"] = now

            time.sleep(READ_DT)
