import time

from shared import SharedData

from tasks.spacemouse_task import SpaceMouseTask
from tasks.franka_task import FrankaTask
from tasks.logger_task import LoggerTask
from tasks.keypress_task import KeypressTask


# =========================
# ROBOT IP
# =========================

FRANKA_IP = "172.16.0.2"


# =========================
# MAIN
# =========================

def main():

    # =========================
    # SHARED
    # =========================

    shared = SharedData()

    # =========================
    # TASKS
    # =========================

    spacemouse = SpaceMouseTask(shared)
    franka = FrankaTask(shared, ip=FRANKA_IP)
    logger = LoggerTask(shared)
    keypress = KeypressTask(shared)

    tasks = [
        spacemouse,
        franka,
        logger,
        keypress,
    ]

    # =========================
    # START
    # =========================

    for t in tasks:
        t.start()

    # =========================
    # MAIN LOOP
    # =========================

    try:

        while shared.running:
            time.sleep(0.1)

    except KeyboardInterrupt:

        with shared.lock:
            shared.running = False

    # =========================
    # JOIN
    # =========================

    for t in tasks:
        t.join()


if __name__ == "__main__":
    main()
