"""
main.py - franka_soryeong/combined_teleop/main.py

franka_teleop과 learning(flowbot)을 SpaceMouse 1번 버튼으로 전환하며
번갈아 구동. 두 쪽 다 라이브러리를 통일하지 않고(franka=pyspacemouse,
flowbot=libspnav 기반), 한 번에 한쪽만 디바이스를 열어서 씀.

- franka는 백그라운드 스레드(tasks/franka_task.py)에서 돌고, 자체적으로
  active_mode에 따라 SpaceMouse를 열고 닫음. 1번 버튼 누르면 정지 후
  (실측 속도 확인) flowbot으로 전환.
- flowbot은 matplotlib 그래프(2x2 패널)를 써서 메인 스레드에서 돌아야
  하므로, 이 main.py의 메인 루프가 flowbot 쪽을 직접 담당함. flowbot
  쪽 SpaceMouse도 active_mode=="flowbot"일 때만 열림. 1번 버튼 누르면
  즉시(정지 대기 없이) franka로 전환 -- flowbot은 마지막 PWM을 유지한
  채로 넘어가면 되니까 별도 정지 절차 필요 없음.
"""

import os
import sys
import time

import numpy as np
import matplotlib.pyplot as plt

from shared import SharedData
from tasks.franka_task import FrankaTask
from tasks.logger_task import LoggerTask

FILE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(FILE_DIR)
sys.path.insert(0, PARENT_DIR)
sys.path.insert(0, os.path.join(PARENT_DIR, "learning", "flowbot"))
from learning.hardware import flowbot as flowbot_module
from learning.hardware.spacemouse import _build_spacemouse

FRANKA_IP = "172.16.0.2"

DEADZONE = 0.1
IDLE_REFRESH_DT = 0.1   # franka 활성 중, 그래프 창이 안 얼어붙게 가끔 갱신


def main():
    shared = SharedData()

    # =========================
    # flowbot 준비 (그래프는 항상 켜둠 -- franka 활성 중엔 갱신만 멈춤)
    # =========================
    fb = flowbot_module.flowbot(
        serial_port="/dev/ttyACM0",
        pwm_min=0,
        pwm_max=26,
        enable_plot=True,
        frequency=30.0,
        max_pos_speed=50,
        pressure_model="linear",
    )
    fb.start()
    fb.pl.highlight_pwm_corners(fb.axes, fb.flowbot, pwm_max=26)

    # =========================
    # franka 백그라운드 스레드 시작 (기본 모드: franka)
    # =========================
    franka_task = FrankaTask(shared, ip=FRANKA_IP, dynamics_factor=0.05)
    franka_task.start()

    # =========================
    # 로거 스레드 (20Hz, 'c'/'s' 키로 에피소드 시작/종료)
    # =========================
    logger_task = LoggerTask(shared)
    logger_task.start()

    sm_fb = None          # flowbot용 SpaceMouse, active일 때만 open
    last_button0 = False

    print("[Main] franka 모드로 시작. SpaceMouse 1번 버튼으로 전환.")

    try:
        while shared.running and plt.fignum_exists(fb.fig.number):

            with shared.lock:
                mode = shared.active_mode

            if mode == "flowbot":
                if sm_fb is None:
                    sm_fb = _build_spacemouse(os_name="linux")
                    sm_fb.start()
                    print("[Main] flowbot active -> SpaceMouse 여는 중...")

                xyz = sm_fb.get_latest_xyz()
                buttons = sm_fb.get_button_status()
                button0 = bool(buttons[0]) if len(buttons) > 0 else False
                edge = button0 and not last_button0
                last_button0 = button0

                if edge:
                    print("[Main] 1번 버튼 감지 -> franka로 전환 (flowbot 상태 유지)")
                    sm_fb.stop()
                    sm_fb = None
                    with shared.lock:
                        shared.active_mode = "franka"
                    last_button0 = False
                    time.sleep(0.05)
                    continue

                xyz = xyz.copy()
                xyz[2] = -xyz[2]
                xyz = np.where(np.abs(xyz) < DEADZONE, 0.0, xyz)

                fb.step(xyz)   # 여기서 PWM 값이 계속 [PYTHON] Sent: ... 로 출력됨
                fb.update_plot()

                # ---- 로깅용: 매 step마다 최신 PWM/spacemouse raw 값 노출 ----
                with shared.lock:
                    shared.flowbot_pwm = np.asarray(fb.last_pwm, dtype=float)
                    shared.sm_raw = np.array(
                        [xyz[0], xyz[1], xyz[2], 0.0, float(button0), 0.0],
                        dtype=float,
                    )

            else:
                # franka 활성 중 -- flowbot 쪽은 아무것도 안 하고 그래프만
                # 가끔 갱신해서 창이 "응답 없음" 상태로 안 보이게만 함.
                if sm_fb is not None:
                    sm_fb.stop()
                    sm_fb = None
                fb.fig.canvas.flush_events()
                time.sleep(IDLE_REFRESH_DT)

    except KeyboardInterrupt:
        pass
    finally:
        with shared.lock:
            shared.running = False
        if sm_fb is not None:
            sm_fb.stop()
        franka_task.join()
        logger_task.join()
        fb.stop()
        time.sleep(0.5)


if __name__ == "__main__":
    main()
