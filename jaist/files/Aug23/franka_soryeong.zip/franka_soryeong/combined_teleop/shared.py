from dataclasses import dataclass, field
from threading import Lock

import numpy as np


@dataclass
class SharedData:
    # "franka" 또는 "flowbot". SpaceMouse는 둘 중 이 값에 해당하는 쪽만
    # 열어서 독점 사용 -- 라이브러리(pyspacemouse vs libspnav)를 통일하지
    # 않고, 대신 한 번에 한쪽만 디바이스를 열게 해서 충돌을 피함.
    active_mode: str = "franka"

    # =========================
    # LOGGING (logger_task.py가 읽기 전용으로만 참조 -- 제어 로직은
    # 이 값들을 쓰기만 하고 읽지 않음. flowbot 모드 중엔 franka_pose/
    # franka_velocity가 갱신 안 되고 "마지막 값"이 유지되는데, 그 구간
    # 동안 franka는 실제로 정지해있으니 문제 없음(의도된 설계).
    # =========================
    franka_pose: np.ndarray = field(default_factory=lambda: np.zeros(3))       # [x, y, z]
    franka_velocity: np.ndarray = field(default_factory=lambda: np.zeros(4))   # [vx, vy, vz, wz]
    flowbot_pwm: np.ndarray = field(default_factory=lambda: np.zeros(3))       # [p1, p2, p3]
    sm_raw: np.ndarray = field(default_factory=lambda: np.zeros(6))            # [x, y, z, yaw, btn0, btn_other]

    # =========================
    # RECORDING (logger_task.py가 'c'/'s' 키로 토글)
    # =========================
    recording: bool = False

    running: bool = True
    lock: Lock = field(default_factory=Lock)
