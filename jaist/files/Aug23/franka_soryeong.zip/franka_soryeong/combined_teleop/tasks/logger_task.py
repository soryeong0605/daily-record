"""
tasks/logger_task.py - franka_soryeong/combined_teleop/tasks/logger_task.py

franka_task.py / main.py의 기존 구동 로직은 건드리지 않고, shared에
노출된 값들(franka_pose, franka_velocity, flowbot_pwm, sm_raw,
active_mode)을 20Hz로 읽어서 CSV로만 저장하는 독립 스레드.

터미널에 포커스 준 상태에서:
    'c' -> 에피소드 레코딩 시작 (episodes/episode_XXXX_타임스탬프.csv 새로 생성)
    's' -> 에피소드 레코딩 종료 + 저장

주의:
- franka 모드 중엔 flowbot_pwm이 "마지막 값" 그대로 찍히고,
  flowbot 모드 중엔 franka_pose/franka_velocity가 "마지막 값" 그대로
  찍힘. 각 경우 실제로 해당 쪽이 정지해있는 상태라 문제 없음
  (의도된 설계 -- shared.py 주석 참고).
- shared.py에 이미 있는 franka/flowbot 제어 로직에는 전혀 관여하지
  않고, 값을 읽기만(read-only) 함.
"""

import csv
import os
import re
import threading
import time
from datetime import datetime

from keypress_listener import KeypressListener

LOG_HZ = 20.0
LOG_DT = 1.0 / LOG_HZ


class LoggerTask(threading.Thread):

    def __init__(self, shared, output_dir="episodes"):
        super().__init__()
        self.shared = shared
        self.output_dir = output_dir
        self.kp = KeypressListener()
        self.episode_id = self._find_last_episode_id()
        self.csv_file = None
        self.writer = None

    def _find_last_episode_id(self):
        """재시작해도 이어서 에피소드 번호를 매기기 위해 기존 파일들을 스캔."""
        if not os.path.isdir(self.output_dir):
            return 0
        max_id = 0
        pattern = re.compile(r"episode_(\d+)_")
        for name in os.listdir(self.output_dir):
            m = pattern.match(name)
            if m:
                max_id = max(max_id, int(m.group(1)))
        return max_id

    def _start_episode(self):
        self.episode_id += 1
        os.makedirs(self.output_dir, exist_ok=True)
        timestamp = time.strftime("%Y%m%d_%H%M%S")
        filepath = os.path.join(
            self.output_dir, f"episode_{self.episode_id:04d}_{timestamp}.csv"
        )
        self.csv_file = open(filepath, "w", newline="")
        self.writer = csv.writer(self.csv_file)
        self.writer.writerow([
            "timestamp", "mode",
            "franka_x", "franka_y", "franka_z",
            "vx", "vy", "vz", "wz",
            "pwm1", "pwm2", "pwm3",
            "sm_x", "sm_y", "sm_z", "sm_yaw", "btn0", "btn_other",
        ])
        print(f"\n>>> RECORDING STARTED -- episode {self.episode_id} -> {filepath} <<<\n")

    def _stop_episode(self):
        if self.csv_file:
            self.csv_file.close()
            self.csv_file = None
            self.writer = None
        print(f"\n>>> RECORDING STOPPED -- episode {self.episode_id} saved <<<\n")

    def run(self):
        self.kp.start()
        print("[Logger] 'c'=레코딩 시작, 's'=레코딩 종료+저장 (20Hz)")

        last_log_time = 0.0

        while self.shared.running:

            # ---- 키 입력: c=시작, s=종료 ----
            key = self.kp.get_key()
            if key in ("c", "C"):
                with self.shared.lock:
                    already = self.shared.recording
                    if not already:
                        self.shared.recording = True
                if not already:
                    self._start_episode()
            elif key in ("s", "S"):
                with self.shared.lock:
                    already = self.shared.recording
                    if already:
                        self.shared.recording = False
                if already:
                    self._stop_episode()

            with self.shared.lock:
                recording = self.shared.recording

            if not recording:
                time.sleep(0.02)
                continue

            # ---- 20Hz 페이싱 ----
            now = time.time()
            if now - last_log_time < LOG_DT:
                time.sleep(0.005)
                continue
            last_log_time = now

            with self.shared.lock:
                mode = self.shared.active_mode
                pose = self.shared.franka_pose.copy()
                vel = self.shared.franka_velocity.copy()
                pwm = self.shared.flowbot_pwm.copy()
                sm = self.shared.sm_raw.copy()

            self.writer.writerow([
                datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f"),
                mode,
                f"{pose[0]:.5f}", f"{pose[1]:.5f}", f"{pose[2]:.5f}",
                f"{vel[0]:.5f}", f"{vel[1]:.5f}", f"{vel[2]:.5f}", f"{vel[3]:.5f}",
                f"{pwm[0]:.2f}", f"{pwm[1]:.2f}", f"{pwm[2]:.2f}",
                f"{sm[0]:.4f}", f"{sm[1]:.4f}", f"{sm[2]:.4f}", f"{sm[3]:.4f}",
                f"{sm[4]:.0f}", f"{sm[5]:.0f}",
            ])

        # ---- 종료 시 레코딩 중이었으면 안전하게 닫기 ----
        with self.shared.lock:
            recording = self.shared.recording
        if recording:
            self._stop_episode()

        self.kp.stop()
