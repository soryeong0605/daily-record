from shared import SharedData

from tasks.franka_task import FrankaTask
from tasks.logger_task import LoggerTask
from tasks.keypress_task import KeypressTask
from tasks.plot_task import run_plot


# =========================
# ROBOT IP
# =========================

FRANKA_IP = "172.16.0.2"


# =========================
# MAIN
# =========================

def main():

    # =========================
    # SHARED
    # =========================

    shared = SharedData()

    # =========================
    # TASKS
    # =========================
    # SpaceMouse 읽기 + 로봇 명령이 franka_task.py 한 곳에서 같이 돎
    # (franky_teleop.py 원본 구조와 동일 -- 별도 스레드로 안 쪼갬)

    franka = FrankaTask(shared, ip=FRANKA_IP, mode="digital", dynamics_factor=0.05)
    logger = LoggerTask(shared)
    keypress = KeypressTask(shared)

    tasks = [
        franka,
        logger,
        keypress,
    ]

    # =========================
    # START
    # =========================

    for t in tasks:
        t.start()

    # =========================
    # 실시간 그래프 (메인 스레드에서 실행 -- matplotlib GUI 제약)
    # =========================
    # 창을 닫으면 run_plot 내부에서 shared.running=False로 바꿔줌.
    # Ctrl+C로 종료할 경우엔 여기서 바로 잡음.

    try:
        run_plot(shared)
    except KeyboardInterrupt:
        with shared.lock:
            shared.running = False

    # =========================
    # JOIN
    # =========================

    with shared.lock:
        shared.running = False

    for t in tasks:
        t.join()


if __name__ == "__main__":
    main()
