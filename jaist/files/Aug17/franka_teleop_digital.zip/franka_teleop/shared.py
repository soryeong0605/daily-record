import time
from collections import deque
from dataclasses import dataclass, field
from threading import Lock


HISTORY_LEN = 200   # 그래프에 보관할 샘플 개수 (PLOT_LOG_DT=0.05 기준 약 10초치)


@dataclass
class SharedData:

    # =========================
    # SPACEMOUSE COMMAND
    # =========================
    # deadband/속도 매핑까지 끝난 "목표 속도" (digital 모드, 고정 속력)
    # 실제 가속도 스무딩은 franka_task.py 쪽 HybridVelocitySmoother가 담당

    spacemouse = {
        "vx": 0.0,
        "vy": 0.0,
        "vz": 0.0,
        "wz": 0.0,
        "stamp": 0.0
    }

    # =========================
    # FRANKA ROBOT
    # =========================

    robot_pose = None                      # TCP xyz (np.ndarray, (3,))
    sent_velocity = [0.0, 0.0, 0.0, 0.0]    # 스무더 통과 후 실제로 로봇에 나간 [vx,vy,vz,wz]

    # =========================
    # RECORDING
    # =========================

    recording: bool = False
    recording_changed: bool = False

    # =========================
    # SLOW MODE
    # =========================
    # True면 franka_task가 MAX_LINEAR 대신 SLOW_LINEAR(0.01m/s)를 씀.
    # 's' 키로 토글 (keypress_task.py 참고)

    slow_mode: bool = False

    running: bool = True

    lock: Lock = field(default_factory=Lock)

    # =========================
    # PLOT (raw 입력 vs 커맨드 속도 실시간 그래프용 buffer)
    # =========================
    # franka_task.py가 PLOT_LOG_DT 주기로 여기에 append,
    # plot_task.py가 읽어서 그림.

    plot_start_time: float = field(default_factory=time.monotonic)

    plot_time: deque = field(default_factory=lambda: deque(maxlen=HISTORY_LEN))
    plot_raw_x: deque = field(default_factory=lambda: deque(maxlen=HISTORY_LEN))
    plot_raw_y: deque = field(default_factory=lambda: deque(maxlen=HISTORY_LEN))
    plot_raw_yaw: deque = field(default_factory=lambda: deque(maxlen=HISTORY_LEN))

    plot_vx: deque = field(default_factory=lambda: deque(maxlen=HISTORY_LEN))
    plot_vy: deque = field(default_factory=lambda: deque(maxlen=HISTORY_LEN))
    plot_vz: deque = field(default_factory=lambda: deque(maxlen=HISTORY_LEN))
    plot_wz: deque = field(default_factory=lambda: deque(maxlen=HISTORY_LEN))
