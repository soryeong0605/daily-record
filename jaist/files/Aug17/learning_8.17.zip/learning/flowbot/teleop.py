from __future__ import annotations

import time
import threading
import argparse

import numpy as np
import matplotlib.pyplot as plt
from scipy.spatial import ConvexHull

import serial
from kinematic_modeling import Flow_driven_bellow
from workspace import workspace_using_fwdmodel
from online_optitrack import MotiveNatNetReader
from position_pid import PositionPIDController
import os
import sys
FILE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(FILE_DIR)
GRANDPARENT_DIR = os.path.dirname(PARENT_DIR)
sys.path.insert(0, GRANDPARENT_DIR)
sys.path.insert(0, PARENT_DIR)
from learning.hardware.spacemouse import _build_spacemouse

# -------------------------
# Control settings
# -------------------------
PLOT_HZ = 25.0              # refresh plot at this rate
SEND_HZ = 30.0              # send PWM to Arduino at this rate

POS_GAIN = 1.0             # SpaceMouse -> task velocity gain (workspace units/s at full deflection)
DEADZONE = 0.1      # ignore tiny SpaceMouse noise
MAX_SPEED = 80.0            # clamp max task velocity magnitude (units/s)
MAX_STEP = 8.0              # clamp per-control-step displacement magnitude

OUTSIDE_POLICY = "backtrack"  # "hold" or "backtrack"

# Visual hull complexity (reduce triangles -> faster UI)
HULL_DOWNSAMPLE = 6

# PWM safety clamp
PWM_MIN = 0
PWM_MAX = 26

OPTITRACK_SCALE = 1000.0  # meters -> millimeters
OPTITRACK_ORIGIN_M = np.array([0.891567139, 0.335721802, -0.00522339], dtype=float)
OPTITRACK_TRAIL_LEN = 50    # keep last N optitrack points in trail


def main():
    from learning.hardware import flowbot
    import platform
    import select

    ap = argparse.ArgumentParser()
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--no-plot", action="store_true")
    ap.add_argument("--device-index", type=int, default=1, help="Index for the spacemouse")
    ap.add_argument("--pwm-min", "-mi", type=int, default=1)
    ap.add_argument("--pwm-max", "-ma", type=int, default=25)
    ap.add_argument("--send-hz", type=float, default=SEND_HZ)
    ap.add_argument("--plot-history", type=int, default=50)
    ap.add_argument("--optitrack", "-opt", action="store_true", default=False,
                     help="Enable OptiTrack NatNet streaming (Motive/NatNet).")
    ap.add_argument("--pressure-model", '-p', choices=["learned", "linear"], default="linear",
                     help="Pressure model: 'learned' (pkl models) or 'linear' (a*pwm+b).")
    # FIX: 오늘 pid_step_test.py로 튜닝한 PID를 실제 SpaceMouse 텔레옵에도
    # 붙일 수 있게 옵션 추가. --pid 안 켜면 예전 그대로 순수 feedforward
    # (fb.step) 경로로 동작 -- 기본 동작은 전혀 안 바뀜.
    ap.add_argument("--pid", action="store_true", default=False,
                     help="OptiTrack 피드백 기반 위치 PID 제어 사용 (기본은 순수 feedforward)")
    ap.add_argument("--kp", type=float, default=0.7)
    ap.add_argument("--ki", type=float, default=0.0)
    ap.add_argument("--kd", type=float, default=0.05)
    ap.add_argument("--integral-clamp", type=float, default=50.0)
    ap.add_argument("--output-clamp", type=float, default=15.0)
    args = ap.parse_args()

    if args.pid and not args.optitrack:
        print("[안내] --pid 사용하려면 실측 피드백(OptiTrack)이 반드시 필요해서 자동으로 --optitrack도 켰습니다.")
        args.optitrack = True

    os_name = platform.system().lower()
    if "linux" in os_name:
        serial_port = "/dev/ttyACM0"
    elif "windows" in os_name:
        serial_port = "COM9"
    CONTROL_HZ = 30.0          # integrate pc at this rate

    ### Flowbot
    fb = flowbot.flowbot(serial_port=serial_port,
                 pwm_min=0,
                 pwm_max=26,
                 enable_plot=True,
                frequency=CONTROL_HZ,
                max_pos_speed=50,
                pressure_model=args.pressure_model)

    # --- OptiTrack (optional) ---
    opti = None
    opti_origin_m = OPTITRACK_ORIGIN_M.copy()
    optitrack_init = True   # True until first valid reading sets the origin
    opti_trail_buf = []

    if args.optitrack:
        opti = MotiveNatNetReader(
            server_ip="127.0.0.1",
            local_ip="127.0.0.1",
            use_multicast=False,
            rigid_body_id=1,
        )
        opti.start()

    # =========================
    # PID 모드 준비 (--pid 켰을 때만)
    # =========================
    pid = None
    ws = None
    ws_tri = None
    ws_center = None
    target_pc = None

    if args.pid:
        pid = PositionPIDController(
            kp=args.kp, ki=args.ki, kd=args.kd,
            integral_clamp=args.integral_clamp, output_clamp=args.output_clamp,
        )
        # FIX: fb.apply_workspace_constraint()는 "현재 pc"에서 탐색을 시작해서,
        # pc가 이미 경계에 붙어있으면 더 못 나가는 버그가 있었음(오늘
        # pid_step_test.py에서 확인/수정함). 여기서도 같은 방식으로,
        # "워크스페이스 중심"에서 매번 새로 탐색하는 버전을 사용.
        ws = workspace_using_fwdmodel(robot=fb.flowbot, pwm_min=fb.pwm_min, pwm_max=fb.pwm_max)
        hull = ws.build_workspace_hull_checker(ws.P)
        ws_tri = hull["tri"]
        ws_center = 0.5 * (hull["bbox"][0] + hull["bbox"][1])
        target_pc = fb.pc.copy()
        print(f"[PID 모드 켜짐] kp={args.kp} ki={args.ki} kd={args.kd} "
              f"integral_clamp={args.integral_clamp} output_clamp={args.output_clamp}")

    def constrain_to_workspace(pc_proposed: np.ndarray) -> np.ndarray:
        d = pc_proposed - ws_center
        norm = float(np.linalg.norm(d))
        if norm < 1e-9:
            return ws_center.copy()
        for a in np.linspace(1.0, 0.0, 60):
            cand = ws_center + a * d
            if ws.is_inside_workspace(cand, ws_tri):
                return cand
        return ws_center.copy()

    PLOT_HZ_LOCAL = 30.0
    plot_dt = 1.0 / PLOT_HZ_LOCAL
    t_next_plot = time.perf_counter()
    t_prev_loop = time.perf_counter()   # PID용 실측 dt 계산에 쓸 이전 루프 시각
    ## --- SpaceMouse flowbot thread ---
    sm_fb = _build_spacemouse(os_name=os_name)
    sm_fb.start()

    fb.start()
    fb.pl.highlight_pwm_corners(fb.axes, fb.flowbot, pwm_max=26)

    # --- keyboard: 'r' resets pc to init and sends [0,0,0] ---
    def _on_key(event):
        nonlocal target_pc
        if event.key == 'r':
            fb.reset()
            if pid is not None:
                pid.reset()
                target_pc = fb.pc.copy()
            print("Reset: pc ->", fb.pc, "  pwm -> [0,0,0]")

    if fb.fig is not None:
        fb.fig.canvas.mpl_connect('key_press_event', _on_key)

    mode_str = "PID (feedback)" if args.pid else "feedforward (original)"
    print(f"Teleop running in {mode_str} mode. Press 'r' to reset. Close plot window or Ctrl+C to stop.")
    try:
        while (fb.fig is None) or plt.fignum_exists(fb.fig.number):
            t_now = time.perf_counter()
            loop_dt = min(t_now - t_prev_loop, 0.05)  # 0.05s 상한: 멈췄다 깨어나도 폭주 방지
            t_prev_loop = t_now

            xyz = sm_fb.get_latest_xyz()
            button_status = sm_fb.get_button_status()
            xyz[2] = -xyz[2]
            xyz = np.where(np.abs(xyz) < DEADZONE, 0.0, xyz)

            # =========================
            # OptiTrack 원점 캘리브레이션 (PID 모드든 아니든, 켜져있으면 한 번만)
            # =========================
            s = opti.get_latest() if opti is not None else None
            if s is not None and optitrack_init:
                opti_origin_m = np.array(s.pos_xyz, dtype=float)
                opti_origin_m[1] += (fb.flowbot.l0 + fb.flowbot.lu) / 1000.0
                optitrack_init = False
                if args.pid:
                    target_pc = fb.pc.copy()

            # =========================
            # 실제 제어: PID 모드 vs 기존 feedforward
            # =========================
            if args.pid:
                dpc = xyz[:3] * fb.max_pos_speed * loop_dt
                target_pc = target_pc + dpc

                if s is not None and not optitrack_init:
                    measured = opti.opti_to_manip(np.array(s.pos_xyz, dtype=float), opti_origin_m)
                    commanded = pid.update(target_pc, measured)
                    fb.pc = constrain_to_workspace(commanded)
                    ik = fb.flowbot.inverse_pressures_from_position(fb.pc, pwm_max=fb.pwm_max)
                    pwm = np.asarray(ik["pwm"], dtype=int).reshape(3,)
                    fb.serial_sending(pwm)
                    fb.last_pwm = pwm
                # s가 None이면(트래킹 순간적으로 끊김) 이번 틱은 안전하게 스킵
                # -- 마지막으로 보냈던 PWM이 그대로 유지됨.
            else:
                fb.step(xyz)   # 기존 순수 feedforward 경로, 완전히 그대로 유지

            if fb.pl is not None and t_now >= t_next_plot:
                if opti is not None and s is not None and not optitrack_init:
                    transformed = opti.opti_to_manip(np.array(s.pos_xyz, dtype=float), opti_origin_m)
                    fb.pl.update_opti_handle(fb.opti_handles, transformed)

                    opti_trail_buf.append(transformed)
                    if len(opti_trail_buf) > OPTITRACK_TRAIL_LEN:
                        opti_trail_buf = opti_trail_buf[-OPTITRACK_TRAIL_LEN:]
                    fb.pl.update_trail_handle(fb.trail_handles, np.vstack(opti_trail_buf))

                fb.update_plot()
                t_next_plot += plot_dt
    except KeyboardInterrupt:
        pass
    finally:
        sm_fb.stop()
        fb.stop()
        time.sleep(0.5)  # give threads a moment to exit
        if opti is not None:
            opti.stop()


if __name__ == "__main__":
    main()
