"""
circle_tracking_test.py

원 궤적을 순수 feedforward로 따라가는 것과, PID 피드백으로 따라가는 것을
비교하기 위한 테스트. 같은 원을 두 모드로 각각 돌려서 결과를 비교하면 됨.

목표 궤적 (X-Y 평면 위의 원, Z는 고정):
    target(t) = [radius*cos(2*pi*t/period), radius*sin(2*pi*t/period), z_center]

사용법
------
# feedforward만 (보정 없음)
python circle_tracking_test.py --port COM9 --mode feedforward --radius 15 --z-center 100

# PID 피드백
python circle_tracking_test.py --port COM9 --mode pid --kp 0.7 --ki 0.0 --kd 0.05 --radius 15 --z-center 100

둘을 같은 radius/z-center/period로 돌려서 CSV/그래프를 나란히 비교하면
feedforward vs PID 성능 차이를 볼 수 있음.
"""

from __future__ import annotations

import argparse
import csv
import os
import sys
import time
from datetime import datetime

import numpy as np
import matplotlib.pyplot as plt

FILE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(FILE_DIR)
GRANDPARENT_DIR = os.path.dirname(PARENT_DIR)
sys.path.insert(0, GRANDPARENT_DIR)
sys.path.insert(0, PARENT_DIR)

from learning.hardware import flowbot as flowbot_pkg
flowbot_module = flowbot_pkg.flowbot
from online_optitrack import MotiveNatNetReader
from position_pid import PositionPIDController
from workspace import workspace_using_fwdmodel

L0_PLUS_LU_M = 0.0955   # l0(82mm) + lu(13.5mm), 원점 오프셋용 (m 단위)
PLOT_HZ = 15.0


def target_on_circle(t: float, radius: float, z_center: float, period: float,
                      cx: float = 0.0, cy: float = 0.0) -> np.ndarray:
    phi = 2.0 * np.pi * t / period
    return np.array([cx + radius * np.cos(phi), cy + radius * np.sin(phi), z_center])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", default="COM9")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--mode", choices=["feedforward", "pid"], default="feedforward",
                     help="feedforward: 보정 없이 목표를 그대로 전송 / pid: OptiTrack 피드백으로 보정")
    ap.add_argument("--radius", type=float, default=15.0, help="원 반지름 (mm)")
    ap.add_argument("--z-center", type=float, default=100.0, help="원이 위치할 Z 높이 (mm)")
    ap.add_argument("--cx", type=float, default=0.0, help="원 중심 X (mm)")
    ap.add_argument("--cy", type=float, default=0.0, help="원 중심 Y (mm)")
    ap.add_argument("--period", type=float, default=8.0, help="한 바퀴 도는 데 걸리는 시간(초)")
    ap.add_argument("--laps", type=float, default=2.0, help="몇 바퀴 돌지")
    ap.add_argument("--settle-s", type=float, default=10.0,
                     help="원 궤적 시작 전, 원의 시작점에서 가만히 대기하며 도달/정착할 시간(초)")
    ap.add_argument("--kp", type=float, default=0.7)
    ap.add_argument("--ki", type=float, default=0.0)
    ap.add_argument("--kd", type=float, default=0.05)
    ap.add_argument("--integral-clamp", type=float, default=50.0)
    ap.add_argument("--output-clamp", type=float, default=15.0)
    ap.add_argument("--hz", type=float, default=30.0, help="제어 주파수")
    ap.add_argument("--pwm-min", type=int, default=0)
    ap.add_argument("--pwm-max", type=int, default=26)
    args = ap.parse_args()

    CONTROL_HZ = args.hz
    control_dt = 1.0 / CONTROL_HZ
    plot_dt = 1.0 / PLOT_HZ
    total_duration = args.settle_s + args.period * args.laps

    # =========================
    # 로봇 + OptiTrack 연결
    # =========================
    fb = flowbot_module(
        serial_port=args.port,
        baud=args.baud,
        pwm_min=args.pwm_min,
        pwm_max=args.pwm_max,
        enable_plot=False,
        frequency=CONTROL_HZ,
        max_pos_speed=50,
        pressure_model="linear",
    )

    motive = MotiveNatNetReader(
        server_ip="127.0.0.1",
        local_ip="127.0.0.1",
        use_multicast=False,
        rigid_body_id=1,
    )
    motive.start()
    time.sleep(2.0)

    print("OptiTrack 데이터 스트림 안정화 대기 중...")
    stable_count = 0
    while stable_count < 10:
        if motive.get_latest() is not None:
            stable_count += 1
        else:
            stable_count = 0
        time.sleep(0.02)
    print("OptiTrack 데이터 스트림 안정적으로 확인됨.")

    print("원점 캘리브레이션 중... 로봇이 초기 자세(pwm_min,pwm_min,pwm_min)인지 확인하세요.")
    sample = motive.get_latest()
    if sample is None:
        raise RuntimeError("OptiTrack 샘플을 못 받음 -- 그리퍼가 시야에 있는지 확인.")
    origin_m = np.array(sample.pos_xyz, dtype=float)
    origin_m[1] += L0_PLUS_LU_M
    print(f"원점(world, m): {np.round(origin_m, 5)}")

    # =========================
    # 워크스페이스 안전망 (오늘 고친 '중심에서 탐색' 버전)
    # =========================
    ws = workspace_using_fwdmodel(robot=fb.flowbot, pwm_min=args.pwm_min, pwm_max=args.pwm_max)
    hull = ws.build_workspace_hull_checker(ws.P)
    ws_tri = hull["tri"]
    ws_center = 0.5 * (hull["bbox"][0] + hull["bbox"][1])

    # FIX: 로봇 움직이기 전에, 원 궤적 전체가 실제로 워크스페이스 안에
    # 있는지 미리 검사. 밖에 있는 구간이 있으면 그 구간은 실제로는 그
    # 자리까지 못 가고 경계에서 멈추게 됨(constrain_to_workspace가 강제로
    # 안쪽으로 당김) -- 원의 일부가 찌그러져 보이는 원인이 될 수 있음.
    n_check = 72
    outside_count = 0
    for i in range(n_check):
        phi_check = 2 * np.pi * i / n_check
        pt = np.array([args.cx + args.radius * np.cos(phi_check),
                        args.cy + args.radius * np.sin(phi_check),
                        args.z_center])
        if not ws.is_inside_workspace(pt, ws_tri):
            outside_count += 1

    if outside_count > 0:
        pct = 100.0 * outside_count / n_check
        print(f"\n[경고] 지정한 원(radius={args.radius}mm, z_center={args.z_center}mm)의 "
              f"약 {pct:.0f}%({outside_count}/{n_check}개 샘플점)가 워크스페이스 밖입니다.")
        print("       그 구간은 실제로 원을 못 그리고 경계에서 눌린 모양으로 나올 수 있어요.")
        print("       radius를 줄이거나 z_center를 조정해보세요 "
              f"(워크스페이스 중심 참고: {np.round(ws_center, 1)}).")
        resp = input("       그래도 계속 진행할까요? (y/N): ").strip().lower()
        if resp != "y":
            print("중단합니다.")
            fb.stop()
            motive.stop()
            return
    else:
        print(f"\n[확인] 원 전체({n_check}개 샘플점)가 워크스페이스 안에 있습니다. 진행합니다.")

    def constrain_to_workspace(pc_proposed: np.ndarray) -> np.ndarray:
        d = pc_proposed - ws_center
        norm = float(np.linalg.norm(d))
        if norm < 1e-9:
            return ws_center.copy()
        for a in np.linspace(1.0, 0.0, 60):
            cand = ws_center + a * d
            if ws.is_inside_workspace(cand, ws_tri):
                return cand
        return ws_center.copy()

    # =========================
    # PID (mode=pid일 때만 사용)
    # =========================
    pid = None
    if args.mode == "pid":
        pid = PositionPIDController(
            kp=args.kp, ki=args.ki, kd=args.kd,
            integral_clamp=args.integral_clamp, output_clamp=args.output_clamp,
        )
        print(f"[PID 모드] kp={args.kp} ki={args.ki} kd={args.kd}")
    else:
        print("[Feedforward 모드] 보정 없이 목표를 그대로 전송합니다.")

    # =========================
    # 로그 준비
    # =========================
    os.makedirs("logs", exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = os.path.join("logs", f"circle_{args.mode}_{ts}.csv")
    f = open(csv_path, "w", newline="")
    writer = csv.writer(f)
    writer.writerow(["t", "target_x", "target_y", "target_z",
                      "meas_x", "meas_y", "meas_z", "pwm1", "pwm2", "pwm3", "err_mm"])

    # =========================
    # 실시간 그래프 준비 (XY 평면, 원 vs 실제 궤적)
    # =========================
    plt.ion()
    fig, (ax_circle, ax_err) = plt.subplots(1, 2, figsize=(13, 6))

    # 목표 원 전체를 미리 옅게 그려둠 (참고용 배경)
    phi_full = np.linspace(0, 2 * np.pi, 200)
    ax_circle.plot(args.cx + args.radius * np.cos(phi_full),
                   args.cy + args.radius * np.sin(phi_full),
                   "k--", alpha=0.4, linewidth=1.0, label="ideal circle")
    (target_marker,) = ax_circle.plot([], [], "ro", markersize=8, label="target (moving)")
    (meas_line,) = ax_circle.plot([], [], "b-", linewidth=1.2, label="measured trace")
    ax_circle.set_xlabel("X (mm)")
    ax_circle.set_ylabel("Y (mm)")
    ax_circle.set_title(f"Circle tracking -- mode={args.mode}, r={args.radius}mm, "
                         f"z={args.z_center}mm, period={args.period}s")
    ax_circle.set_aspect("equal", adjustable="box")
    margin = args.radius * 0.5 + 5
    ax_circle.set_xlim(args.cx - args.radius - margin, args.cx + args.radius + margin)
    ax_circle.set_ylim(args.cy - args.radius - margin, args.cy + args.radius + margin)
    ax_circle.grid(True, alpha=0.3)
    ax_circle.legend(loc="upper right", fontsize=8)

    (err_line,) = ax_err.plot([], [], "g-", linewidth=1.0)
    ax_err.axvline(args.settle_s, color="gray", linestyle=":", alpha=0.6, label="circle start")
    ax_err.set_xlabel("time (s)")
    ax_err.set_ylabel("tracking error |target-measured| (mm)")
    ax_err.set_title("XY plane tracking error over time")
    ax_err.grid(True, alpha=0.3)
    ax_err.legend(loc="best", fontsize=8)

    fig.tight_layout()
    fig.show()
    plt.pause(0.001)

    log_t, log_target, log_meas, log_err, log_is_circle = [], [], [], [], []

    def refresh_plot():
        if len(log_meas) == 0:
            return
        meas_arr = np.array(log_meas)
        meas_line.set_data(meas_arr[:, 0], meas_arr[:, 1])
        target_marker.set_data([log_target[-1][0]], [log_target[-1][1]])
        err_line.set_data(log_t, log_err)
        ax_err.relim()
        ax_err.autoscale_view()
        fig.canvas.draw_idle()
        fig.canvas.flush_events()

    # =========================
    # 메인 루프
    # =========================
    t_start = time.perf_counter()
    t_next_plot = t_start

    print(f"\n{args.settle_s}초 동안 원 시작점에서 대기(정착) 후, "
          f"{args.laps}바퀴 반지름 {args.radius}mm, 주기 {args.period}s로 원을 그립니다 "
          f"(총 {total_duration:.1f}초). 그래프 창을 닫거나 Ctrl+C로 언제든 중단 가능\n")

    circle_started = False

    try:
        while plt.fignum_exists(fig.number):
            t_now = time.perf_counter() - t_start
            if t_now > total_duration:
                break

            if t_now < args.settle_s:
                # FIX: 로봇이 쉬는 자세에서 원 시작점까지 이동/정착할 시간을
                # 먼저 줌. 이 구간에는 목표를 원의 시작 각도(t_circle=0)에
                # 고정해둠 -- t=0부터 바로 원을 따라 돌면, 로봇이 아직
                # 시작점에도 못 간 상태에서 목표가 계속 앞서나가버림.
                target_pc = target_on_circle(0.0, args.radius, args.z_center, args.period,
                                              cx=args.cx, cy=args.cy)
            else:
                if not circle_started:
                    print(f"[t={t_now:.2f}s] 정착 완료, 원 궤적 추종 시작")
                    circle_started = True
                t_circle = t_now - args.settle_s
                target_pc = target_on_circle(t_circle, args.radius, args.z_center, args.period,
                                              cx=args.cx, cy=args.cy)

            sample = motive.get_latest()
            if sample is not None:
                measured = motive.opti_to_manip(np.array(sample.pos_xyz), origin_m)

                if args.mode == "pid":
                    commanded = pid.update(target_pc, measured)
                else:
                    commanded = target_pc   # feedforward: 보정 없이 목표 그대로

                fb.pc = constrain_to_workspace(commanded)
                ik = fb.flowbot.inverse_pressures_from_position(fb.pc, pwm_max=fb.pwm_max)
                pwm = np.asarray(ik["pwm"], dtype=int).reshape(3,)
                fb.serial_sending(pwm)
                fb.last_pwm = pwm

                err_xy = float(np.linalg.norm(target_pc[:2] - measured[:2]))

                log_t.append(t_now)
                log_target.append(target_pc.copy())
                log_meas.append(measured.copy())
                log_err.append(err_xy)
                log_is_circle.append(circle_started)

                writer.writerow([
                    f"{t_now:.4f}",
                    *[f"{v:.3f}" for v in target_pc],
                    *[f"{v:.3f}" for v in measured],
                    *[int(v) for v in fb.last_pwm],
                    f"{err_xy:.3f}",
                ])

            if t_now >= (t_next_plot - t_start):
                refresh_plot()
                t_next_plot += plot_dt

            time.sleep(control_dt)

    except KeyboardInterrupt:
        print("\n중단됨.")
    finally:
        f.close()
        print(f"\nCSV 저장: {csv_path}")
        print("안전을 위해 초기 자세로 복귀 중...")
        try:
            fb.reset()
        except Exception:
            pass
        time.sleep(1.0)
        fb.stop()
        motive.stop()

    # =========================
    # 최종 통계 + 그래프 저장
    # =========================
    if len(log_err) > 0:
        # FIX: 정착(settle) 구간은 "원 추종"이 아니라 "시작점 도달 과정"이라
        # 통계에서 제외 -- 안 그러면 feedforward/PID 비교가 불공정해짐.
        circle_mask = np.array(log_is_circle, dtype=bool)
        if circle_mask.any():
            err_arr = np.array(log_err)[circle_mask]
        else:
            print("경고: 원 추종 구간 데이터가 없음 (settle-s가 너무 길었을 수 있음) -- 전체 구간으로 계산.")
            err_arr = np.array(log_err)

        rms = float(np.sqrt(np.mean(err_arr ** 2)))
        mean_err = float(np.mean(err_arr))
        max_err = float(np.max(err_arr))
        print(f"\n[{args.mode}] XY 평면 추종 오차 (정착 구간 제외, 원 추종 구간만) -- "
              f"평균: {mean_err:.2f}mm, RMS: {rms:.2f}mm, 최대: {max_err:.2f}mm")

        ax_circle.set_title(ax_circle.get_title() +
                             f"\nmean={mean_err:.2f}mm RMS={rms:.2f}mm max={max_err:.2f}mm")
        refresh_plot()
        out_png = csv_path.replace(".csv", "_circle.png")
        plt.savefig(out_png, dpi=150)
        print(f"그래프 저장: {out_png}")

    print("종료하려면 그래프 창을 닫으세요.")
    plt.ioff()
    plt.show()


if __name__ == "__main__":
    main()
