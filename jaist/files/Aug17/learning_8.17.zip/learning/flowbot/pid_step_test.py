"""
pid_step_test.py

PID 게인 튜닝용 스텝 응답(step response) 테스트 -- 실시간 그래프 버전.

절차
----
1) 로봇을 PWM=(pwm_min,pwm_min,pwm_min) 근처(초기 자세)에서 시작
2) 잠깐(PRE_STEP_S) 그 자리에서 대기 -> 기준선(baseline) 확보
3) t=PRE_STEP_S 시점에 목표를 X축으로만 STEP_SIZE_MM(기본 30mm) 만큼 계단
   형태로 바꿈 (Y, Z는 그대로 유지)
4) PID가 그 새 목표를 따라가는 동안, 시간 vs (목표, 실측) 위치를
   실시간으로 그래프에 그려나감 (테스트 끝날 때까지 기다릴 필요 없음)
5) 끝나면 CSV로 저장 + 마지막 그래프를 PNG로도 저장

사용법
------
python pid_step_test.py --port COM9 --kp 0.6 --ki 0.0 --kd 0.05 --step 30
"""

from __future__ import annotations

import argparse
import csv
import os
import sys
import time
from datetime import datetime

import numpy as np
import matplotlib.pyplot as plt

FILE_DIR = os.path.dirname(os.path.abspath(__file__))
PARENT_DIR = os.path.dirname(FILE_DIR)
GRANDPARENT_DIR = os.path.dirname(PARENT_DIR)
sys.path.insert(0, GRANDPARENT_DIR)
sys.path.insert(0, PARENT_DIR)

from learning.hardware import flowbot as flowbot_pkg
flowbot_module = flowbot_pkg.flowbot
from online_optitrack import MotiveNatNetReader
from position_pid import PositionPIDController
from workspace import workspace_using_fwdmodel

L0_PLUS_LU_M = 0.0955  # l0(82mm) + lu(13.5mm), 원점 오프셋용 (m 단위)
PLOT_HZ = 15.0          # 그래프 갱신 주파수 (제어 주파수보다 낮게 -- 너무 자주 그리면 느려짐)


def compute_settling_time(t_arr, resp_arr, step_time, final_value, tol_frac=0.02, step_size=1.0):
    """
    스텝 인가 시점(step_time) 이후 구간에서, 최종값(final_value) 기준
    ±tol_frac*step_size 오차범위 안에 들어간 뒤로 다시 안 벗어나는
    최초 시각(정상상태시간)을 계산. 못 찾으면 None 반환.
    """
    post_mask = t_arr >= step_time
    t_post = t_arr[post_mask]
    resp_post = resp_arr[post_mask]
    if len(t_post) == 0:
        return None, None

    band = abs(tol_frac * step_size)
    within = np.abs(resp_post - final_value) <= band

    for i in range(len(within)):
        if np.all(within[i:]):
            return t_post[i], band
    return None, band


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--port", default="COM9")
    ap.add_argument("--baud", type=int, default=115200)
    ap.add_argument("--kp", type=float, default=0.6)
    ap.add_argument("--ki", type=float, default=0.0)
    ap.add_argument("--kd", type=float, default=0.05)
    ap.add_argument("--integral-clamp", type=float, default=50.0, help="적분항 최대 누적치 (mm)")
    ap.add_argument("--output-clamp", type=float, default=15.0, help="한 스텝 최대 보정량 (mm)")
    ap.add_argument("--step", type=float, default=30.0, help="스텝 크기 (mm)")
    ap.add_argument("--axis", choices=["x", "y", "z"], default="x", help="스텝을 줄 축")
    ap.add_argument("--single-axis-only", action="store_true",
                     help="다른 두 축을 baseline에 억지로 고정하지 않고, 자연스러운 "
                          "커플링대로 흘러가게 둠 (스텝 축만 실제로 PID 제어됨)")
    ap.add_argument("--pre-step-s", type=float, default=1.0, help="스텝 넣기 전 기준선 확보 시간(s)")
    ap.add_argument("--duration-s", type=float, default=8.0, help="스텝 이후 총 관찰 시간(s)")
    ap.add_argument("--hz", type=float, default=30.0, help="제어 주파수")
    ap.add_argument("--pwm-min", type=int, default=0)
    ap.add_argument("--pwm-max", type=int, default=26)
    args = ap.parse_args()

    axis_idx = {"x": 0, "y": 1, "z": 2}[args.axis]
    axis_name = args.axis.upper()

    CONTROL_HZ = args.hz
    control_dt = 1.0 / CONTROL_HZ
    plot_dt = 1.0 / PLOT_HZ

    # =========================
    # 로봇 + OptiTrack 연결
    # =========================
    fb = flowbot_module(
        serial_port=args.port,
        baud=args.baud,
        pwm_min=args.pwm_min,
        pwm_max=args.pwm_max,
        enable_plot=False,     # flowbot 자체의 3D뷰는 끄고, 이 스크립트의 실시간 그래프만 씀
        frequency=CONTROL_HZ,
        max_pos_speed=50,
        pressure_model="linear",
    )

    motive = MotiveNatNetReader(
        server_ip="127.0.0.1",
        local_ip="127.0.0.1",
        use_multicast=False,
        rigid_body_id=1,
    )
    motive.start()
    time.sleep(2.0)

    # FIX: 연결 직후 바로 루프를 시작하면, OptiTrack 스트림이 아직
    # 안정화되기 전이라 몇 초간 get_latest()가 None을 반환하는 구간이
    # 생길 수 있음 (기준선 확보 시간을 조용히 잡아먹어버림). 실제로
    # 연속으로 유효한 샘플이 들어오는지 확인하고 나서 테스트 타이머를
    # 시작하도록 함.
    print("OptiTrack 데이터 스트림 안정화 대기 중...")
    stable_count = 0
    while stable_count < 10:
        if motive.get_latest() is not None:
            stable_count += 1
        else:
            stable_count = 0
        time.sleep(0.02)
    print("OptiTrack 데이터 스트림 안정적으로 확인됨.")

    # =========================
    # 원점 잡기
    # =========================
    print("원점 캘리브레이션 중... 로봇이 초기 자세(pwm_min,pwm_min,pwm_min)인지 확인하세요.")
    sample = motive.get_latest()
    if sample is None:
        raise RuntimeError("OptiTrack 샘플을 못 받음 -- 그리퍼가 시야에 있는지 확인.")
    origin_m = np.array(sample.pos_xyz, dtype=float)
    origin_m[1] += L0_PLUS_LU_M
    print(f"원점(world, m): {np.round(origin_m, 5)}")

    # =========================
    # 워크스페이스/경계 체크용 별도 hull 구성
    # =========================
    # FIX: fb.apply_workspace_constraint()는 "현재 pc"에서 "제안된 목표"까지
    # 직선을 그어 그 위에서 경계 안쪽 점을 찾는 방식(backtrack). 근데 pc가
    # 이미 경계에 딱 붙어있으면, 그 직선의 시작점(pc 자신) 말고는 거의 다
    # 워크스페이스 바깥이라 매번 "못 찾음 -> 원래 자리 그대로"만 반복돼서
    # pc가 그 자리에 완전히 고정돼버림 (경계를 따라 옆으로 더 갈 수 있는
    # 공간이 남아있어도 전혀 활용 못 함). 그래서 "현재 pc"가 아니라
    # "워크스페이스 중심"에서 매번 새로 목표 방향으로 탐색하도록 대체.
    ws = workspace_using_fwdmodel(robot=fb.flowbot, pwm_min=args.pwm_min, pwm_max=args.pwm_max)
    hull = ws.build_workspace_hull_checker(ws.P)
    ws_tri = hull["tri"]
    ws_center = 0.5 * (hull["bbox"][0] + hull["bbox"][1])

    def constrain_to_workspace(pc_proposed: np.ndarray) -> np.ndarray:
        d = pc_proposed - ws_center
        norm = float(np.linalg.norm(d))
        if norm < 1e-9:
            return ws_center.copy()
        for a in np.linspace(1.0, 0.0, 60):
            cand = ws_center + a * d
            if ws.is_inside_workspace(cand, ws_tri):
                return cand
        return ws_center.copy()

    print(f"워크스페이스 중심(디버깅용): {np.round(ws_center, 2)}")

    # =========================
    # PID 세팅
    # =========================
    pid = PositionPIDController(
        kp=args.kp, ki=args.ki, kd=args.kd,
        integral_clamp=args.integral_clamp, output_clamp=args.output_clamp,
    )
    print(f"PID 게인: kp={args.kp}, ki={args.ki}, kd={args.kd}, "
          f"integral_clamp={args.integral_clamp}, output_clamp={args.output_clamp}")

    # =========================
    # 로그 준비
    # =========================
    os.makedirs("logs", exist_ok=True)
    ts = datetime.now().strftime("%Y%m%d_%H%M%S")
    csv_path = os.path.join("logs", f"step_test_{ts}.csv")
    f = open(csv_path, "w", newline="")
    writer = csv.writer(f)
    writer.writerow(["t", "target_x", "target_y", "target_z",
                      "meas_x", "meas_y", "meas_z", "pwm1", "pwm2", "pwm3"])

    # =========================
    # 실시간 그래프 준비
    # =========================
    plt.ion()
    axis_labels = ["X", "Y", "Z"]
    fig, axes = plt.subplots(3, 1, figsize=(10, 9), sharex=True)

    target_lines, meas_lines = [], []
    for i in range(3):
        ax = axes[i]
        (tl,) = ax.plot([], [], "k--", label="target", linewidth=1.5)
        (ml,) = ax.plot([], [], "b-", label="measured", linewidth=1.2)
        ax.axvline(args.pre_step_s, color="gray", linestyle=":", alpha=0.6, label="step applied")
        ax.set_ylabel(f"{axis_labels[i]} (mm)")
        ax.grid(True, alpha=0.3)
        ax.legend(loc="best", fontsize=8)
        target_lines.append(tl)
        meas_lines.append(ml)

    axes[0].set_title(f"Step Response (live) -- kp={args.kp}, ki={args.ki}, kd={args.kd}, step={args.step}mm ({axis_name} axis)")
    axes[-1].set_xlabel("time (s)")
    plt.tight_layout()
    fig.show()
    plt.pause(0.001)

    def refresh_plot(t_arr, target_arr, meas_arr):
        for i in range(3):
            target_lines[i].set_data(t_arr, target_arr[:, i])
            meas_lines[i].set_data(t_arr, meas_arr[:, i])
            axes[i].relim()
            axes[i].autoscale_view()
        fig.canvas.draw_idle()
        fig.canvas.flush_events()

    # =========================
    # 스텝 테스트 시작
    # =========================
    baseline_pc = fb.pc.copy()          # 시작 목표 (Y,Z는 끝까지 이 값 유지)
    target_pc = baseline_pc.copy()

    log_t, log_target, log_meas = [], [], []

    t_start = time.perf_counter()
    t_next_plot = t_start
    stepped = False
    total_duration = args.pre_step_s + args.duration_s

    print(f"\n시작: {args.pre_step_s}초 대기 후 {axis_name}축으로 {args.step}mm 스텝, "
          f"이후 {args.duration_s}초 관찰 (총 {total_duration:.1f}초)")
    print("그래프 창을 닫거나 Ctrl+C로 언제든 중단 가능\n")

    try:
        while plt.fignum_exists(fig.number):
            t_now = time.perf_counter() - t_start
            if t_now > total_duration:
                break

            if (not stepped) and (t_now >= args.pre_step_s):
                target_pc = baseline_pc.copy()
                target_pc[axis_idx] += args.step
                stepped = True
                print(f"[t={t_now:.2f}s] 스텝 인가: 목표 {axis_name} = {target_pc[axis_idx]:.2f}mm")

            sample = motive.get_latest()
            if sample is not None:
                measured = motive.opti_to_manip(np.array(sample.pos_xyz), origin_m)

                # FIX: --single-axis-only 켜져있으면, 스텝을 안 준 축들은
                # 매 순간 target을 "지금 측정값"으로 갱신해서 오차를 항상
                # 0으로 만듦 -> PID가 그 축들을 baseline으로 억지로 되돌리려는
                # 힘이 사라지고, 소프트로봇의 자연스러운 커플링(예: Y로 많이
                # 밀면 X,Z도 같이 움직이는 것)을 그대로 허용하게 됨.
                if args.single_axis_only and stepped:
                    for other_idx in range(3):
                        if other_idx != axis_idx:
                            target_pc[other_idx] = measured[other_idx]

                commanded = pid.update(target_pc, measured)

                # NOTE: fb.set_position()은 self.pc만 갱신하고 실제로
                # PWM을 보내지 않음 (serial_sending 호출이 없음). fb.step()은
                # 절대위치가 아니라 조이스틱류 정규화 입력(-1~1)을 받는
                # 구조라 여기 목적에 안 맞음. 그래서 step()의 핵심 로직만
                # 직접 재현: 워크스페이스 클램프(수정판, 중심에서 탐색)
                # -> IK(pwm_max 명시) -> 전송.
                pc_before_constraint = fb.pc.copy()
                fb.pc = constrain_to_workspace(commanded)
                ik = fb.flowbot.inverse_pressures_from_position(fb.pc, pwm_max=fb.pwm_max)
                pwm = np.asarray(ik["pwm"], dtype=int).reshape(3,)
                fb.serial_sending(pwm)
                fb.last_pwm = pwm

                # FIX: 어느 단계(PID 출력 자체 vs 워크스페이스 제한)에서
                # 값이 고정되는지 1초 간격으로 눈으로 확인할 수 있게 출력.
                # output_clamp를 40까지 열어도 결과가 안 바뀌는 원인을
                # 찾기 위한 임시 진단 코드.
                if int(t_now * 2) != int((t_now - control_dt) * 2):
                    print(f"\n  [진단] commanded(PID원출력)={np.round(commanded,2)}  "
                          f"fb.pc(제한통과후)={np.round(fb.pc,2)}  pwm={pwm}")

                log_t.append(t_now)
                log_target.append(target_pc.copy())
                log_meas.append(measured.copy())

                writer.writerow([
                    f"{t_now:.4f}",
                    *[f"{v:.3f}" for v in target_pc],
                    *[f"{v:.3f}" for v in measured],
                    *[int(v) for v in fb.last_pwm],
                ])
            else:
                # FIX: 샘플이 None인 구간을 눈에 보이게 경고 -- 예전엔 조용히
                # 건너뛰기만 해서, OptiTrack 데이터가 1초 넘게 끊겨도 콘솔에
                # 아무 표시가 없었음. 그래프에서 "target이 램프처럼 보이는"
                # 현상의 실제 원인이 바로 이 구간이었음 (로그 공백을 matplotlib이
                # 직선으로 이어그려서 램프처럼 보인 것뿐, 실제 target은 계단임).
                print(f"\r[t={t_now:.2f}s] 경고: OptiTrack 샘플 없음 (None) -- "
                      f"이 프레임은 로그/제어에서 건너뜀", end="", flush=True)

            # 그래프는 PLOT_HZ 속도로만 갱신 (매 제어스텝마다 그리면 느려짐)
            if t_now >= (t_next_plot - t_start):
                if len(log_t) >= 2:
                    refresh_plot(np.array(log_t), np.array(log_target), np.array(log_meas))
                t_next_plot += plot_dt

            time.sleep(control_dt)

    except KeyboardInterrupt:
        print("\n중단됨.")
    finally:
        f.close()
        print(f"\nCSV 저장: {csv_path}")
        print("안전을 위해 초기 자세로 복귀 중...")
        try:
            fb.reset()
        except Exception:
            pass
        time.sleep(1.0)
        fb.stop()
        motive.stop()

    # =========================
    # 마지막으로 한 번 더 갱신 + 정상상태시간 계산/표시 + PNG 저장
    # =========================
    if len(log_t) >= 2:
        t_arr = np.array(log_t)
        target_arr = np.array(log_target)
        meas_arr = np.array(log_meas)
        refresh_plot(t_arr, target_arr, meas_arr)

        # 스텝을 준 축(axis_idx)에 대해 정상상태시간 계산
        final_value = target_arr[-1, axis_idx]
        settling_t, band = compute_settling_time(
            t_arr, meas_arr[:, axis_idx], args.pre_step_s, final_value,
            tol_frac=0.05, step_size=args.step,
        )

        for i in range(3):
            ax = axes[i]
            # 시간축 눈금을 촘촘하게 -- 정상상태시간을 눈으로도 읽기 쉽게
            ax.xaxis.set_major_locator(plt.MaxNLocator(nbins=20))
            ax.grid(True, which="major", alpha=0.3)
            ax.grid(True, which="minor", alpha=0.1)
            ax.minorticks_on()

        if settling_t is not None:
            print(f"\n정상상태시간({axis_name}축, ±5% 기준): {settling_t - args.pre_step_s:.3f}초 "
                  f"(스텝 인가 후 기준, 허용오차 ±{band:.2f}mm)")
            axes[axis_idx].axvline(settling_t, color="red", linestyle="-.", alpha=0.8,
                             label=f"settled ({settling_t - args.pre_step_s:.2f}s)")
            axes[axis_idx].axhspan(final_value - band, final_value + band,
                             color="green", alpha=0.08, label="±5% band")
            axes[axis_idx].legend(loc="best", fontsize=8)
        else:
            print(f"\n정상상태시간({axis_name}축, ±5% 기준): 관찰 시간({args.duration_s}초) 안에 정착 못 함 "
                  f"(허용오차 ±{band:.2f}mm) -- duration-s를 늘려서 다시 시도해보세요.")

        fig.canvas.draw_idle()
        fig.canvas.flush_events()

        out_png = csv_path.replace(".csv", "_step_response.png")
        plt.savefig(out_png, dpi=150)
        print(f"그래프 저장: {out_png}")

    print("종료하려면 그래프 창을 닫으세요.")
    plt.ioff()
    plt.show()


if __name__ == "__main__":
    main()
