"""
position_pid.py

목표 위치(target_pc, SpaceMouse가 정한 것)와 실측 위치(OptiTrack, opti_to_manip
변환값) 사이의 오차를 보고, 그 오차를 줄이는 방향으로 IK에 넣을 최종 명령
위치를 계산하는 위치 PID 컨트롤러.

설계 원칙
--------
- 하중/점탄성 등 "왜 벗어났는지"는 전혀 모델링하지 않음. 그냥 벗어난 만큼
  보정 -> K-MLP식 명시적 하중 모델링을 완전히 대체.
- 소프트로봇은 지연(delay)이 있는 시스템이라, 게인을 세게 넣으면 진동하기
  쉬움. 그래서:
    - anti-windup: 적분항이 무한정 커지지 않도록 클램프
    - output clamp: 한 스텝에 너무 크게 보정하지 않도록 최대 보정량 제한
    - Ki 기본값 0.0 (처음엔 P/D만 쓰다가, 필요하면 아주 조금씩 늘려갈 것)
"""

from __future__ import annotations

import time
import numpy as np


class PositionPIDController:
    def __init__(
        self,
        kp: float = 0.6,
        ki: float = 0.0,
        kd: float = 0.05,
        integral_clamp: float = 50.0,   # mm, 적분항이 이 이상 못 쌓이게 제한
        output_clamp: float = 15.0,     # mm, 한 스텝 보정량 최대치
    ):
        self.kp = kp
        self.ki = ki
        self.kd = kd
        self.integral_clamp = integral_clamp
        self.output_clamp = output_clamp

        self._integral = np.zeros(3, dtype=float)
        self._prev_error = np.zeros(3, dtype=float)
        self._prev_t = None

    def reset(self):
        """적분항/이전오차 초기화. 목표를 크게 바꾸거나, 트래킹이 끊겼다
        다시 잡혔을 때 호출 권장 (안 그러면 그동안 쌓인 적분항이 갑자기
        큰 보정을 만들어버릴 수 있음)."""
        self._integral[:] = 0.0
        self._prev_error[:] = 0.0
        self._prev_t = None

    def update(self, target_pc: np.ndarray, measured_pc: np.ndarray) -> np.ndarray:
        """
        target_pc  : SpaceMouse가 정한 목표 위치 (로봇 좌표계, mm)
        measured_pc: OptiTrack 실측 위치 (로봇 좌표계, mm, opti_to_manip 결과)

        반환값: IK에 넣을 최종 명령 위치 (target_pc + PID 보정값)
        """
        target_pc = np.asarray(target_pc, dtype=float).reshape(3,)
        measured_pc = np.asarray(measured_pc, dtype=float).reshape(3,)

        now = time.perf_counter()
        if self._prev_t is None:
            dt = 0.0
        else:
            dt = max(1e-4, now - self._prev_t)  # 0으로 나누기 방지
        self._prev_t = now

        error = target_pc - measured_pc

        # 적분항 (anti-windup: 클램프)
        self._integral += error * dt
        self._integral = np.clip(self._integral, -self.integral_clamp, self.integral_clamp)

        # 미분항
        derivative = (error - self._prev_error) / dt if dt > 0 else np.zeros(3)
        self._prev_error = error

        correction = self.kp * error + self.ki * self._integral + self.kd * derivative

        # 한 스텝 보정량 제한 (급격한 명령 변화 방지)
        corr_norm = float(np.linalg.norm(correction))
        if corr_norm > self.output_clamp:
            correction = correction * (self.output_clamp / corr_norm)

        return target_pc + correction
