"""
plot_session.py - franka_task.py가 저장한 sessions/*.csv를 나중에 열어서
x / y / z / yaw 4개 subplot으로 그려주는 오프라인 스크립트.

로봇 제어 중에는 절대 실행하지 않음 -- 세션이 끝난 뒤 따로 실행.
(실시간 중에 matplotlib을 띄우면 GIL을 잡아먹어 franka_task 쪽 타이밍이
밀리면서 reflex fault가 났던 문제 때문에, 그리기는 완전히 분리함.)

사용법:
    python plot_session.py                  # sessions/ 폴더에서 가장 최근 파일
    python plot_session.py sessions/session_20260817_153000.csv   # 특정 파일 지정
"""

import csv
import glob
import os
import sys

import matplotlib.pyplot as plt


def find_latest_session():
    files = glob.glob(os.path.join("sessions", "session_*.csv"))
    if not files:
        raise FileNotFoundError("sessions/ 폴더에 session_*.csv 파일이 없음")
    return max(files, key=os.path.getmtime)


def load_session(filepath):
    t, raw_x, raw_y, raw_yaw, raw_z_btn = [], [], [], [], []
    vx, vy, vz, wz = [], [], [], []
    act_vx, act_vy, act_vz, act_wz = [], [], [], []

    with open(filepath, newline="") as f:
        reader = csv.DictReader(f)
        has_actual = "act_vx" in reader.fieldnames
        for row in reader:
            t.append(float(row["t"]))
            raw_x.append(float(row["raw_x"]))
            raw_y.append(float(row["raw_y"]))
            raw_yaw.append(float(row["raw_yaw"]))
            raw_z_btn.append(float(row["raw_z_btn"]))
            vx.append(float(row["vx"]))
            vy.append(float(row["vy"]))
            vz.append(float(row["vz"]))
            wz.append(float(row["wz"]))
            if has_actual:
                act_vx.append(float(row["act_vx"]))
                act_vy.append(float(row["act_vy"]))
                act_vz.append(float(row["act_vz"]))
                act_wz.append(float(row["act_wz"]))

    return {
        "t": t,
        "raw_x": raw_x, "raw_y": raw_y, "raw_yaw": raw_yaw, "raw_z_btn": raw_z_btn,
        "vx": vx, "vy": vy, "vz": vz, "wz": wz,
        "act_vx": act_vx, "act_vy": act_vy, "act_vz": act_vz, "act_wz": act_wz,
        "has_actual": has_actual,
    }


def plot_axis(ax, t, raw, vel, raw_label, vel_label, vel_ylabel, act=None, act_label=None):
    """
    한 subplot 안에 빨강(raw 입력, 왼쪽 y축) + 파랑(커맨드 target, 오른쪽 y축)
    + 초록(실측 속도, 오른쪽 y축, 있으면) 이중 y축으로 그림. 단위가 다르므로
    (무차원 -1~1 vs m/s 또는 rad/s) twinx를 씀.
    """
    ax.plot(t, raw, color="red", label=raw_label, linewidth=1.2)
    ax.set_ylabel(raw_label, color="red")
    ax.tick_params(axis="y", labelcolor="red")
    ax.set_ylim(-1.1, 1.1)
    ax.grid(True, alpha=0.3)

    ax2 = ax.twinx()
    ax2.plot(t, vel, color="blue", label=vel_label, linewidth=1.2)
    if act is not None:
        ax2.plot(t, act, color="green", label=act_label, linewidth=1.0, alpha=0.85)
    ax2.set_ylabel(vel_ylabel, color="blue")
    ax2.tick_params(axis="y", labelcolor="blue")
    if act is not None:
        ax2.legend(loc="upper right", fontsize=8)

    return ax2


def main():
    filepath = sys.argv[1] if len(sys.argv) > 1 else find_latest_session()
    print(f"[plot_session] loading {filepath}")

    data = load_session(filepath)
    t = data["t"]

    fig, axes = plt.subplots(4, 1, sharex=True, figsize=(10, 10))
    fig.canvas.manager.set_window_title(os.path.basename(filepath))

    has_act = data["has_actual"]

    plot_axis(axes[0], t, data["raw_x"], data["vx"], "x raw", "vx (target)", "vx (m/s)",
              act=data["act_vx"] if has_act else None, act_label="vx (actual)")
    axes[0].set_title("X axis")

    plot_axis(axes[1], t, data["raw_y"], data["vy"], "y raw", "vy (target)", "vy (m/s)",
              act=data["act_vy"] if has_act else None, act_label="vy (actual)")
    axes[1].set_title("Y axis")

    plot_axis(axes[2], t, data["raw_z_btn"], data["vz"], "z button", "vz (target)", "vz (m/s)",
              act=data["act_vz"] if has_act else None, act_label="vz (actual)")
    axes[2].set_title("Z axis (button input)")

    plot_axis(axes[3], t, data["raw_yaw"], data["wz"], "yaw raw", "wz (target)", "wz (rad/s)",
              act=data["act_wz"] if has_act else None, act_label="wz (actual)")
    axes[3].set_title("Yaw")
    axes[3].set_xlabel("time (s)")

    fig.tight_layout()

    out_png = os.path.splitext(filepath)[0] + ".png"
    fig.savefig(out_png, dpi=150)
    print(f"[plot_session] saved -> {out_png}")

    plt.show()


if __name__ == "__main__":
    main()
